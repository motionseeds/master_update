/* MotionSeeds Master - compatibility.jsx (AE CC 2018 -> 2026, ExtendScript ES3) */
/*
 * json2.js (MotionSeeds build) - ES3-safe JSON polyfill.
 * Public-domain algorithm (after Douglas Crockford's json2.js).
 * Works in ExtendScript (AE CC 2018+, where JSON is missing) and in browsers.
 * Only defines JSON.stringify / JSON.parse when the host does not provide them.
 */
(function (G) {
    if (typeof G.JSON !== "object" || G.JSON === null) {
        G.JSON = {};
    }
    var J = G.JSON;
    var rxOne = /^[\],:{}\s]*$/;
    var rxTwo = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rxThree = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
    var rxFour = /(?:^|:|,)(?:\s*\[)+/g;
    var rxEscapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var rxDangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var meta = { "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", "\"": "\\\"", "\\": "\\\\" };

    function quote(s) {
        rxEscapable.lastIndex = 0;
        return rxEscapable.test(s) ? "\"" + s.replace(rxEscapable, function (a) {
            var c = meta[a];
            return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
        }) + "\"" : "\"" + s + "\"";
    }

    function isArr(v) {
        return Object.prototype.toString.apply(v) === "[object Array]";
    }

    function str(key, holder) {
        var i, k, v, partial, value = holder[key];
        if (value && typeof value === "object" && typeof value.toJSON === "function") {
            value = value.toJSON(key);
        }
        switch (typeof value) {
        case "string":
            return quote(value);
        case "number":
            return isFinite(value) ? String(value) : "null";
        case "boolean":
            return String(value);
        case "object":
            if (!value) {
                return "null";
            }
            partial = [];
            if (isArr(value)) {
                for (i = 0; i < value.length; i += 1) {
                    partial[i] = str(i, value) || "null";
                }
                return partial.length === 0 ? "[]" : "[" + partial.join(",") + "]";
            }
            for (k in value) {
                if (Object.prototype.hasOwnProperty.call(value, k)) {
                    v = str(k, value);
                    if (v) {
                        partial.push(quote(k) + ":" + v);
                    }
                }
            }
            return partial.length === 0 ? "{}" : "{" + partial.join(",") + "}";
        }
        return undefined;
    }

    if (typeof J.stringify !== "function") {
        J.stringify = function (value) {
            return str("", { "": value });
        };
    }

    if (typeof J.parse !== "function") {
        J.parse = function (text) {
            text = String(text);
            rxDangerous.lastIndex = 0;
            if (rxDangerous.test(text)) {
                text = text.replace(rxDangerous, function (a) {
                    return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }
            if (rxOne.test(text.replace(rxTwo, "@").replace(rxThree, "]").replace(rxFour, ""))) {
                return eval("(" + text + ")");
            }
            throw new SyntaxError("JSON.parse: invalid JSON");
        };
    }
}((typeof $ !== "undefined" && $.global) ? $.global : this));


/*
 * MotionSeeds compatibility layer (AE CC 2018 / ExtendScript ES3 -> AE 2026)
 * - JSON polyfill above (json2) for engines without native JSON.
 * - Version flags used by the host to pick safe code paths.
 */
(function (G) {
    var C = G.MotionSeedsCompat = G.MotionSeedsCompat || {};
    var v = parseFloat(app.version);
    C.aeVersion = isNaN(v) ? 15 : v;               // 15 = CC 2018, 16 = 2019, 17 = 2020, 18 = 2021, 22+ = 2022+
    C.hasTaper = C.aeVersion >= 17.1;              // stroke taper / wave (AE 2020 17.1+)
    C.hasH264RQ = C.aeVersion >= 23;               // H.264 in Render Queue returned in AE 2023
    C.hasAME = C.aeVersion >= 14;                  // queueInAME (CC 2017+)
    C.isWin = $.os.indexOf("Windows") !== -1;
    C.ok = true;
}($.global));
