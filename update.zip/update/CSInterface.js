/*
 * MotionSeeds CSInterface (lightweight, API-compatible subset of Adobe's CSInterface.js)
 * Talks to the CEP runtime directly through window.__adobe_cep__ (CEP 8 -> CEP 12).
 * Only the calls used by MotionSeeds Master are implemented.
 */
(function (global) {
    "use strict";

    var SystemPath = {
        USER_DATA: "userData",
        COMMON_FILES: "commonFiles",
        MY_DOCUMENTS: "myDocuments",
        APPLICATION: "application",
        EXTENSION: "extension",
        HOST_APPLICATION: "hostApplication"
    };

    function CSInterface() {}

    CSInterface.prototype.isCEP = function () {
        return !!(global.__adobe_cep__);
    };

    CSInterface.prototype.getOSInformation = function () {
        var ua = global.navigator ? global.navigator.userAgent : "";
        var platform = global.navigator ? global.navigator.platform : "";
        if (platform.indexOf("Win") === 0 || ua.indexOf("Windows") >= 0) { return "Windows"; }
        if (platform.indexOf("Mac") === 0 || ua.indexOf("Mac OS") >= 0) { return "Mac OS"; }
        return "Unknown Operation System";
    };

    CSInterface.prototype.getSystemPath = function (pathType) {
        if (!global.__adobe_cep__) { return ""; }
        var path = decodeURI(global.__adobe_cep__.getSystemPath(pathType));
        var os = this.getOSInformation();
        if (os.indexOf("Windows") >= 0) { path = path.replace("file:///", ""); }
        else if (os.indexOf("Mac") >= 0) { path = path.replace("file://", ""); }
        return path;
    };

    CSInterface.prototype.evalScript = function (script, callback) {
        if (!global.__adobe_cep__) {
            if (callback) { setTimeout(function () { callback("EvalScript error."); }, 0); }
            return;
        }
        global.__adobe_cep__.evalScript(script, callback || function () {});
    };

    CSInterface.prototype.getHostEnvironment = function () {
        try { return JSON.parse(global.__adobe_cep__.getHostEnvironment()); } catch (e) { return null; }
    };

    CSInterface.prototype.openURLInDefaultBrowser = function (url) {
        try {
            if (global.cep && global.cep.util && global.cep.util.openURLInDefaultBrowser) {
                global.cep.util.openURLInDefaultBrowser(url);
                return true;
            }
        } catch (e) {}
        try { global.open(url, "_blank"); } catch (e2) {}
        return false;
    };

    CSInterface.prototype.addEventListener = function (type, listener, obj) {
        if (global.__adobe_cep__) { global.__adobe_cep__.addEventListener(type, listener, obj); }
    };

    global.CSInterface = CSInterface;
    global.SystemPath = SystemPath;
}(window));
