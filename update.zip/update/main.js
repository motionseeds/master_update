/*
 * MotionSeeds Master - main.js (panel logic)
 * CEP 8 (AE CC 2018, Chromium 57) -> CEP 12 (AE 2023-2026).
 * Every tool button sends:  MotionSeeds.exec(tool, modifierTier, argsJSON)  to hostscript.jsx
 * Modifier tiers: click | alt | shift | ctrl | ctrlAlt | shiftCtrl | shiftCtrlAlt  (Cmd = Ctrl on macOS)
 */
// Flex "gap" support test (CEP 8-10 = Chromium 57-74 have no flex gap) -> html.no-flexgap enables CSS fallbacks
(function () {
    try {
        var d = document.createElement('div');
        d.style.cssText = 'display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden;';
        d.appendChild(document.createElement('div'));
        d.appendChild(document.createElement('div'));
        document.body.appendChild(d);
        var ok = d.scrollHeight === 1;
        d.parentNode.removeChild(d);
        if (!ok) { document.documentElement.className += ' no-flexgap'; }
    } catch (e) {}
}());

document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    // ==========================================
    // ENVIRONMENT
    // ==========================================
    var csi = new CSInterface();
    var IS_CEP = csi.isCEP();
    var EXT_ROOT = IS_CEP ? csi.getSystemPath(SystemPath.EXTENSION).replace(/\\/g, '/') : '';
    var IS_MAC = (navigator.platform || '').indexOf('Mac') === 0;
    var WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbx2ONVheYljOm0NPCrxLJrSnqAzW_a3Jz8gO2K9QTLsHSi8lCXQcR_XeMlTUewPEjQt/exec';
    var nodeRequire = (window.cep_node && window.cep_node.require) ? window.cep_node.require : (typeof window.require === 'function' ? window.require : null);

    function $(id) { return document.getElementById(id); }
    function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
    function replaceClass(el, a, b) { if (el && el.classList.contains(a)) { el.classList.remove(a); el.classList.add(b); } }
    function store(key, val) {
        try {
            if (val === undefined) { return localStorage.getItem(key); }
            if (val === null) { localStorage.removeItem(key); } else { localStorage.setItem(key, val); }
        } catch (e) {}
        return null;
    }
    function esc(s) { return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function jsLit(s) { return JSON.stringify(String(s)).replace(/[\u007f-\uffff]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); }
    function hash(s) { var h = 5381, i; s = String(s); for (i = 0; i < s.length; i++) { h = ((h << 5) + h + s.charCodeAt(i)) | 0; } return 'h' + (h >>> 0).toString(36); }
    function clampInt(v, a, b, d) { var n = parseInt(v, 10); if (isNaN(n)) { n = d; } return Math.max(a, Math.min(b, n)); }

    // ==========================================
    // TOAST SYSTEM (errors + short host notices)
    // ==========================================
    var toastContainer = $('toast-container');
    var toastMessage = $('toast-message');
    var toastIcon = $('toast-icon');
    var toastTimeout;

    window.showToast = function (message, type) {
        type = type || 'success';
        if (type !== 'error' && type !== 'info') { return; }
        if (!toastMessage || !toastContainer) { return; }
        toastMessage.textContent = String(message).replace(/(<([^>]+)>)/gi, '');
        toastContainer.className = 'show' + (type === 'info' ? ' info' : '');
        if (toastIcon) { toastIcon.className = 'ph ' + (type === 'info' ? 'ph-check-circle text-[#30d158]' : 'ph-warning-circle text-[#ff375f]') + ' text-[18px]'; }
        clearTimeout(toastTimeout);
        toastTimeout = setTimeout(function () {
            if (!toastContainer) { return; }
            toastContainer.classList.remove('show');
        }, type === 'info' ? 2600 : 3800);
    };

    // ==========================================
    // HOST BRIDGE (queued ExtendScript calls)
    // ==========================================
    var Host = {
        chain: Promise.resolve(),
        ready: false,
        evalRaw: function (script) {
            return new Promise(function (resolve) {
                if (!IS_CEP) { resolve('NO_CEP'); return; }
                csi.evalScript(script, function (r) { resolve(r); });
            });
        },
        queue: function (fn) {
            var p = Host.chain.then(fn, fn);
            Host.chain = p.then(function () {}, function () {});
            return p;
        },
        run: function (tool, mod, args, opt) {
            opt = opt || {};
            var payload = Object.assign({}, commonArgs(), args || {});
            var script = 'MotionSeeds.exec(' + jsLit(tool) + ',' + jsLit(mod) + ',' + jsLit(JSON.stringify(payload)) + ')';
            return Host.queue(function () {
                return (tool === '__init__' ? Promise.resolve() : hostReady()).then(function () { return Host.evalRaw(script); }).then(function (raw) {
                    var res;
                    if (raw === 'NO_CEP') { res = { ok: false, err: 'Open this panel inside After Effects (Window > Extensions > Master).' }; }
                    else if (!raw || raw === 'EvalScript error.' || raw === 'undefined') { res = { ok: false, err: 'MotionSeeds host script is not loaded. Restart After Effects.' }; }
                    else { try { res = JSON.parse(raw); } catch (e) { res = { ok: false, err: String(raw) }; } }
                    if (!res.ok && !opt.silent) { showToast(res.err || 'Unknown error', 'error'); }
                    if (res.ok && res.info && !opt.silent) { showToast(res.info, 'info'); }
                    return res;
                });
            });
        },
        init: function () {
            if (!IS_CEP) { return Promise.resolve(false); }
            var root = jsLit(EXT_ROOT);
            var script = '(function(){var r=' + root + ';' +
                'try{if(typeof JSON!=="object"||typeof $.global.MotionSeedsCompat==="undefined"){$.evalFile(new File(r+"/jsx/compatibility.jsx"));}}catch(e){}' +
                'try{if(typeof MotionSeeds!=="object"){$.evalFile(new File(r+"/jsx/hostscript.jsx"));}}catch(e2){return "LOAD_ERROR: "+e2;}' +
                'if(typeof MotionSeeds!=="object"){return "LOAD_ERROR";}MotionSeeds.setRoot(r);return MotionSeeds.ping();}())';
            return Host.evalRaw(script).then(function (r) {
                Host.ready = !!r && r.indexOf('"ok":true') !== -1;
                if (!Host.ready) { showToast('MotionSeeds host failed to load: ' + r, 'error'); }
                return Host.ready;
            });
        }
    };

    var hostInitPromise = null;
    function hostReady() {
        if (!hostInitPromise) { hostInitPromise = Host.init(); }
        return hostInitPromise;
    }

    function tierOf(e) {
        var c = !!(e.ctrlKey || e.metaKey), a = !!e.altKey, s = !!e.shiftKey;
        if (s && c && a) { return 'shiftCtrlAlt'; }
        if (s && c) { return 'shiftCtrl'; }
        if (c && a) { return 'ctrlAlt'; }
        if (s && a) { return 'shiftAlt'; }
        if (c) { return 'ctrl'; }
        if (s) { return 'shift'; }
        if (a) { return 'alt'; }
        return 'click';
    }

    // ==========================================
    // TOOL MODIFIER MATRIX (tooltips)
    // ==========================================
    var M = function (t, rows) { return { title: t, rows: rows }; };
    var TIPS = {
        textShape: M('Align Text to Shape', [['Click', 'Center Text to Shape Bounds'], ['Alt+Click', 'Link via Expressions'], ['Shift+Click', 'Auto-Resize Shape to Text']]),
        solid: M('New Solid Layer', [['Click', 'Solid + Fill Effect'], ['Alt+Click', 'Solid + 4-Color Gradient'], ['Shift+Click', 'Solid + Fractal Noise'], ['Ctrl+Click', 'Solid + Gradient Ramp'], ['Ctrl+Alt', 'Solid + Grid'], ['Shift+Ctrl', 'Vignette Setup']]),
        nullObj: M('New Null Object', [['Click', 'Full Comp Size Null'], ['Alt+Click', 'Match Selected Layer Size'], ['Shift+Click', 'Auto-Parent Selected to Null'], ['Ctrl+Click', 'Start at Current Time (CTI)'], ['Ctrl+Alt', 'Expression-Link Selected'], ['Shift+Ctrl', 'Trim to Work Area']]),
        adjLayer: M('New Adjustment Layer', [['Click', 'Full Comp Size'], ['Alt+Click', 'Match Selected Layer Size'], ['Shift+Click', 'Auto-Parent Selected'], ['Ctrl+Click', 'Start at Current Time (CTI)'], ['Ctrl+Alt', 'Expression-Link Selected'], ['Shift+Ctrl', 'Trim to Work Area']]),
        precompose: M('Pre-compose', [['Click', 'Move All Attributes'], ['Alt+Click', 'Leave All Attributes'], ['Shift+Click', 'Trim Comp to Layer Duration'], ['Ctrl+Click', 'Auto-Open New Comp'], ['Ctrl+Alt', 'Bake Expressions Inside'], ['Shift+Ctrl', 'Crop Comp to Content']]),
        split: M('Split Layer', [['Click', 'Split at CTI'], ['Alt+Click', 'Trim Out (Right)'], ['Shift+Click', 'Split & Remove Extra Keyframes'], ['Ctrl+Click', 'Trim In (Left)'], ['Ctrl+Alt', 'Split + 5-Frame Crossfade'], ['Shift+Ctrl', 'Trim to Work Area']]),
        fill: M('Add Fill Effect', [['Click', 'Add Fill (Active Swatch)'], ['Alt+Click', 'Pick Color from Layer']]),
        camera: M('New Camera', [['Click', 'Default 2-Node Camera'], ['Alt+Click', 'Start at Layer In-Point'], ['Shift+Click', 'Camera + Control Null Rig'], ['Ctrl+Click', '1-Node Camera'], ['Ctrl+Alt', 'Pro Multi-Node Rig'], ['Shift+Ctrl', 'Auto Depth of Field']]),
        newComp: M('New Composition', [['Click', 'Create new Comp'], ['Alt', 'Match Selected Item Size'], ['Shift', 'Default 1080p Comp'], ['Ctrl', '4K (UHD) Comp'], ['Ctrl+Alt', 'Square (1:1) Comp'], ['Shift+Ctrl', 'Custom Settings Prompt'], ['Shift+Ctrl+Alt', 'Vertical (9:16) Reels Comp']]),
        bounce: M('Bounce Expression', [['Click', 'Add to Keyframed Property'], ['Alt+Click', 'Add + 3 Slider Controls'], ['Shift+Click', 'All Keyed Transform Props'], ['Ctrl+Click', 'Remove Bounce'], ['Ctrl+Alt', 'Bake Physics to Keys'], ['Shift+Ctrl', 'Randomize Parameters']]),
        textAnim: M('Text Animation', [['Click', 'Scale Animator + Bounce Expr'], ['Alt+Click', 'Position Drop + Overshoot'], ['Shift+Click', 'Opacity Fade Stagger'], ['Ctrl+Click', 'Remove Animator'], ['Ctrl+Alt', 'Expand Tracking'], ['Shift+Ctrl', '3D Tumble Characters']]),
        loop: M('Loop Expression', [['Click', "loopOut('cycle')"], ['Alt+Click', "loopOut('pingpong')"], ['Shift+Click', "loopOut('offset')"], ['Ctrl+Click', 'Remove Loop'], ['Ctrl+Alt', "loopOut('continue')"], ['Shift+Ctrl', 'Marker-Triggered Loop']]),
        keyClone: M('Keyframe Clone', [['Click', 'Clone Selected Keyframes to CTI'], ['Shift+Click', 'Clone + Time Reverse'], ['Ctrl+Click', 'Clone to Other Selected Layers']]),
        stagger: M('Sequence & Stagger', [['Click', 'Stagger by Frames'], ['Alt+Click', 'Randomize Intervals'], ['Shift+Click', 'End-to-End Chain (no gaps)'], ['Ctrl+Click', 'Offset In-Points Only'], ['Ctrl+Alt', 'Time-Delay Expression'], ['Shift+Ctrl', 'Stagger + Opacity Fade-In']]),
        explode: M('Explode/Merge Shapes', [['Click', 'Explode Groups into Layers'], ['Alt+Click', 'Merge Layers into Groups'], ['Shift+Click', 'Center Group Anchors'], ['Ctrl+Click', 'Group Items'], ['Ctrl+Alt', 'Ungroup Items'], ['Shift+Ctrl', 'Explode + Stagger']]),
        trim: M('Smart Trim Paths', [['Click', 'Add Trim Paths (0-100 Anim)'], ['Alt+Click', 'Infinite Radar Loop'], ['Shift+Click', 'Symmetrical Dual Trim'], ['Ctrl+Click', 'Glitch Offset'], ['Ctrl+Alt', 'Linked Slider Controls'], ['Shift+Ctrl', 'Staggered Across Shapes']]),
        autoBox: M('Auto-Box (Text)', [['Click', 'Dynamic Box behind Text'], ['Alt+Click', 'Rounded Corners + Shadow'], ['Shift+Click', 'Linked Opacity Control'], ['Ctrl+Click', 'Stroke-Only Outline'], ['Ctrl+Alt', 'Skewed Perspective Box'], ['Shift+Ctrl', 'Highlight Accent Bar']]),
        burst: M('Quick Burst', [['Click', 'Line Burst Animation'], ['Alt+Click', 'Random Color Burst'], ['Shift+Click', 'Circle Scale Burst'], ['Ctrl+Click', 'Star Burst'], ['Ctrl+Alt', '3D Z-Space Burst'], ['Shift+Ctrl', 'Looping Burst']]),
        splitText: M('Split Text', [['Click', 'Split by Lines'], ['Alt+Click', 'Split by Words'], ['Shift+Click', 'Split by Characters'], ['Ctrl+Click', 'Lines + Keep Backup Layer'], ['Ctrl+Alt', 'Split + Precomp Each'], ['Shift+Ctrl', 'Z-Space Character Scatter']]),
        counter: M('Smart Counter', [['Click', '0-100 Counter Expression'], ['Alt+Click', 'Currency Format ($#,###)'], ['Shift+Click', 'Countdown Timer'], ['Ctrl+Click', 'Digital Clock HH:MM:SS'], ['Ctrl+Alt', 'Comp Timecode Link'], ['Shift+Ctrl', 'Odometer Rolling Digits']]),
        typewriter: M('Typewriter Pro', [['Click', 'Typewriter + Blinking Cursor'], ['Alt+Click', 'Speed Control Sliders'], ['Shift+Click', 'Word-by-Word Reveal'], ['Ctrl+Click', 'Terminal Hacker Style'], ['Ctrl+Alt', 'Marker-Triggered Typing'], ['Shift+Ctrl', 'Scramble Decrypt']]),
        lookAt: M('Look-At / Orient', [['Click', '2D Target Expression'], ['Alt+Click', '3D Orient to Null'], ['Shift+Click', 'Face Active Camera'], ['Ctrl+Click', 'Y-Axis Rotation Only'], ['Ctrl+Alt', 'X-Axis Rotation Only'], ['Shift+Ctrl', 'Instant 180\u00B0 Flip']]),
        capRound: M('Round Cap', [['Click', 'Round Cap (Selected Shapes)'], ['Alt+Click', 'Dashed Stroke'], ['Shift+Click', 'All Shapes in Comp'], ['Ctrl+Click', 'Toggle Round/Miter Join'], ['Ctrl+Alt', 'Tapered Stroke (AE 2020+)'], ['Shift+Ctrl', 'Zig-Zag / Wave Modifier']]),
        capButt: M('Butt Cap', [['Click', 'Butt Cap (Selected Shapes)'], ['Alt+Click', 'Dashed Stroke'], ['Shift+Click', 'All Shapes in Comp'], ['Ctrl+Click', 'Toggle Round/Miter Join'], ['Ctrl+Alt', 'Tapered Stroke (AE 2020+)'], ['Shift+Ctrl', 'Zig-Zag / Wave Modifier']]),
        pointNull: M('Point to Null', [['Click', 'Null on Path Vertex 1'], ['Alt+Click', 'Nulls for All Vertices'], ['Shift+Click', 'Trace Path Through Selected'], ['Ctrl+Click', '0-100% Path Tracker Null'], ['Ctrl+Alt', 'Null at Vertex Number...'], ['Shift+Ctrl', 'Bake Tracking Nulls']]),
        fit: M('Fit to Comp', [['Click', 'Fit Proportional'], ['Alt+Click', 'Fit Width Only'], ['Shift+Click', 'Fit Height Only'], ['Ctrl+Click', 'Stretch to Fit'], ['Ctrl+Alt', 'Scale Expression Lock'], ['Shift+Ctrl', 'Fit to Action Safe']]),
        keyUtils: M('Keyframe Utils', [['Click', 'Reverse Selected Keys'], ['Alt+Click', 'Bake Expressions to Keys'], ['Shift+Click', 'Clone Keys to CTI'], ['Ctrl+Click', 'Mirror Key Values'], ['Ctrl+Alt', 'Rove Keys in Time'], ['Shift+Ctrl', 'Toggle Hold Keyframes']]),
        bake: M('Bake Expressions', [['Click', 'Bake to Keyframes'], ['Alt+Click', 'Bake Every 2nd Frame'], ['Shift+Click', 'Bake Whole Comp']]),
        crop: M('Crop Comp to Selection', [['Click', 'Crop Work Area to Selection'], ['Alt+Click', 'Crop Comp Duration'], ['Shift+Click', 'Crop Comp Size to Bounds']]),
        cleanup: M('Clean Up Layers', [['Click', 'Delete Empty Layers'], ['Alt+Click', 'Delete Hidden/Disabled'], ['Shift+Click', 'Remove Unused Assets'], ['Ctrl+Click', 'Delete Muted Audio Layers'], ['Ctrl+Alt', 'Delete Unlocked Layers'], ['Shift+Ctrl', 'Delete Empty Shape Groups']]),
        justifyLeft: M('Text Align Left', [['Click', 'Left Justify Selected Text']]),
        justifyCenter: M('Text Align Center', [['Click', 'Center Justify Selected Text']]),
        justifyRight: M('Text Align Right', [['Click', 'Right Justify Selected Text']]),
        colorLink: M('Global Color Linker', [['Click', 'Master Color Null + Link'], ['Alt+Click', 'Unlink from Master'], ['Shift+Click', 'Link to Layer Index...'], ['Ctrl+Click', 'Link + HSL Offsets'], ['Ctrl+Alt', 'Bake Colors (hard values)'], ['Shift+Ctrl', 'Random Palette Mapping']]),
        copyEase: M('Copy Ease Velocity', [['Click', 'Copy Ease from Keyframe'], ['Shift+Click', 'Paste Ease to Selected Keys']]),
        rename: M('Batch Rename', [['Click', 'Rename Selected...'], ['Alt+Click', 'Staircase Name_01, _02...'], ['Shift+Click', 'Append Suffix...'], ['Ctrl+Click', 'Color-Code by Type'], ['Ctrl+Alt', 'Search & Replace...'], ['Shift+Ctrl', 'Prepend Prefix...']]),
        group: M('Smart Grouping', [['Click', 'Group Null + Parent'], ['Alt+Click', 'Select Child Layers'], ['Shift+Click', 'Ungroup / Clear Parents'], ['Ctrl+Click', 'Pre-compose Group'], ['Ctrl+Alt', 'Lock Group Hierarchy'], ['Shift+Ctrl', 'Solo Group Hierarchy']]),
        snapshot: M('Smart Snapshot', [['Click', 'PNG + Import to Project'], ['Alt+Click', 'Save PNG to Folder...'], ['Shift+Click', 'Compressed JPEG'], ['Ctrl+Click', 'Layered PSD'], ['Ctrl+Alt', 'Frames at Markers'], ['Shift+Ctrl', 'Alpha-Trimmed PNG']]),
        render: M('Quick Render', [['Click', 'H.264 / MP4'], ['Alt+Click', 'ProRes 4444 + Alpha'], ['Shift+Click', 'Animated GIF (Media Encoder)'], ['Ctrl+Click', 'Send to Media Encoder'], ['Ctrl+Alt', 'ProRes 422'], ['Shift+Ctrl', 'WAV Audio Only']]),
        purge: M('Project Purge & Save', [['Click', 'Remove Unused Footage'], ['Alt+Click', 'Purge Memory & Disk Cache'], ['Shift+Click', 'Consolidate Footage'], ['Ctrl+Click', 'Reduce to Active Comps'], ['Ctrl+Alt', 'Purge + Save as _v02'], ['Shift+Ctrl', 'Collect Files']])
    };
    function tipHTML(title, rows) {
        var h = '<b>' + esc(title) + '</b>', i;
        for (i = 0; i < rows.length; i++) { h += "<div class='mod-row'><span class='mod-color'>" + esc(rows[i][0]) + ":</span> " + esc(rows[i][1]) + '</div>'; }
        return h;
    }

    // ==========================================
    // FREE LICENSE SYSTEM INTEGRATION (Google Sheets + Apps Script)
    // ==========================================
    var licenseModal = $('license-modal');
    var licenseKeyInput = $('license-key-input');
    var activateBtn = $('activate-btn');
    var licenseError = $('license-error');
    var LS_ACT = 'motionSeeds_master_activated', LS_KEY = 'motionSeeds_license_key', LS_SIG = 'motionSeeds_device_sig';
    var deviceIdPromise = null;

    function nodeDeviceId() {
        if (!nodeRequire) { return null; }
        try {
            var cp = nodeRequire('child_process'), os = nodeRequire('os'), out = '', m, rx = /[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/;
            var ok = function (u) { return u && !/^[0F\-]+$/i.test(u); };
            var run = function (cmd) { try { return String(cp.execSync(cmd, { encoding: 'utf8', timeout: 10000, windowsHide: true })); } catch (e) { return ''; } };
            if (os.platform() === 'win32') {
                out = run('wmic csproduct get uuid'); m = out.match(rx); if (m && ok(m[0])) { return 'WIN_' + m[0].toUpperCase(); }
                out = run('powershell.exe -NoProfile -NonInteractive -Command "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID"'); m = out.match(rx); if (m && ok(m[0])) { return 'WIN_' + m[0].toUpperCase(); }
                out = run('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid'); m = out.match(/MachineGuid\s+REG_SZ\s+([0-9A-Fa-f\-]+)/); if (m) { return 'WINR_' + m[1].toUpperCase(); }
            } else {
                out = run('/usr/sbin/ioreg -rd1 -c IOPlatformExpertDevice'); m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/); if (m) { return 'MAC_' + m[1]; }
            }
            var u = ''; try { u = os.userInfo().username; } catch (e2) {}
            return 'NODE_' + hash(os.hostname() + '|' + u + '|' + os.platform()).toUpperCase();
        } catch (e) { return null; }
    }
    function getDeviceID() {
        if (deviceIdPromise) { return deviceIdPromise; }
        deviceIdPromise = hostReady().then(function () { return Host.evalRaw('(typeof getSystemDeviceID==="function")?getSystemDeviceID():"MOTIONSEEDS_FALLBACK_DEVICE_ID"').then(function (id) {
            if (!id || id === 'NO_CEP' || id === 'undefined' || id.indexOf('EvalScript') !== -1 || id.indexOf('FALLBACK') !== -1 || id.indexOf('ERR') === 0) {
                id = nodeDeviceId() || ('MS_' + hash(navigator.userAgent + '|' + EXT_ROOT).toUpperCase());
            }
            return id;
        }); });
        return deviceIdPromise;
    }
    function postLicense(key, deviceID) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', WEB_APP_URL, true);
            xhr.setRequestHeader('Content-Type', 'text/plain;charset=utf-8');
            xhr.timeout = 25000;
            xhr.onload = function () {
                try { resolve(JSON.parse(xhr.responseText)); }
                catch (e) { reject(new Error('Unexpected server response (' + xhr.status + '). Check the Apps Script deployment.')); }
            };
            xhr.onerror = function () { reject(new Error('Network error - connect to the internet to activate.')); };
            xhr.ontimeout = function () { reject(new Error('License server timed out. Try again.')); };
            xhr.send(JSON.stringify({ licenseKey: key, deviceID: deviceID }));
        });
    }
    function showLicense(msg) {
        if (licenseModal) { licenseModal.classList.remove('hidden'); }
        if (licenseError) { licenseError.innerText = msg || ''; }
    }
function checkLicenseStatus() {
        var isActivated = store(LS_ACT), key = store(LS_KEY), sig = store(LS_SIG);
        if (isActivated !== 'true' || !key) { showLicense(''); return; }
        
        getDeviceID().then(function (id) {
            // Sheet theke device ID remove korle server check-e error asbe
            postLicense(key, id).then(function (res) {
                if (res && res.status === 'SUCCESS') {
                    if (licenseModal) { licenseModal.classList.add('hidden'); }
                } else {
                    // Server theke error ba invalid asle activation clear kore diye modal দেখাবে
                    store(LS_ACT, null);
                    store(LS_KEY, null);
                    store(LS_SIG, null);
                    showLicense(res && res.message ? res.message : 'Your license has been deactivated or removed.');
                }
            }).catch(function () {
                // Network na thakle purano local signature diye cholbe (offline support)
                if (sig && sig === hash(key + '|' + id)) {
                    if (licenseModal) { licenseModal.classList.add('hidden'); }
                } else {
                    showLicense('Network error - verify your license connection.');
                }
            });
        });
    }
    function activate() {
        var key = licenseKeyInput.value.trim();
        if (key.length < 5) { licenseError.innerText = 'Please enter a valid license key.'; return; }
        licenseError.innerText = '';
        activateBtn.innerText = 'Verifying...';
        activateBtn.disabled = true;
        getDeviceID().then(function (id) {
            return postLicense(key, id).then(function (res) {
                if (res && res.status === 'SUCCESS') {
                    store(LS_ACT, 'true');
                    store(LS_KEY, key);
                    store(LS_SIG, hash(key + '|' + id));
                    if (licenseModal) { licenseModal.classList.add('hidden'); }
                } else {
                    licenseError.innerText = (res && res.message) ? res.message : 'Activation failed.';
                }
            });
        }).catch(function (err) {
            licenseError.innerText = err && err.message ? err.message : 'Activation failed.';
        }).then(function () {
            activateBtn.innerText = 'Verify & Activate';
            activateBtn.disabled = false;
        });
    }
    if (activateBtn) { activateBtn.addEventListener('click', activate); }
    if (licenseKeyInput) { licenseKeyInput.addEventListener('keydown', function (e) { if (e.keyCode === 13) { activate(); } }); }

    // ==========================================
    // POPULATE ANCHOR GRID
    // ==========================================
    var anchorGridData = [
        { icon: 'ph-arrow-up-left', pos: 'Top Left', fx: 0, fy: 0 },
        { icon: 'ph-arrow-up', pos: 'Top Center', fx: 0.5, fy: 0 },
        { icon: 'ph-arrow-up-right', pos: 'Top Right', fx: 1, fy: 0 },
        { icon: 'ph-arrow-left', pos: 'Middle Left', fx: 0, fy: 0.5 },
        { icon: 'ph-target', pos: 'Center', extra: 'center', fx: 0.5, fy: 0.5 },
        { icon: 'ph-arrow-right', pos: 'Middle Right', fx: 1, fy: 0.5 },
        { icon: 'ph-arrow-down-left', pos: 'Bottom Left', fx: 0, fy: 1 },
        { icon: 'ph-arrow-down', pos: 'Bottom Center', fx: 0.5, fy: 1 },
        { icon: 'ph-arrow-down-right', pos: 'Bottom Right', fx: 1, fy: 1 }
    ];
    var anchorContainer = $('anchor-grid-container');
    if (anchorContainer) {
        anchorGridData.forEach(function (item) {
            var btn = document.createElement('button');
            btn.className = 'anchor-btn ' + (item.extra || '');
            btn.setAttribute('data-tool', 'anchor');
            btn.setAttribute('data-arg-fx', item.fx);
            btn.setAttribute('data-arg-fy', item.fy);
            btn.setAttribute('data-tooltip', tipHTML('Anchor: ' + item.pos, [['Click', 'Move Anchor Point'], ['Alt+Click', 'Anchor + Center Layer in Comp'], ['Shift+Click', 'Move All Selected'], ['Ctrl+Click', 'Use Mask/Path Bounds'], ['Ctrl+Alt', 'Lock via Expression'], ['Shift+Ctrl', 'Bake Anchor Expressions']]));
            btn.innerHTML = '<i class="ph ' + item.icon + '"></i>';
            anchorContainer.appendChild(btn);
        });
    }

    // ==========================================
    // POPULATE ALIGNMENT & DISTRIBUTE GRIDS
    // ==========================================
    var alignTools = [
        { id: 'al-1', icon: 'ph-align-left', name: 'Align Left', op: 'left' },
        { id: 'al-2', icon: 'ph-align-center-horizontal', name: 'Align Center Horiz', op: 'hcenter' },
        { id: 'al-3', icon: 'ph-align-right', name: 'Align Right', op: 'right' },
        { id: 'al-4', icon: 'ph-align-top', name: 'Align Top', op: 'top' },
        { id: 'al-5', icon: 'ph-align-center-vertical', name: 'Align Center Vert', op: 'vcenter' },
        { id: 'al-6', icon: 'ph-align-bottom', name: 'Align Bottom', op: 'bottom' }
    ];
    var distributeTools = [
        { id: 'al-7', icon: 'ph-align-left-simple', name: 'Distribute Left', op: 'dleft' },
        { id: 'al-8', icon: 'ph-columns', name: 'Distribute Center Horiz', op: 'dhcenter' },
        { id: 'al-9', icon: 'ph-align-right-simple', name: 'Distribute Right', op: 'dright' },
        { id: 'al-10', icon: 'ph-align-top-simple', name: 'Distribute Top', op: 'dtop' },
        { id: 'al-11', icon: 'ph-rows', name: 'Distribute Center Vert', op: 'dvcenter' },
        { id: 'al-12', icon: 'ph-align-bottom-simple', name: 'Distribute Bottom', op: 'dbottom' }
    ];
    function alignTip(name, verb) {
        return tipHTML(name, [['Click', '2D Space ' + verb], ['Alt+Click', verb + ' + Keyframe'], ['Shift+Click', verb + ' + Parent'], ['Ctrl+Click', '3D Z-Space ' + verb], ['Ctrl+Alt', 'Expression Lock'], ['Shift+Ctrl', 'Procedural Motion Path']]);
    }
    var alignGrid = $('tools-align-grid');
    var distributeGrid = $('tools-distribute-grid');
    if (alignGrid) {
        alignTools.forEach(function (tool) {
            var btn = document.createElement('button');
            btn.className = 'glass-btn p-1.5 text-[14px]';
            btn.setAttribute('data-action', tool.name);
            btn.setAttribute('data-tool', 'align');
            btn.setAttribute('data-arg-op', tool.op);
            btn.setAttribute('data-tooltip', alignTip(tool.name, 'Align'));
            btn.innerHTML = '<i class="ph ' + tool.icon + '"></i>';
            alignGrid.appendChild(btn);
        });
    }
    if (distributeGrid) {
        distributeTools.forEach(function (tool) {
            var btn = document.createElement('button');
            btn.className = 'glass-btn p-1.5 text-[14px] text-[#0a84ff]/80 hover:text-[#0a84ff]';
            btn.setAttribute('data-action', tool.name);
            btn.setAttribute('data-tool', 'align');
            btn.setAttribute('data-arg-op', tool.op);
            btn.setAttribute('data-tooltip', alignTip(tool.name, 'Distribute'));
            btn.innerHTML = '<i class="ph ' + tool.icon + '"></i>';
            distributeGrid.appendChild(btn);
        });
    }

    // static tool buttons -> tooltips from the modifier matrix
    $$('[data-tool]').forEach(function (btn) {
        var key = btn.getAttribute('data-tip') || btn.getAttribute('data-tool'), d = TIPS[key];
        if (d && !btn.hasAttribute('data-tooltip')) { btn.setAttribute('data-tooltip', tipHTML(d.title, d.rows)); }
    });

    // ==========================================
    // SEGMENTED CONTROL (alignment target)
    // ==========================================
    var alignMode = clampInt(store('motionSeeds_align_mode'), 0, 3, 0);
    var segBtns = $$('.segmented-control .seg-btn');
    function setAlignMode(m) {
        alignMode = m;
        segBtns.forEach(function (b) { b.classList.toggle('active', parseInt(b.getAttribute('data-mode'), 10) === m); });
        store('motionSeeds_align_mode', String(m));
    }
    segBtns.forEach(function (btn) {
        btn.addEventListener('click', function () { setAlignMode(parseInt(this.getAttribute('data-mode'), 10) || 0); });
    });
    setAlignMode(alignMode);

    // ==========================================
    // STAGGER INPUTS
    // ==========================================
    var staggerFrames = $('stagger-frames'), staggerGroup = $('stagger-group');
    if (staggerFrames) { staggerFrames.value = clampInt(store('motionSeeds_stagger_frames'), 0, 9999, 5); staggerFrames.addEventListener('change', function () { this.value = clampInt(this.value, 0, 9999, 5); store('motionSeeds_stagger_frames', this.value); }); }
    if (staggerGroup) { staggerGroup.value = clampInt(store('motionSeeds_stagger_group'), 1, 999, 1); staggerGroup.addEventListener('change', function () { this.value = clampInt(this.value, 1, 999, 1); store('motionSeeds_stagger_group', this.value); }); }

    // ==========================================
    // COMMON ARGS SENT WITH EVERY ACTION
    // ==========================================
    var activeSwatch = clampInt(store('motionSeeds_active_swatch'), 0, 999, 0);
    function swatchHex(sw) {
        if (!sw) { return '#ff375f'; }
        if (sw.type === 'gradient') { var m = String(sw.value).match(/#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}/); return m ? m[0] : '#ffffff'; }
        return sw.value || '#ffffff';
    }
    function commonArgs() {
        var pal = (userPalette || []).map(swatchHex);
        return {
            color: swatchHex((userPalette || [])[Math.min(activeSwatch, (userPalette || []).length - 1)]),
            palette: pal,
            frames: staggerFrames ? clampInt(staggerFrames.value, 0, 9999, 5) : 5,
            group: staggerGroup ? clampInt(staggerGroup.value, 1, 999, 1) : 1,
            mode: alignMode
        };
    }
    function argsFromDataset(el) {
        var out = {}, k, v;
        for (k in el.dataset) {
            if (k.indexOf('arg') === 0 && k.length > 3) {
                v = el.dataset[k];
                out[k.charAt(3).toLowerCase() + k.slice(4)] = (v !== '' && !isNaN(v)) ? parseFloat(v) : v;
            }
        }
        return out;
    }

    // ==========================================
    // GLOBAL DRAG & DROP (SORTABLE) + LAYOUT PERSISTENCE
    // ==========================================
    var mainSortable = null;
    var innerSortables = [];
    var isEditMode = false;
    var panelContent = $('panel-content');

    function itemKey(el) {
        if (el.getAttribute('data-sort-row')) { return 'row:' + el.getAttribute('data-sort-row'); }
        var k = el.getAttribute('data-tool') || '', ds = argsFromDataset(el), p;
        for (p in ds) { k += '|' + p + '=' + ds[p]; }
        return k;
    }
    function saveGridOrder(grid) {
        var key = grid.getAttribute('data-sort-key');
        if (!key) { return; }
        store('motionSeeds_layout_' + key, JSON.stringify(Array.prototype.map.call(grid.children, itemKey)));
    }
    function restoreGridOrder(grid) {
        var key = grid.getAttribute('data-sort-key'), saved, map = {};
        if (!key) { return; }
        try { saved = JSON.parse(store('motionSeeds_layout_' + key) || 'null'); } catch (e) { saved = null; }
        if (!saved || !saved.length) { return; }
        Array.prototype.forEach.call(grid.children, function (c) { map[itemKey(c)] = c; });
        saved.forEach(function (k) { if (map[k]) { grid.appendChild(map[k]); delete map[k]; } });
        Object.keys(map).forEach(function (k) { grid.appendChild(map[k]); });
    }
    function restoreCardOrder() {
        var saved, footer = panelContent.querySelector('.footer-copyright');
        try { saved = JSON.parse(store('motionSeeds_layout_cards') || 'null'); } catch (e) { saved = null; }
        if (!saved || !saved.length) { return; }
        saved.forEach(function (id) {
            var card = panelContent.querySelector('.widget-card[data-id="' + id + '"]');
            if (card) { panelContent.insertBefore(card, footer); }
        });
    }
    if (panelContent) {
        restoreCardOrder();
        $$('.sortable-grid').forEach(restoreGridOrder);
        mainSortable = new Sortable(panelContent, {
            animation: 250,
            handle: '.drag-handle',
            ghostClass: 'sortable-ghost',
            dragClass: 'sortable-drag',
            filter: '.footer-copyright',
            onEnd: function () {
                store('motionSeeds_layout_cards', JSON.stringify($$('.widget-card', panelContent).map(function (c) { return c.getAttribute('data-id'); })));
            }
        });
    }
    $$('.sortable-grid').forEach(function (grid) {
        var sortable = new Sortable(grid, {
            animation: 200,
            disabled: true,
            ghostClass: 'sortable-ghost',
            onEnd: function () { saveGridOrder(grid); }
        });
        innerSortables.push(sortable);
    });

    $$('.edit-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var card = this.closest('.widget-card');
            var grid = card.querySelector('.sortable-grid');
            var icon = this.querySelector('i');
            var isEditingCard = card.classList.contains('edit-mode-active');
            var sortableInstance = innerSortables.filter(function (s) { return s.el === grid; })[0];
            if (isEditingCard) {
                card.classList.remove('edit-mode-active', 'jiggle-active');
                replaceClass(icon, 'ph-check', 'ph-pencil-simple');
                replaceClass(this, 'text-[#30d158]', 'text-white/30');
                if (sortableInstance) { sortableInstance.option('disabled', true); }
                isEditMode = $$('.widget-card.edit-mode-active').length > 0;
            } else {
                card.classList.add('edit-mode-active', 'jiggle-active');
                replaceClass(icon, 'ph-pencil-simple', 'ph-check');
                replaceClass(this, 'text-white/30', 'text-[#30d158]');
                if (sortableInstance) { sortableInstance.option('disabled', false); }
                isEditMode = true;
                hideTooltip();
            }
        });
    });

    // ==========================================
    // SMART EASING SLIDERS LOGIC (live, throttled)
    // ==========================================
    var sMaster = $('ease-master');
    var sIn = $('ease-in');
    var sOut = $('ease-out');
    var vMaster = $('val-master');
    var vIn = $('val-in');
    var vOut = $('val-out');
    var ease = { timer: null, pending: null, busy: false, errShown: false };

    function flushEase() {
        ease.timer = null;
        if (!ease.pending) { return; }
        if (ease.busy) { ease.timer = setTimeout(flushEase, 40); return; }
        var p = ease.pending;
        ease.pending = null;
        ease.busy = true;
        Host.run('ease', 'click', p, { silent: ease.errShown }).then(function (res) {
            ease.busy = false;
            if (!res.ok) { ease.errShown = true; }
        });
    }
    function scheduleEase(which, now) {
        ease.pending = { which: which, vin: parseFloat(sIn.value), vout: parseFloat(sOut.value) };
        if (now) { clearTimeout(ease.timer); flushEase(); return; }
        if (!ease.timer) { ease.timer = setTimeout(flushEase, 80); }
    }
    if (sMaster && sIn && sOut) {
        sMaster.addEventListener('input', function (e) {
            var val = e.target.value;
            vMaster.innerText = val;
            sIn.value = val; vIn.innerText = val;
            sOut.value = val; vOut.innerText = val;
            scheduleEase('master');
        });
        sIn.addEventListener('input', function (e) { vIn.innerText = e.target.value; scheduleEase('in'); });
        sOut.addEventListener('input', function (e) { vOut.innerText = e.target.value; scheduleEase('out'); });
        [sMaster, sIn, sOut].forEach(function (s) {
            s.addEventListener('mousedown', function () { ease.errShown = false; });
            s.addEventListener('change', function () { scheduleEase(s === sMaster ? 'master' : (s === sIn ? 'in' : 'out'), true); });
        });
    }

    // ==========================================
    // ACTION DISPATCH (click + modifier tier)
    // ==========================================
    function onAction(el, e) {
        if (isEditMode) { return; }
        e.preventDefault();
        hideTooltip();
        if (el.classList.contains('interp-icon')) {
            Host.run('interp', 'click', { type: el.getAttribute('data-interp') });
            return;
        }
        var tool = el.getAttribute('data-tool');
        if (!tool) { return; }
        Host.run(tool, tierOf(e), argsFromDataset(el));
    }
    document.addEventListener('click', function (e) {
        var el = e.target.closest ? e.target.closest('[data-tool], .interp-icon') : null;
        if (!el || !document.body.contains(el)) { return; }
        if (el.closest('#license-modal')) { return; }
        onAction(el, e);
    });
    document.addEventListener('contextmenu', function (e) {   // macOS Control+click arrives as contextmenu
        if (!IS_MAC || !e.ctrlKey) { return; }
        var el = e.target.closest ? e.target.closest('[data-tool], .interp-icon, [data-tk-index], [data-sw-index]') : null;
        if (!el) { return; }
        e.preventDefault();
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, ctrlKey: true, shiftKey: e.shiftKey, altKey: e.altKey, metaKey: false }));
    });

    var footerLink = $('footer-link');
    if (footerLink) {
        footerLink.addEventListener('click', function (e) { e.preventDefault(); csi.openURLInDefaultBrowser(this.href); });
    }

    // ==========================================
    // CUSTOM TOOLKIT SYSTEM
    // ==========================================
    var toolkitViewMode = $('toolkit-view-mode');
    var toolkitEditMode = $('toolkit-edit-mode');
    var toggleEditBtn = $('toggle-edit-toolkit');
    var saveToolkitBtn = $('save-toolkit-btn');
    var addToolkitBtn = $('add-toolkit-btn');
    var toolkitActions = $('toolkit-actions');
    var iconInput = $('icon-file-input');
    var iconTargetIndex = -1;

    var defaultPresets = [
        { name: 'My Template', type: 'aep', value: '', color: '#bf5af2', iconType: 'ph', icon: 'ph-folder-star', customIconBase64: '' },
        { name: 'Brand Red', type: 'color', value: '#FF375F', color: '#ff375f', iconType: 'ph', icon: 'ph-palette', customIconBase64: '' }
    ];
    var userPresets = defaultPresets.slice(0);
    var hadSavedToolkit = false;
    try {
        var saved = store('motionSeeds_toolkit_v4');
        if (saved) { userPresets = JSON.parse(saved); hadSavedToolkit = true; }
    } catch (err) {}
    var ICON_BY_TYPE = { ffx: 'ph-magic-wand', aep: 'ph-folder-star', jsx: 'ph-code', color: 'ph-palette' };

    function saveToolkit() {
        var json = JSON.stringify(userPresets);
        store('motionSeeds_toolkit_v4', json);
        Host.run('dataSave', 'click', { kind: 'toolkit', json: json }, { silent: true });
    }
    function toolkitTip(preset) {
        var tooltipDesc = '<b>' + esc(preset.name) + '</b>';
        if ((preset.value && String(preset.value).charAt(0) === '#') || preset.type === 'color') {
            tooltipDesc += "<div class='mod-row'><span class='mod-color'>Click:</span> Apply Color</div><div class='mod-row'><span class='mod-color'>Alt+Click:</span> Color Adjustment Layer</div><div class='mod-row'><span class='mod-color'>Shift+Click:</span> Clean Slate Apply</div><div class='mod-row'><span class='mod-color'>Ctrl+Click:</span> Color Keyframe at CTI</div><div class='mod-row'><span class='mod-color'>Ctrl+Alt:</span> Strip Expressions + Apply</div><div class='mod-row'><span class='mod-color'>Shift+Ctrl:</span> Select Layers by Label</div>";
        } else {
            tooltipDesc += "<div class='mod-row'><span class='mod-color'>Click:</span> Apply Preset</div><div class='mod-row'><span class='mod-color'>Alt+Click:</span> Add Adjustment Layer</div><div class='mod-row'><span class='mod-color'>Shift+Click:</span> Clean Slate Apply</div><div class='mod-row'><span class='mod-color'>Ctrl+Click:</span> Apply at CTI + Marker</div><div class='mod-row'><span class='mod-color'>Ctrl+Alt:</span> Apply & Strip Expressions</div><div class='mod-row'><span class='mod-color'>Shift+Ctrl:</span> Select Layers by Label</div>";
        }
        return tooltipDesc;
    }
    function renderToolkitView() {
        if (!toolkitViewMode) { return; }
        toolkitViewMode.innerHTML = '';
        userPresets.forEach(function (preset, index) {
            var btn = document.createElement('button');
            var isLinked = preset.value ? '<span class="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full" style="background-color: ' + esc(preset.color) + '; box-shadow: 0 0 4px ' + esc(preset.color) + '"></span>' : '';
            btn.className = 'glass-btn py-1.5 relative transition-colors duration-300';
            btn.style.color = 'rgba(255,255,255,0.7)';
            btn.setAttribute('data-tk-index', index);
            btn.onmouseenter = function () { btn.style.color = preset.color; };
            btn.onmouseleave = function () { btn.style.color = 'rgba(255,255,255,0.7)'; };
            btn.setAttribute('data-tooltip', toolkitTip(preset));
            if (preset.customIconBase64) {
                btn.innerHTML = '<img src="' + esc(preset.customIconBase64) + '" class="custom-icon w-[18px] h-[18px] object-contain pointer-events-none">' + isLinked;
            } else {
                btn.innerHTML = '<i class="ph ' + esc(preset.icon || 'ph-wrench') + ' text-[18px]"></i>' + isLinked;
            }
            btn.addEventListener('click', function (e) {
                if (isEditMode) { return; }
                e.preventDefault();
                hideTooltip();
                Host.run('toolkit', tierOf(e), { item: { name: preset.name, type: preset.type, value: preset.type === 'color' ? (preset.value || preset.color) : preset.value, color: preset.color } });
            });
            toolkitViewMode.appendChild(btn);
        });
        attachTooltipEvents();
    }
    function syncToolkitInputs() {
        userPresets.forEach(function (preset, index) {
            var nameInput = $('preset-name-' + index);
            var colorInput = $('preset-color-' + index);
            if (nameInput) { preset.name = nameInput.value; }
            if (colorInput) { preset.color = colorInput.value; }
            if (preset.type === 'color') { preset.value = preset.color; }
        });
    }
    function renderToolkitEdit() {
        if (!toolkitEditMode) { return; }
        toolkitEditMode.innerHTML = '';
        userPresets.forEach(function (preset, index) {
            var row = document.createElement('div');
            var linkTitle = preset.type === 'color' ? 'Solid color item' : (preset.value ? 'Linked: ' + preset.value : 'Not linked');
            row.className = 'flex flex-col gap-1 mb-2 bg-black/10 p-1.5 rounded-[8px] border border-white/5 relative group';
            row.innerHTML =
                '<div class="flex items-center gap-1.5">' +
                    '<div class="flex flex-col gap-0.5 opacity-30 hover:opacity-100 transition-opacity">' +
                        '<i class="ph ph-caret-up text-[10px] cursor-pointer hover:text-[#0a84ff]" data-move="-1" data-index="' + index + '"></i>' +
                        '<i class="ph ph-caret-down text-[10px] cursor-pointer hover:text-[#0a84ff]" data-move="1" data-index="' + index + '"></i>' +
                    '</div>' +
                    '<div class="relative w-5 h-5 shrink-0 rounded-full overflow-hidden border border-white/20 cursor-pointer">' +
                        '<input type="color" id="preset-color-' + index + '" value="' + esc(preset.color) + '" class="absolute -top-2 -left-2 w-10 h-10 cursor-pointer">' +
                    '</div>' +
                    '<input type="text" id="preset-name-' + index + '" value="' + esc(preset.name) + '" class="flex-1 bg-black/20 text-white text-[11px] px-2 py-1.5 rounded-[6px] border border-white/10 focus:outline-none focus:border-[#0a84ff]/50 shadow-inner">' +
                    '<button class="upload-file-btn bg-black/30 hover:bg-black/50 ' + (preset.value ? 'text-[#30d158]' : 'text-white/60') + ' hover:text-[#0a84ff] w-7 h-7 rounded-[6px] border border-white/10 flex items-center justify-center transition-colors shrink-0" data-index="' + index + '" title="' + esc(linkTitle) + '  (Click: link .ffx/.aep/.jsx  |  Alt+Click: make solid-color item)">' +
                        '<i class="ph ph-link text-[14px]"></i>' +
                    '</button>' +
                    '<button class="upload-icon-btn bg-black/30 hover:bg-black/50 text-white/60 hover:text-[#ff9f0a] w-7 h-7 rounded-[6px] border border-white/10 flex items-center justify-center transition-colors shrink-0" data-index="' + index + '" title="Custom icon">' +
                        (preset.customIconBase64 ? '<img src="' + esc(preset.customIconBase64) + '" class="w-4 h-4 object-contain pointer-events-none">' : '<i class="ph ph-image text-[14px]"></i>') +
                    '</button>' +
                    '<button class="delete-preset-btn bg-black/30 hover:bg-[#ff375f]/20 text-white/40 hover:text-[#ff375f] w-7 h-7 rounded-[6px] border border-white/10 flex items-center justify-center transition-colors shrink-0" data-index="' + index + '" title="Delete">' +
                        '<i class="ph ph-trash text-[14px]"></i>' +
                    '</button>' +
                '</div>';
            toolkitEditMode.appendChild(row);
        });
    }
    window.moveToolkitItem = function (index, direction) {
        if (index + direction < 0 || index + direction >= userPresets.length) { return; }
        syncToolkitInputs();
        var temp = userPresets[index];
        userPresets[index] = userPresets[index + direction];
        userPresets[index + direction] = temp;
        renderToolkitEdit();
    };
    if (toolkitEditMode) {
        toolkitEditMode.addEventListener('click', function (e) {
            var mv = e.target.closest('[data-move]'), del = e.target.closest('.delete-preset-btn'), up = e.target.closest('.upload-icon-btn'), link = e.target.closest('.upload-file-btn'), idx;
            if (mv) { window.moveToolkitItem(parseInt(mv.getAttribute('data-index'), 10), parseInt(mv.getAttribute('data-move'), 10)); return; }
            if (del) {
                syncToolkitInputs();
                idx = parseInt(del.getAttribute('data-index'), 10);
                var rm = userPresets.splice(idx, 1)[0];
                if (rm && rm.value && String(rm.value).indexOf('assets/') === 0) {
                    var ign = [];
                    try { ign = JSON.parse(store('motionSeeds_toolkit_ignored') || '[]'); } catch (x) {}
                    if (ign.indexOf(rm.value) === -1) { ign.push(rm.value); store('motionSeeds_toolkit_ignored', JSON.stringify(ign)); }
                }
                renderToolkitEdit();
                return;
            }
            if (up) { syncToolkitInputs(); iconTargetIndex = parseInt(up.getAttribute('data-index'), 10); if (iconInput) { iconInput.value = ''; iconInput.click(); } return; }
            if (link) {
                syncToolkitInputs();
                idx = parseInt(link.getAttribute('data-index'), 10);
                var preset = userPresets[idx];
                if (!preset) { return; }
                if (e.altKey) {
                    preset.type = 'color'; preset.value = preset.color;
                    if (!preset.customIconBase64 && (!preset.icon || preset.icon === 'ph-wrench')) { preset.icon = 'ph-palette'; }
                    renderToolkitEdit();
                    return;
                }
                Host.run('assetLink', 'click', {}).then(function (res) {
                    if (!res.ok || !res.data || res.data.cancelled) { return; }
                    preset.value = res.data.value;
                    preset.type = res.data.type;
                    if (!preset.name || preset.name === 'New Tool') { preset.name = res.data.name; }
                    if (!preset.customIconBase64 && (!preset.icon || preset.icon === 'ph-wrench' || preset.icon === 'ph-palette')) { preset.icon = ICON_BY_TYPE[res.data.type] || 'ph-wrench'; }
                    renderToolkitEdit();
                });
            }
        });
    }
    if (iconInput) {
        iconInput.addEventListener('change', function () {
            var f = iconInput.files && iconInput.files[0];
            if (!f || iconTargetIndex < 0 || !userPresets[iconTargetIndex]) { return; }
            var reader = new FileReader();
            reader.onload = function () {
                var img = new Image();
                img.onload = function () {
                    var c = document.createElement('canvas'), s = 64, r = Math.min(s / img.width, s / img.height, 1);
                    c.width = Math.max(1, Math.round(img.width * r)); c.height = Math.max(1, Math.round(img.height * r));
                    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
                    userPresets[iconTargetIndex].customIconBase64 = c.toDataURL('image/png');
                    renderToolkitEdit();
                };
                img.onerror = function () { showToast('Unsupported image file.', 'error'); };
                img.src = reader.result;
            };
            reader.readAsDataURL(f);
        });
    }
    if (toggleEditBtn) {
        toggleEditBtn.addEventListener('click', function () {
            var isEditing = !toolkitViewMode.classList.contains('hidden');
            if (isEditing) {
                toolkitViewMode.classList.add('hidden');
                toolkitEditMode.classList.remove('hidden');
                toolkitActions.classList.remove('hidden');
                renderToolkitEdit();
                toggleEditBtn.innerHTML = '<i class="ph ph-x text-[14px]"></i>';
                replaceClass(toggleEditBtn, 'hover:text-[#0a84ff]', 'hover:text-[#ff375f]');
            } else {
                toolkitViewMode.classList.remove('hidden');
                toolkitEditMode.classList.add('hidden');
                toolkitActions.classList.add('hidden');
                toggleEditBtn.innerHTML = '<i class="ph ph-pencil-simple text-[14px]"></i>';
                replaceClass(toggleEditBtn, 'hover:text-[#ff375f]', 'hover:text-[#0a84ff]');
                try { userPresets = JSON.parse(store('motionSeeds_toolkit_v4') || 'null') || userPresets; } catch (e) {}
                renderToolkitView();
            }
        });
    }
    if (addToolkitBtn) {
        addToolkitBtn.addEventListener('click', function () {
            syncToolkitInputs();
            userPresets.push({ name: 'New Tool', type: 'custom', value: '', color: '#ffffff', iconType: 'ph', icon: 'ph-wrench', customIconBase64: '' });
            renderToolkitEdit();
        });
    }
    if (saveToolkitBtn) {
        saveToolkitBtn.addEventListener('click', function () {
            syncToolkitInputs();
            saveToolkit();
            renderToolkitView();
            if (toggleEditBtn) { toggleEditBtn.click(); }
        });
    }

    // ==========================================
    // DYNAMIC CUSTOM PALETTE SYSTEM
    // ==========================================
    var paletteViewMode = $('palette-view-mode');
    var paletteEditMode = $('palette-edit-mode');
    var toggleEditPaletteBtn = $('toggle-edit-palette');
    var savePaletteBtn = $('save-palette-btn');
    var addPaletteBtn = $('add-palette-btn');
    var paletteActions = $('palette-actions');

    var defaultPalette = [
        { name: 'Coral Rose', value: '#ff375f', type: 'solid' },
        { name: 'Sunset Gold', value: '#ff9f0a', type: 'solid' },
        { name: 'Emerald', value: '#30d158', type: 'solid' },
        { name: 'Cyan Sky', value: '#32ade6', type: 'solid' },
        { name: 'Royal Purple', value: '#bf5af2', type: 'solid' }
    ];
    var userPalette = defaultPalette.slice(0);
    var hadSavedPalette = false;
    try {
        var savedPalette = store('motionSeeds_palette_v1');
        if (savedPalette) { userPalette = JSON.parse(savedPalette); hadSavedPalette = true; }
    } catch (err) {}

    function savePalette() {
        var json = JSON.stringify(userPalette);
        store('motionSeeds_palette_v1', json);
        Host.run('dataSave', 'click', { kind: 'palette', json: json }, { silent: true });
    }
    function hexToHsl(hex) {
        var n = parseInt(hex.replace('#', ''), 16), r = ((n >> 16) & 255) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
        var mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
        if (d) { s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : (mx === g ? (b - r) / d + 2 : (r - g) / d + 4); h /= 6; }
        return [h, s, l];
    }
    function hslToHex(h, s, l) {
        var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
        function f(t) { if (t < 0) { t += 1; } if (t > 1) { t -= 1; } if (t < 1 / 6) { return p + (q - p) * 6 * t; } if (t < 1 / 2) { return q; } if (t < 2 / 3) { return p + (q - p) * (2 / 3 - t) * 6; } return p; }
        var c = s === 0 ? [l, l, l] : [f(h + 1 / 3), f(h), f(h - 1 / 3)];
        return '#' + c.map(function (v) { var x = Math.round(v * 255).toString(16); return x.length < 2 ? '0' + x : x; }).join('');
    }
    function swatchClick(index, e) {
        if (isEditMode) { return; }
        e.preventDefault();
        hideTooltip();
        var sw = userPalette[index], mod = tierOf(e);
        if (!sw) { return; }
        activeSwatch = index;
        store('motionSeeds_active_swatch', String(index));
        markActiveSwatch();
        if (mod === 'shiftCtrl') {      // randomize palette hues (panel side)
            userPalette.forEach(function (s) {
                if (s.type === 'gradient') { return; }
                var hsl = hexToHsl(swatchHex(s));
                s.value = hslToHex(Math.random(), Math.max(0.45, hsl[1]), Math.min(0.7, Math.max(0.35, hsl[2])));
            });
            savePalette(); renderPaletteView();
            return;
        }
        Host.run('swatch', mod, { hex: swatchHex(sw), name: sw.name, slot: index }).then(function (res) {
            if (!res.ok || !res.data) { return; }
            if (mod === 'alt' && typeof res.data === 'string') {
                userPalette[index] = { name: sw.name, value: res.data, type: 'solid' };
                savePalette(); renderPaletteView();
            } else if (mod === 'ctrl' && res.data.length) {
                res.data.forEach(function (hex, i) {
                    if (userPalette[i]) { userPalette[i] = { name: userPalette[i].name, value: hex, type: 'solid' }; }
                    else { userPalette.push({ name: 'Extracted ' + (i + 1), value: hex, type: 'solid' }); }
                });
                savePalette(); renderPaletteView();
            }
        });
    }
    function markActiveSwatch() {
        if (!paletteViewMode) { return; }
        Array.prototype.forEach.call(paletteViewMode.children, function (b, i) { b.classList.toggle('swatch-active', i === activeSwatch); });
    }
    function renderPaletteView() {
        if (!paletteViewMode) { return; }
        paletteViewMode.innerHTML = '';
        if (activeSwatch >= userPalette.length) { activeSwatch = 0; }
        userPalette.forEach(function (swatch, index) {
            var btn = document.createElement('button');
            btn.className = 'glass-btn py-1.5 relative transition-transform hover:scale-105 duration-200';
            btn.setAttribute('data-sw-index', index);
            btn.setAttribute('data-tooltip', tipHTML(swatch.name, [['Click', 'Apply Color (Fill / Text)'], ['Alt+Click', 'Pick to Swatch'], ['Shift+Click', 'Apply to Stroke Only'], ['Ctrl+Click', 'Auto-Extract Palette'], ['Ctrl+Alt', 'Link to Color Control'], ['Shift+Ctrl', 'Randomize Palette Hues']]));
            var innerBox = document.createElement('div');
            innerBox.className = 'w-5 h-5 rounded-full border border-white/30 shadow-md';
            if (swatch.type === 'gradient') { innerBox.style.background = swatch.value; }
            else { innerBox.style.backgroundColor = swatch.value; }
            btn.appendChild(innerBox);
            btn.addEventListener('click', function (e) { swatchClick(index, e); });
            paletteViewMode.appendChild(btn);
        });
        markActiveSwatch();
        attachTooltipEvents();
    }
    function syncPaletteInputs() {
        userPalette.forEach(function (swatch, index) {
            var nameInput = $('palette-name-' + index);
            var valInput = $('palette-val-' + index);
            if (nameInput) { swatch.name = nameInput.value; }
            if (valInput && (swatch.type !== 'gradient' || valInput.getAttribute('data-touched'))) { swatch.value = valInput.value; swatch.type = 'solid'; }
        });
    }
    function renderPaletteEdit() {
        if (!paletteEditMode) { return; }
        paletteEditMode.innerHTML = '';
        userPalette.forEach(function (swatch, index) {
            var row = document.createElement('div');
            row.className = 'flex items-center gap-1.5 mb-2 bg-black/10 p-1.5 rounded-[8px] border border-white/5 relative';
            row.innerHTML =
                '<div class="relative w-6 h-6 shrink-0 rounded-full overflow-hidden border border-white/20 cursor-pointer">' +
                    '<input type="color" id="palette-val-' + index + '" value="' + esc(swatch.type === 'solid' ? swatch.value : '#30d158') + '" class="absolute -top-2 -left-2 w-12 h-12 cursor-pointer">' +
                '</div>' +
                '<input type="text" id="palette-name-' + index + '" value="' + esc(swatch.name) + '" class="flex-1 bg-black/20 text-white text-[11px] px-2 py-1.5 rounded-[6px] border border-white/10 focus:outline-none focus:border-[#0a84ff]/50 shadow-inner">' +
                '<button class="delete-swatch-btn bg-black/30 hover:bg-[#ff375f]/20 text-white/40 hover:text-[#ff375f] w-7 h-7 rounded-[6px] border border-white/10 flex items-center justify-center transition-colors shrink-0" data-index="' + index + '">' +
                    '<i class="ph ph-trash text-[14px]"></i>' +
                '</button>';
            paletteEditMode.appendChild(row);
            var ci = row.querySelector('input[type=color]');
            ci.addEventListener('input', function () { ci.setAttribute('data-touched', '1'); });
        });
        attachPaletteEditListeners();
    }
    function attachPaletteEditListeners() {
        $$('.delete-swatch-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                syncPaletteInputs();
                var idx = parseInt(this.getAttribute('data-index'), 10);
                userPalette.splice(idx, 1);
                renderPaletteEdit();
            });
        });
    }
    if (toggleEditPaletteBtn) {
        toggleEditPaletteBtn.addEventListener('click', function () {
            var isEditing = !paletteViewMode.classList.contains('hidden');
            if (isEditing) {
                paletteViewMode.classList.add('hidden');
                paletteEditMode.classList.remove('hidden');
                paletteActions.classList.remove('hidden');
                renderPaletteEdit();
                toggleEditPaletteBtn.innerHTML = '<i class="ph ph-x text-[14px]"></i>';
                replaceClass(toggleEditPaletteBtn, 'hover:text-[#0a84ff]', 'hover:text-[#ff375f]');
            } else {
                paletteViewMode.classList.remove('hidden');
                paletteEditMode.classList.add('hidden');
                paletteActions.classList.add('hidden');
                toggleEditPaletteBtn.innerHTML = '<i class="ph ph-pencil-simple text-[14px]"></i>';
                replaceClass(toggleEditPaletteBtn, 'hover:text-[#ff375f]', 'hover:text-[#0a84ff]');
                try { userPalette = JSON.parse(store('motionSeeds_palette_v1') || 'null') || userPalette; } catch (e) {}
                renderPaletteView();
            }
        });
    }
    if (addPaletteBtn) {
        addPaletteBtn.addEventListener('click', function () {
            syncPaletteInputs();
            userPalette.push({ name: 'New Swatch', value: '#32ade6', type: 'solid' });
            renderPaletteEdit();
        });
    }
    if (savePaletteBtn) {
        savePaletteBtn.addEventListener('click', function () {
            syncPaletteInputs();
            savePalette();
            renderPaletteView();
            if (toggleEditPaletteBtn) { toggleEditPaletteBtn.click(); }
        });
    }

    // ==========================================
    // STRICT 700ms HOVER TOOLTIP SYSTEM
    // ==========================================
    var customTooltipDiv = document.createElement('div');
    customTooltipDiv.id = 'custom-tooltip';
    document.body.appendChild(customTooltipDiv);
    var hoverTimer;

    function hideTooltip() {
        clearTimeout(hoverTimer);
        if (customTooltipDiv) { customTooltipDiv.classList.remove('show'); }
    }

    function attachTooltipEvents() {
        $$('[data-tooltip]').forEach(function (el) {
            if (el.dataset.tooltipBound) { return; }
            el.dataset.tooltipBound = 'true';
            if (el.hasAttribute('title')) { el.removeAttribute('title'); }

            el.addEventListener('mouseenter', function () {
                if (isEditMode) { return; }
                clearTimeout(hoverTimer);
                hoverTimer = setTimeout(function () {
                    if (!customTooltipDiv) { return; }
                    customTooltipDiv.innerHTML = el.getAttribute('data-tooltip') || '';
                    var rect = el.getBoundingClientRect();
                    var left = rect.left + (rect.width / 2);
                    var top = rect.top - 10;

                    customTooltipDiv.style.left = left + 'px';
                    customTooltipDiv.style.top = top + 'px';
                    customTooltipDiv.classList.add('show');

                    setTimeout(function () {
                        if (!customTooltipDiv) { return; }
                        var tRect = customTooltipDiv.getBoundingClientRect();
                        if (tRect.top < 0) { customTooltipDiv.style.top = (rect.bottom + tRect.height + 10) + 'px'; }
                        if (tRect.left < 5) { customTooltipDiv.style.left = (tRect.width / 2 + 15) + 'px'; }
                        else if (tRect.right > window.innerWidth - 5) { customTooltipDiv.style.left = (window.innerWidth - (tRect.width / 2) - 15) + 'px'; }
                    }, 10);
                }, 700);
            });

            el.addEventListener('mouseleave', hideTooltip);
            el.addEventListener('mousedown', hideTooltip);
            el.addEventListener('click', hideTooltip);
        });
    }

    // ==========================================
    // SNAPSHOT POST-PROCESSING (JPEG / alpha trim, done with canvas + Node fs)
    // ==========================================
    function fileUrl(p) { p = String(p).replace(/\\/g, '/'); return 'file:///' + encodeURI(p.replace(/^\/+/, '')).replace(/#/g, '%23').replace(/\?/g, '%3F'); }
    function postSnapshot(d) {
        if (!d || !d.post) { return; }
        var fs = null;
        try { fs = nodeRequire ? nodeRequire('fs') : null; } catch (e) { fs = null; }
        if (!fs) { showToast('JPEG / trimmed snapshots need Node.js (enabled in the manifest). PNG kept at: ' + d.src, 'error'); return; }
        var img = new Image();
        img.onload = function () {
            var c = document.createElement('canvas'), x = 0, y = 0, w = img.width, h = img.height, ctx, data, i, minX = w, minY = h, maxX = -1, maxY = -1, px, py, out, b64;
            c.width = w; c.height = h;
            ctx = c.getContext('2d');
            if (d.post === 'jpeg') {
                ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
                ctx.drawImage(img, 0, 0);
                b64 = c.toDataURL('image/jpeg', 0.85);
            } else {
                ctx.drawImage(img, 0, 0);
                data = ctx.getImageData(0, 0, w, h).data;
                for (i = 3; i < data.length; i += 4) {
                    if (data[i] > 2) { px = ((i - 3) / 4) % w; py = Math.floor(((i - 3) / 4) / w); if (px < minX) { minX = px; } if (px > maxX) { maxX = px; } if (py < minY) { minY = py; } if (py > maxY) { maxY = py; } }
                }
                if (maxX < 0) { showToast('The frame is fully transparent.', 'error'); return; }
                x = minX; y = minY; w = maxX - minX + 1; h = maxY - minY + 1;
                out = document.createElement('canvas'); out.width = w; out.height = h;
                out.getContext('2d').drawImage(c, x, y, w, h, 0, 0, w, h);
                b64 = out.toDataURL('image/png');
            }
            try {
                var B = (window.cep_node && window.cep_node.Buffer) ? window.cep_node.Buffer : window.Buffer;
                if (!B && nodeRequire) { B = nodeRequire('buffer').Buffer; }
                fs.writeFileSync(d.dst, B.from ? B.from(b64.split(',')[1], 'base64') : new B(b64.split(',')[1], 'base64'));
                try { fs.unlinkSync(d.src); } catch (e3) {}
                showToast('Saved: ' + d.dst, 'info');
            } catch (e2) { showToast('Could not write ' + d.dst + ': ' + e2.message, 'error'); }
        };
        img.onerror = function () { showToast('Could not read the snapshot image.', 'error'); };
        try { img.src = 'data:image/png;base64,' + fs.readFileSync(d.src).toString('base64'); }
        catch (e4) { img.src = fileUrl(d.src) + '?t=' + Date.now(); }
    }
    var _run = Host.run;
    Host.run = function (tool, mod, args, opt) {
        return _run(tool, mod, args, opt).then(function (res) {
            if (tool === 'snapshot' && res.ok && res.data && res.data.post) { postSnapshot(res.data); }
            return res;
        });
    };

    // ==========================================
    // ASSET SYNC (assets/ffx, assets/aep, assets/color)
    // ==========================================
    function syncAssets() {
        var tasks = [];
        if (!hadSavedToolkit) {
            tasks.push(Host.run('dataLoad', 'click', { kind: 'toolkit' }, { silent: true }).then(function (res) {
                if (res.ok && res.data) { try { var arr = JSON.parse(res.data); if (arr && arr.length) { userPresets = arr; store('motionSeeds_toolkit_v4', res.data); } } catch (e) {} }
            }));
        }
        if (!hadSavedPalette) {
            tasks.push(Host.run('dataLoad', 'click', { kind: 'palette' }, { silent: true }).then(function (res) {
                if (res.ok && res.data) { try { var arr = JSON.parse(res.data); if (arr && arr.length) { userPalette = arr; store('motionSeeds_palette_v1', res.data); } } catch (e) {} }
            }));
        }
        return Promise.all(tasks).then(function () {
            return Host.run('assetList', 'click', {}, { silent: true });
        }).then(function (res) {
            var ign = [], added = 0;
            try { ign = JSON.parse(store('motionSeeds_toolkit_ignored') || '[]'); } catch (e) {}
            if (res.ok && res.data && res.data.length) {
                res.data.forEach(function (a) {
                    var exists = userPresets.some(function (p) { return p.value === a.value; });
                    if (!exists && ign.indexOf(a.value) === -1) {
                        userPresets.push({ name: a.name, type: a.type, value: a.value, color: a.type === 'aep' ? '#bf5af2' : '#32ade6', iconType: 'ph', icon: ICON_BY_TYPE[a.type] || 'ph-wrench', customIconBase64: '' });
                        added++;
                    }
                });
            }
            if (added) { store('motionSeeds_toolkit_v4', JSON.stringify(userPresets)); }
            renderToolkitView();
            renderPaletteView();
        });
    }

    // ==========================================
    // BOOT
    // ==========================================
    renderToolkitView();
    renderPaletteView();
    attachTooltipEvents();
    hostReady().then(function (ok) { if (ok) { return syncAssets(); } return null; });
    checkLicenseStatus();
});
