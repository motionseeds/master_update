/* =====================================================================
 * Master by MotionSeeds - js/updater.js  (silent auto-updater)
 * After Effects CC 2018+  |  CEP 8+  |  Node.js enabled (mixed context)
 *
 * Flow
 *   1. Panel opens  -> fetch update.json (cache-busted) and compare versions.
 *   2. Newer found  -> un-hide the banner "New Update Available (vX.X.X)".
 *                      No alerts, no pop-ups; any failure is silent.
 *   3. "Update Now" -> overlay -> download update.zip -> (verify sha256)
 *                      -> save to the extension folder -> adm-zip extract
 *                      (overwrite = true) -> install -> delete zip
 *                      -> reload the ExtendScript host -> location.reload().
 *
 * Written for the Node.js bundled with CEP 8 (Node 8.6) and newer, so it avoids
 * fs.promises, fs.mkdirSync({recursive}), fs.rmSync, optional chaining, etc.
 *
 * Loaded by index.html right before js/main.js. Settings: section 1 below.
 * ===================================================================== */
(function (window, document) {
    'use strict';

    /* ------------------------------------------------------------------
     * 1. CONFIG  (window.MS_UPDATER_CONFIG = {...} before this file overrides any key)
     * ------------------------------------------------------------------ */
    var CONFIG = {
        UPDATE_JSON_URL: 'https://raw.githubusercontent.com/motionseeds/master_update/main/update.json',
        HOST_SCRIPT: 'jsx/hostscript.jsx',      // re-loaded into ExtendScript after updating
        ZIP_NAME: 'update.zip',                 // temporary download (inside the extension folder)
        STAGING_DIR: '.update_staging',         // temporary extraction folder
        BACKUP_DIR: '.update_backup',           // previous files, used to roll back a failed install
        REQUIRED_FILE: 'CSXS/manifest.xml',     // a valid update package must contain this file
        PRESERVE_IF_EXISTS: [                   // user data an update must never overwrite
            'assets/color/toolkit.json',
            'assets/color/palette.json'
        ],
        CHECK_DELAY_MS: 1500,                   // let the panel finish loading first
        JSON_TIMEOUT_MS: 15000,
        DOWNLOAD_TIMEOUT_MS: 300000,
        MAX_REDIRECTS: 5,
        REQUIRE_HTTPS: true,
        EXT_ROOT: '',                           // leave empty: detected via CSInterface
        DEBUG: false                            // true = log every step to the CEP devtools console
    };
    (function applyOverrides(o) {
        var k;
        if (!o || typeof o !== 'object') { return; }
        for (k in o) { if (Object.prototype.hasOwnProperty.call(o, k)) { CONFIG[k] = o[k]; } }
    }(window.MS_UPDATER_CONFIG));

    var JUNK = /(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db|desktop\.ini|\.git)(\/|$)/i;

    function log() {
        if (!CONFIG.DEBUG || !window.console) { return; }
        var a = Array.prototype.slice.call(arguments);
        a.unshift('[MS Updater]');
        window.console.log.apply(window.console, a);
    }

    function userError(msg) { var e = new Error(msg); e.userMessage = msg; return e; }

    /* ------------------------------------------------------------------
     * 2. NODE.JS ACCESS  (mixed context: require is global;
     *    separate context (CEP 8+ default): window.cep_node.require)
     * ------------------------------------------------------------------ */
    var nodeRequire = (window.cep_node && window.cep_node.require) ? window.cep_node.require
        : (typeof window.require === 'function' ? window.require : null);
    var NodeBuffer = (window.cep_node && window.cep_node.Buffer) ? window.cep_node.Buffer : window.Buffer;
    var Node = null;

    function loadNode() {
        if (Node) { return Node; }
        if (!nodeRequire || !NodeBuffer) { return null; }
        try {
            Node = {
                fs: nodeRequire('fs'),
                path: nodeRequire('path'),
                url: nodeRequire('url'),
                http: nodeRequire('http'),
                https: nodeRequire('https'),
                crypto: nodeRequire('crypto')
            };
        } catch (e) {
            log('Node.js modules unavailable', e);
            Node = null;
        }
        return Node;
    }

    function join() { return Node.path.join.apply(Node.path, arguments); }

    /* ------------------------------------------------------------------
     * 3. CEP HELPERS
     * ------------------------------------------------------------------ */
    function extensionRoot() {
        var p = CONFIG.EXT_ROOT || '';
        try {
            if (!p && typeof window.CSInterface === 'function') {
                p = new window.CSInterface().getSystemPath(window.SystemPath ? window.SystemPath.EXTENSION : 'extension');
            }
            if (!p && window.__adobe_cep__) {
                p = decodeURI(window.__adobe_cep__.getSystemPath('extension'));
                p = /^file:\/\/\/[A-Za-z]:/.test(p) ? p.substr(8) : p.replace(/^file:\/\//, '');
            }
        } catch (e) { log('getSystemPath failed', e); }
        return p ? Node.path.normalize(p) : '';
    }

    function evalScript(script, cb) {
        try {
            if (typeof window.CSInterface === 'function' && window.__adobe_cep__) { new window.CSInterface().evalScript(script, cb); return; }
            if (window.__adobe_cep__) { window.__adobe_cep__.evalScript(script, cb); return; }
        } catch (e) { log('evalScript failed', e); }
        if (cb) { setTimeout(function () { cb('EvalScript error.'); }, 0); }
    }

    /* ------------------------------------------------------------------
     * 4. VERSIONS
     * ------------------------------------------------------------------ */
    /* The manifest holds two version numbers (ExtensionBundleVersion and
       <Extension ... Version>). Use the higher one, so bumping either works. */
    function localVersion(root) {
        try {
            var xml = Node.fs.readFileSync(join(root, 'CSXS', 'manifest.xml'), 'utf8');
            var a = /ExtensionBundleVersion\s*=\s*"([^"]+)"/.exec(xml);
            var b = /<Extension\s[^>]*\bVersion\s*=\s*"([^"]+)"/.exec(xml);
            var va = a ? a[1] : '0.0.0', vb = b ? b[1] : '0.0.0';
            return compareVersions(va, vb) >= 0 ? va : vb;
        } catch (e) {
            return '0.0.0';
        }
    }

    /* Loop guard: remember the release that was installed. If its package turns out to
       carry a lower version than update.json announced, the banner is not shown again
       for that same release (a new release - other version, zip or checksum - still shows). */
    var GUARD_KEY = 'msUpdater.installedRelease';
    function releaseId(info) { return info.version + '|' + (info.sha256 || info.url); }
    function rememberInstall(info) { try { window.localStorage.setItem(GUARD_KEY, releaseId(info)); } catch (e) { /* ignore */ } }
    function alreadyInstalled(info) { try { return window.localStorage.getItem(GUARD_KEY) === releaseId(info); } catch (e) { return false; } }

    /* 1 if a > b, -1 if a < b, 0 if equal.  "1.0.10" > "1.0.9";  "v1.2" == "1.2.0" */
    function compareVersions(a, b) {
        var pa = String(a).replace(/^v/i, '').split(/[-+]/)[0].split('.');
        var pb = String(b).replace(/^v/i, '').split(/[-+]/)[0].split('.');
        var n = Math.max(pa.length, pb.length), i, x, y;
        for (i = 0; i < n; i++) {
            x = parseInt(pa[i], 10); y = parseInt(pb[i], 10);
            if (isNaN(x)) { x = 0; }
            if (isNaN(y)) { y = 0; }
            if (x !== y) { return x > y ? 1 : -1; }
        }
        return 0;
    }

    function validateInfo(info) {
        var v, url, sha;
        if (!info || typeof info !== 'object') { throw new Error('update.json is not a JSON object'); }
        v = String(info.version || '').replace(/^v/i, '');
        if (!/^\d+(\.\d+){0,3}([-+][0-9A-Za-z.-]+)?$/.test(v)) { throw new Error('update.json: invalid "version"'); }
        url = String(info.url || info.zipUrl || '');            // "zipUrl" accepted as an alias
        if (!/^https?:\/\//i.test(url)) { throw new Error('update.json: "url" is missing'); }
        if (CONFIG.REQUIRE_HTTPS && !/^https:\/\//i.test(url)) { throw new Error('update.json: "url" must use https'); }
        sha = info.sha256 ? String(info.sha256).toLowerCase() : '';
        if (sha && !/^[0-9a-f]{64}$/.test(sha)) { throw new Error('update.json: invalid "sha256"'); }
        return { version: v, url: url, sha256: sha, notes: info.notes ? String(info.notes) : '' };
    }

    /* ------------------------------------------------------------------
     * 5. NETWORK  (fetch first; Node https as fallback when fetch is
     *    blocked by CORS/redirects - Node requests have no CORS)
     * ------------------------------------------------------------------ */
    function bust(url) {   // defeat CEF + GitHub CDN caching
        return url + (url.indexOf('?') === -1 ? '?' : '&') + 't=' + new Date().getTime();
    }

    function httpError(status, url) {
        var e = new Error('HTTP ' + status + ' for ' + url);
        e.httpStatus = status;
        return e;
    }

    function withTimeout(promise, ms, label) {
        return new Promise(function (resolve, reject) {
            var done = false;
            var timer = setTimeout(function () {
                if (!done) { done = true; reject(new Error(label + ' timed out')); }
            }, ms);
            promise.then(function (v) {
                if (!done) { done = true; clearTimeout(timer); resolve(v); }
            }, function (e) {
                if (!done) { done = true; clearTimeout(timer); reject(e); }
            });
        });
    }

    function fetchBuffer(url, onProgress) {
        if (typeof window.fetch !== 'function') { return Promise.reject(new Error('fetch is not available')); }
        // No custom request headers on purpose: they would trigger a CORS pre-flight.
        return window.fetch(url, { cache: 'no-store', credentials: 'omit', redirect: 'follow' }).then(function (res) {
            if (!res.ok) { throw httpError(res.status, url); }
            var total = parseInt(res.headers.get('content-length'), 10) || 0;
            if (!res.body || typeof res.body.getReader !== 'function') {
                return res.arrayBuffer().then(function (ab) {
                    if (onProgress) { onProgress(1); }
                    return NodeBuffer.from(new Uint8Array(ab));
                });
            }
            var reader = res.body.getReader(), chunks = [], received = 0;
            function pump() {
                return reader.read().then(function (r) {
                    if (r.done) { return NodeBuffer.concat(chunks, received); }
                    chunks.push(NodeBuffer.from(r.value));
                    received += r.value.length;
                    if (onProgress && total) { onProgress(Math.min(1, received / total)); }
                    return pump();
                });
            }
            return pump();
        });
    }

    function nodeBuffer(url, onProgress, redirects) {
        redirects = redirects || 0;
        return new Promise(function (resolve, reject) {
            var opts = Node.url.parse(url), lib = /^https:/i.test(url) ? Node.https : Node.http, req;
            opts.headers = { 'User-Agent': 'MotionSeeds-Updater', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' };
            req = lib.get(opts, function (res) {
                var code = res.statusCode, loc = res.headers.location, total, received = 0, chunks = [];
                if (code >= 300 && code < 400 && loc) {
                    res.resume();
                    if (redirects >= CONFIG.MAX_REDIRECTS) { reject(new Error('Too many redirects')); return; }
                    loc = Node.url.resolve(url, loc);
                    if (CONFIG.REQUIRE_HTTPS && !/^https:/i.test(loc)) { reject(new Error('Refusing non-https redirect')); return; }
                    nodeBuffer(loc, onProgress, redirects + 1).then(resolve, reject);
                    return;
                }
                if (code !== 200) { res.resume(); reject(httpError(code, url)); return; }
                total = parseInt(res.headers['content-length'], 10) || 0;
                res.on('data', function (c) {
                    chunks.push(c);
                    received += c.length;
                    if (onProgress && total) { onProgress(Math.min(1, received / total)); }
                });
                res.on('end', function () { resolve(NodeBuffer.concat(chunks, received)); });
                res.on('error', reject);
            });
            req.on('error', reject);
            req.setTimeout(CONFIG.DOWNLOAD_TIMEOUT_MS, function () { req.abort(); reject(new Error('Connection timed out')); });
        });
    }

    function getBuffer(url, onProgress) {
        return fetchBuffer(url, onProgress).catch(function (err) {
            if (err && err.httpStatus) { throw err; }          // real HTTP error: do not retry
            log('fetch failed, retrying with Node https:', err && err.message);
            return nodeBuffer(url, onProgress);
        });
    }

    function fetchJSON(url) {
        return getBuffer(bust(url)).then(function (buf) {
            var s = buf.toString('utf8');
            if (s.charCodeAt(0) === 0xFEFF) { s = s.slice(1); }   // strip a UTF-8 BOM
            return JSON.parse(s);
        });
    }

    /* ------------------------------------------------------------------
     * 6. FILE SYSTEM  (Node 8 safe)
     * ------------------------------------------------------------------ */
    function mkdirp(dir) {
        if (!dir || Node.fs.existsSync(dir)) { return; }
        mkdirp(Node.path.dirname(dir));
        try { Node.fs.mkdirSync(dir); } catch (e) { if (e.code !== 'EEXIST') { throw e; } }
    }

    function rmrf(p) {
        var st;
        try { st = Node.fs.lstatSync(p); } catch (e) { return; }
        if (st.isDirectory()) {
            Node.fs.readdirSync(p).forEach(function (n) { rmrf(join(p, n)); });
            Node.fs.rmdirSync(p);
        } else {
            try { Node.fs.chmodSync(p, 438); } catch (e2) { /* 0666: clear read-only flag */ }
            Node.fs.unlinkSync(p);
        }
    }

    function listFiles(dir, rel, out) {   // relative file paths, forward slashes
        rel = rel || '';
        out = out || [];
        Node.fs.readdirSync(join(dir, rel)).forEach(function (n) {
            var r = rel ? rel + '/' + n : n;
            if (JUNK.test(r)) { return; }
            if (Node.fs.statSync(join(dir, r)).isDirectory()) { listFiles(dir, r, out); }
            else { out.push(r); }
        });
        return out;
    }

    function writeFile(dst, data) {
        mkdirp(Node.path.dirname(dst));
        try { Node.fs.writeFileSync(dst, data); }
        catch (e) {
            if (e.code !== 'EPERM' && e.code !== 'EACCES') { throw e; }
            Node.fs.chmodSync(dst, 438);        // read-only file on Windows: unlock and retry
            Node.fs.writeFileSync(dst, data);
        }
    }

    function isWritable(dir) {
        var probe = join(dir, '.ms_write_test');
        try { Node.fs.writeFileSync(probe, 'ok'); Node.fs.unlinkSync(probe); return true; } catch (e) { return false; }
    }

    function cleanup(root) {
        [CONFIG.ZIP_NAME, CONFIG.STAGING_DIR, CONFIG.BACKUP_DIR].forEach(function (n) {
            try { rmrf(join(root, n)); } catch (e) { log('cleanup failed for', n, e); }
        });
    }

    /* A GitHub "Download ZIP" wraps everything in one top folder - accept both layouts. */
    function findPackageRoot(staging) {
        var entries, dirs;
        if (Node.fs.existsSync(join(staging, CONFIG.REQUIRED_FILE))) { return staging; }
        entries = Node.fs.readdirSync(staging).filter(function (n) { return !JUNK.test(n); });
        dirs = entries.filter(function (n) { return Node.fs.statSync(join(staging, n)).isDirectory(); });
        if (entries.length === 1 && dirs.length === 1 && Node.fs.existsSync(join(staging, dirs[0], CONFIG.REQUIRED_FILE))) {
            return join(staging, dirs[0]);
        }
        throw userError('The update package is invalid (' + CONFIG.REQUIRED_FILE + ' not found).');
    }

    function isPreserved(rel, root) {
        return CONFIG.PRESERVE_IF_EXISTS.indexOf(rel) !== -1 && Node.fs.existsSync(join(root, rel));
    }

    function isInternal(rel) {
        var top = rel.split('/')[0];
        return top === CONFIG.ZIP_NAME || top === CONFIG.STAGING_DIR || top === CONFIG.BACKUP_DIR;
    }

    /* Copy every file of the new version over the extension.
       Old copies go to BACKUP_DIR first, so any failure rolls back cleanly. */
    function installFiles(pkg, root) {
        var files = listFiles(pkg), backup = join(root, CONFIG.BACKUP_DIR), done = [], i, rel, dst, existed;
        rmrf(backup);
        try {
            for (i = 0; i < files.length; i++) {
                rel = files[i];
                if (isInternal(rel) || isPreserved(rel, root)) { continue; }
                dst = join(root, rel);
                existed = Node.fs.existsSync(dst);
                if (existed) { writeFile(join(backup, rel), Node.fs.readFileSync(dst)); }
                done.push({ rel: rel, existed: existed });
                writeFile(dst, Node.fs.readFileSync(join(pkg, rel)));
            }
        } catch (err) {
            for (i = done.length - 1; i >= 0; i--) {   // roll back
                try {
                    if (done[i].existed) { writeFile(join(root, done[i].rel), Node.fs.readFileSync(join(backup, done[i].rel))); }
                    else { rmrf(join(root, done[i].rel)); }
                } catch (e2) { log('rollback failed for', done[i].rel, e2); }
            }
            throw userError('Could not write "' + rel + '" (' + (err.code || err.message) + '). Nothing was changed - close other apps using the panel files and try again.');
        }
        return done.length;
    }

    /* The ExtendScript side is NOT refreshed by location.reload(): load the new host script now. */
    function reloadHostScript(root) {
        return new Promise(function (resolve) {
            var f = CONFIG.HOST_SCRIPT ? join(root, CONFIG.HOST_SCRIPT) : '', finished = false;
            function finish(r) { if (!finished) { finished = true; log('host script reload:', r); resolve(); } }
            if (!f || !Node.fs.existsSync(f)) { finish('skipped'); return; }
            evalScript('(function(){try{$.evalFile(new File(' + JSON.stringify(f.replace(/\\/g, '/')) + '));return "ok";}catch(e){return "error: "+e;}}())', finish);
            setTimeout(function () { finish('timeout'); }, 5000);   // never hang the update on ExtendScript
        });
    }

    /* ------------------------------------------------------------------
     * 7. UI  (banner + overlay; every element is optional)
     * ------------------------------------------------------------------ */
    var UI = {
        el: {},
        init: function () {
            var ids = { banner: 'ms-update-banner', text: 'ms-update-text', btn: 'ms-update-btn', dismiss: 'ms-update-dismiss',
                overlay: 'ms-update-overlay', spinner: 'ms-update-spinner', msg: 'ms-update-msg', sub: 'ms-update-sub', progress: 'ms-update-progress', bar: 'ms-update-bar', close: 'ms-update-close' };
            var k;
            for (k in ids) { if (ids.hasOwnProperty(k)) { UI.el[k] = document.getElementById(ids[k]); } }
            if (UI.el.btn) { UI.el.btn.addEventListener('click', function () { if (latest) { performUpdate(latest); } }); }
            if (UI.el.dismiss) { UI.el.dismiss.addEventListener('click', UI.hideBanner); }
            if (UI.el.close) { UI.el.close.addEventListener('click', UI.hideOverlay); }
        },
        show: function (e, on) { if (e) { if (on) { e.removeAttribute('hidden'); } else { e.setAttribute('hidden', ''); } } },
        showBanner: function (info) {
            if (UI.el.text) { UI.el.text.textContent = 'New Update Available (v' + info.version + ')'; }
            if (UI.el.banner && info.notes) { UI.el.banner.title = info.notes; }
            if (UI.el.btn) { UI.el.btn.disabled = false; }
            UI.show(UI.el.banner, true);
        },
        hideBanner: function () { UI.show(UI.el.banner, false); },
        showOverlay: function (msg, sub) {
            if (UI.el.btn) { UI.el.btn.disabled = true; }
            if (UI.el.spinner) { UI.el.spinner.className = 'ms-update-spinner'; }
            UI.setStatus(msg, sub);
            UI.setProgress(0);
            UI.show(UI.el.progress, true);
            UI.show(UI.el.close, false);
            UI.show(UI.el.overlay, true);
        },
        setStatus: function (msg, sub) {
            if (UI.el.msg && msg !== undefined) { UI.el.msg.textContent = msg; }
            if (UI.el.sub && sub !== undefined) { UI.el.sub.textContent = sub; }
        },
        setProgress: function (f) { if (UI.el.bar) { UI.el.bar.style.width = Math.round(Math.max(0, Math.min(1, f)) * 100) + '%'; } },
        done: function (msg) {
            if (UI.el.spinner) { UI.el.spinner.className = 'ms-update-spinner done'; }
            UI.setStatus(msg, '');
            UI.setProgress(1);
        },
        fail: function (msg) {
            if (UI.el.spinner) { UI.el.spinner.className = 'ms-update-spinner error'; }
            UI.setStatus('Update failed', msg);
            UI.show(UI.el.progress, false);
            UI.show(UI.el.close, true);
            UI.show(UI.el.overlay, true);
            if (UI.el.btn) { UI.el.btn.disabled = false; }
        },
        hideOverlay: function () { UI.show(UI.el.overlay, false); }
    };

    /* ------------------------------------------------------------------
     * 8. UPDATE CHECK  (silent)
     * ------------------------------------------------------------------ */
    var latest = null, busy = false;

    function checkForUpdate() {
        var root, current;
        if (!loadNode()) { log('Node.js is not enabled - updater disabled'); return Promise.resolve(null); }
        root = extensionRoot();
        if (!root) { log('Extension path unknown - updater disabled'); return Promise.resolve(null); }
        if (CONFIG.REQUIRE_HTTPS && !/^https:\/\//i.test(CONFIG.UPDATE_JSON_URL)) { log('UPDATE_JSON_URL must be https'); return Promise.resolve(null); }
        if (!busy) { cleanup(root); }                     // leftovers of an interrupted update
        current = localVersion(root);
        return withTimeout(fetchJSON(CONFIG.UPDATE_JSON_URL), CONFIG.JSON_TIMEOUT_MS, 'Update check')
            .then(validateInfo)
            .then(function (info) {
                if (compareVersions(info.version, current) > 0) {
                    if (alreadyInstalled(info)) {
                        log('Release ' + info.version + ' is already installed (its package reports ' + current + ') - banner suppressed');
                        return null;
                    }
                    latest = info;
                    log('Update available:', current, '->', info.version);
                    UI.showBanner(info);
                    return info;
                }
                log('Up to date (' + current + ')');
                return null;
            })
            .catch(function (err) {                       // silent by design
                log('Update check failed:', err && err.message);
                return null;
            });
    }

    /* ------------------------------------------------------------------
     * 9. DOWNLOAD + INSTALL
     * ------------------------------------------------------------------ */
    function performUpdate(info) {
        var root, zipPath, staging;
        if (busy || !loadNode()) { return Promise.resolve(false); }
        busy = true;
        root = extensionRoot();
        zipPath = join(root, CONFIG.ZIP_NAME);
        staging = join(root, CONFIG.STAGING_DIR);
        UI.showOverlay('Downloading and Installing...', 'Version ' + info.version + ' - please keep After Effects open.');

        return Promise.resolve().then(function () {
            if (!isWritable(root)) {
                throw userError('This copy of the panel is installed in a protected folder and cannot update itself. Please install the new version with the installer.');
            }
            return withTimeout(getBuffer(bust(info.url), function (f) {
                UI.setProgress(f * 0.8);
                UI.setStatus('Downloading... ' + Math.round(f * 100) + '%');
            }), CONFIG.DOWNLOAD_TIMEOUT_MS, 'Download');
        }).then(function (buf) {
            var AdmZip, zip, pkg, count;
            if (!buf || !buf.length) { throw userError('The downloaded file is empty.'); }
            if (info.sha256 && Node.crypto.createHash('sha256').update(buf).digest('hex') !== info.sha256) {
                throw userError('The download is corrupted (checksum mismatch). Please try again.');
            }
            UI.setStatus('Installing...');
            UI.setProgress(0.85);

            Node.fs.writeFileSync(zipPath, buf);                       // save into the extension folder
            rmrf(staging);
            AdmZip = nodeRequire(join(root, 'node_modules', 'adm-zip'));
            zip = new AdmZip(zipPath);
            zip.extractAllTo(staging, true);                            // extract, overwrite = true
            pkg = findPackageRoot(staging);
            count = installFiles(pkg, root);                            // overwrite the panel files
            rememberInstall(info);
            log('Installed', count, 'files');
            cleanup(root);                                              // delete update.zip + temp folders
            UI.setProgress(0.95);
            return reloadHostScript(root);
        }).then(function () {
            UI.done('Update installed - reloading...');
            setTimeout(function () { window.location.reload(); }, 800);
            return true;
        }).catch(function (err) {
            try { cleanup(root); } catch (e) { /* ignore */ }
            busy = false;
            log('Update failed:', err);
            UI.fail(err && err.userMessage ? err.userMessage : 'Could not update: ' + (err && err.message ? err.message : err));
            return false;
        });
    }

    /* ------------------------------------------------------------------
     * 10. BOOT
     * ------------------------------------------------------------------ */
    function boot() {
        UI.init();
        setTimeout(checkForUpdate, CONFIG.CHECK_DELAY_MS);
    }

    window.MSUpdater = {
        check: checkForUpdate,
        update: function () { return latest ? performUpdate(latest) : Promise.resolve(false); },
        compareVersions: compareVersions,
        config: CONFIG,
        _ui: UI
    };

    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
    else { boot(); }

}(window, document));
