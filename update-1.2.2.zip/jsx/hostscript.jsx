/* =====================================================================
 * MotionSeeds Master - hostscript.jsx
 * Adobe After Effects CC 2018 (15.0) -> 2026  |  ExtendScript (ES3)
 * Loaded by CSXS/manifest.xml (ScriptPath). Public API:
 *   MotionSeeds.exec(tool, modifierTier, argsJSON) -> JSON string
 *   getSystemDeviceID()                             -> machine fingerprint
 * ===================================================================== */
(function () {
    if (typeof $.global.MotionSeedsCompat === "undefined" || typeof $.global.JSON !== "object") {
        try {
            var f = new File(File($.fileName).parent.fsName + "/compatibility.jsx");
            if (f.exists) { $.evalFile(f); }
        } catch (e) {}
    }
}());

(function () {
    /* =====================================================================
     * MotionSeeds Master - hostscript.jsx
     * After Effects CC 2018 -> 2026 (ExtendScript / ES3 safe)
     * Every action runs inside: app.beginUndoGroup("MotionSeeds: <Tool>")
     * try { ... } catch (err) { report } finally { app.endUndoGroup(); }
     * ===================================================================== */
    var MS = {};
    MS.VERSION = "1.0.0";
    MS.T = {};
    MS.root = "";
    MS.MOD = { click: "Click", alt: "Alt", shift: "Shift", ctrl: "Ctrl", ctrlAlt: "Ctrl+Alt", shiftCtrl: "Shift+Ctrl", shiftAlt: "Shift+Alt", shiftCtrlAlt: "Shift+Ctrl+Alt" };

    /* ------------------------------ basics ------------------------------ */
    MS.fail = function (msg) {
        var e = new Error(msg);
        e.msUser = true;
        throw e;
    };
    MS.errStr = function (e) {
        if (e && e.msUser) { return e.message; }
        var s = (e && e.message) ? e.message : String(e);
        if (e && e.line) { s += " (line " + e.line + ")"; }
        return "MotionSeeds Error: " + s;
    };
    MS.json = function (o) { return JSON.stringify(o); };
    MS.trim = function (s) { return String(s).replace(/^\s+|\s+$/g, ""); };
    MS.idx = function (arr, v) {
        var i;
        for (i = 0; i < arr.length; i++) { if (arr[i] === v) { return i; } }
        return -1;
    };
    MS.eqL = function (a, b) {   // robust layer identity test
        if (a === b) { return true; }
        try { return !!(a && b && a.index === b.index && a.containingComp.id === b.containingComp.id); } catch (e) { return false; }
    };
    MS.idxL = function (arr, l) {
        var i;
        for (i = 0; i < arr.length; i++) { if (MS.eqL(arr[i], l)) { return i; } }
        return -1;
    };
    MS.clamp = function (v, a, b) { return v < a ? a : (v > b ? b : v); };
    MS.num = function (v, d) { var n = parseFloat(v); return isNaN(n) ? d : n; };
    MS.isArr = function (v) { return (v instanceof Array) || Object.prototype.toString.call(v) === "[object Array]"; };
    MS.rnd = function (a, b) { return a + Math.random() * (b - a); };
    MS.q = function (s) {
        return "\"" + String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\r/g, "\\r").replace(/\n/g, "\\n") + "\"";
    };
    MS.f = function (n) {   // number literal for expressions
        var r = Math.round(n * 10000) / 10000;
        return (r === 0) ? "0" : String(r);
    };
    MS.vadd = function (a, b) {
        var i, out;
        if (!MS.isArr(a)) { return a + (MS.isArr(b) ? b[0] : b); }
        out = [];
        for (i = 0; i < a.length; i++) { out.push(a[i] + (MS.isArr(b) ? (i < b.length ? b[i] : 0) : b)); }
        return out;
    };
    MS.vsub = function (a, b) {
        var i, out = [];
        for (i = 0; i < a.length; i++) { out.push(a[i] - (i < b.length ? b[i] : 0)); }
        return out;
    };
    MS.vfit = function (cur, v) {   // keep the dimension count of "cur"
        var i, out;
        if (!MS.isArr(cur)) { return MS.isArr(v) ? v[0] : v; }
        out = [];
        for (i = 0; i < cur.length; i++) { out.push(i < v.length ? v[i] : cur[i]); }
        return out;
    };
    MS.copyArr = function (a) {
        var i, o = [];
        if (!MS.isArr(a)) { return a; }
        for (i = 0; i < a.length; i++) { o.push(a[i]); }
        return o;
    };

    /* ------------------------------ colors ------------------------------ */
    MS.hex2rgb = function (hex) {
        var h = String(hex || "#ffffff").replace("#", "");
        if (h.length === 3) { h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2); }
        var n = parseInt(h.substr(0, 6), 16);
        if (isNaN(n)) { n = 0xffffff; }
        return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
    };
    MS.rgb2hex = function (c) {
        function h(v) { var s = Math.round(MS.clamp(v, 0, 1) * 255).toString(16); return s.length < 2 ? "0" + s : s; }
        return "#" + h(c[0]) + h(c[1]) + h(c[2]);
    };
    MS.rgba = function (hex) { var c = MS.hex2rgb(hex); return [c[0], c[1], c[2], 1]; };
    MS.rgb2hsl = function (c) {
        var r = c[0], g = c[1], b = c[2], mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
        if (d > 0.00001) {
            s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
            if (mx === r) { h = (g - b) / d + (g < b ? 6 : 0); } else if (mx === g) { h = (b - r) / d + 2; } else { h = (r - g) / d + 4; }
            h /= 6;
        }
        return [h, s, l];
    };
    MS.hsl2rgb = function (hsl) {
        var h = hsl[0], s = hsl[1], l = hsl[2], q, p;
        function f(t) {
            if (t < 0) { t += 1; }
            if (t > 1) { t -= 1; }
            if (t < 1 / 6) { return p + (q - p) * 6 * t; }
            if (t < 1 / 2) { return q; }
            if (t < 2 / 3) { return p + (q - p) * (2 / 3 - t) * 6; }
            return p;
        }
        if (s === 0) { return [l, l, l]; }
        q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        p = 2 * l - q;
        return [f(h + 1 / 3), f(h), f(h - 1 / 3)];
    };
    MS.randColor = function () { return MS.hsl2rgb([Math.random(), MS.rnd(0.65, 0.95), MS.rnd(0.5, 0.65)]); };
    MS.argColor = function (c) { return MS.hex2rgb((c.args && c.args.color) ? c.args.color : "#ff375f"); };
    MS.argPalette = function (c) {
        var p = (c.args && c.args.palette && c.args.palette.length) ? c.args.palette : ["#ff375f", "#ff9f0a", "#30d158", "#32ade6", "#bf5af2"];
        var out = [], i;
        for (i = 0; i < p.length; i++) { out.push(MS.hex2rgb(p[i])); }
        return out;
    };

    /* ------------------------------ project / comp ------------------------------ */
    MS.comp = function () {
        var c = (app.project) ? app.project.activeItem : null;
        if (!(c instanceof CompItem)) { MS.fail("Open a composition first (click inside its timeline)."); }
        return c;
    };
    MS.compOrNull = function () {
        var c = (app.project) ? app.project.activeItem : null;
        return (c instanceof CompItem) ? c : null;
    };
    MS.sel = function (comp, min) {
        var s = comp.selectedLayers, out = [], i;
        for (i = 0; i < s.length; i++) { out.push(s[i]); }
        if (min && out.length < min) { MS.fail(min === 1 ? "Select at least one layer." : "Select at least " + min + " layers."); }
        return out;
    };
    MS.filter = function (arr, fn) {
        var out = [], i;
        for (i = 0; i < arr.length; i++) { if (fn(arr[i])) { out.push(arr[i]); } }
        return out;
    };
    MS.needSome = function (arr, msg) { if (!arr.length) { MS.fail(msg); } return arr; };
    // NOTE: in After Effects scripting TextLayer and ShapeLayer are NOT "instanceof AVLayer",
    // so every layer that has transform/bounds is tested with these helpers.
    MS.isAV = function (l) { return (l instanceof AVLayer) || (l instanceof TextLayer) || (l instanceof ShapeLayer); };
    MS.isVisual = function (l) { try { return MS.isAV(l) && l.hasVideo; } catch (e) { return false; } };
    MS.isText = function (l) { return (l instanceof TextLayer); };
    MS.isShape = function (l) { return (l instanceof ShapeLayer); };
    MS.allLayers = function (comp) {
        var out = [], i;
        for (i = 1; i <= comp.numLayers; i++) { out.push(comp.layer(i)); }
        return out;
    };
    MS.layerByName = function (comp, name) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) { if (comp.layer(i).name === name) { return comp.layer(i); } }
        return null;
    };
    MS.uniq = function (comp, base) {
        var n = 2, nm = base;
        while (MS.layerByName(comp, nm)) { nm = base + " " + n; n++; }
        return nm;
    };
    MS.selectOnly = function (comp, layers) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) { try { comp.layer(i).selected = false; } catch (e) {} }
        for (i = 0; i < layers.length; i++) { try { layers[i].selected = true; } catch (e2) {} }
    };
    MS.removeLayer = function (l) {
        var src = null;
        try { src = l.source; } catch (e) {}
        l.remove();
        try { if (src && (src instanceof FootageItem) && src.mainSource instanceof SolidSource && src.usedIn.length === 0) { src.remove(); } } catch (e2) {}
    };
    MS.topOf = function (layers) {
        var best = null, i;
        for (i = 0; i < layers.length; i++) { if (!best || layers[i].index < best.index) { best = layers[i]; } }
        return best;
    };
    MS.placeAbove = function (l, ref) { if (ref && ref !== l) { try { l.moveBefore(ref); } catch (e) {} } };
    MS.placeBelow = function (l, ref) { if (ref && ref !== l) { try { l.moveAfter(ref); } catch (e) {} } };
    MS.dur = function (comp) { return comp.duration; };
    MS.ext = function (l) { return (l instanceof ShapeLayer); };   // includeExtents for sourceRectAtTime
    MS.rect = function (l, t) { return l.sourceRectAtTime(t, MS.ext(l)); };

    /* ------------------------------ properties ------------------------------ */
    MS.tr = function (l, mn) { return l.property("ADBE Transform Group").property(mn); };
    MS.setVal = function (p, v, t) {
        if (p.numKeys > 0) { p.setValueAtTime(t, v); } else { p.setValue(v); }
    };
    MS.addToProp = function (p, d) {
        var k;
        if (p.numKeys > 0) {
            for (k = 1; k <= p.numKeys; k++) { p.setValueAtKey(k, MS.vadd(p.keyValue(k), d)); }
        } else {
            p.setValue(MS.vadd(p.value, d));
        }
    };
    MS.posGet = function (l, t, pre) {
        var p = MS.tr(l, "ADBE Position"), x, y, z;
        if (p.dimensionsSeparated) {
            x = MS.tr(l, "ADBE Position_0").valueAtTime(t, !!pre);
            y = MS.tr(l, "ADBE Position_1").valueAtTime(t, !!pre);
            z = l.threeDLayer ? MS.tr(l, "ADBE Position_2").valueAtTime(t, !!pre) : 0;
            return [x, y, z];
        }
        return p.valueAtTime(t, !!pre);
    };
    MS.posAdd = function (l, d) {
        var p = MS.tr(l, "ADBE Position");
        if (p.dimensionsSeparated) {
            MS.addToProp(MS.tr(l, "ADBE Position_0"), d[0] || 0);
            MS.addToProp(MS.tr(l, "ADBE Position_1"), d[1] || 0);
            if (l.threeDLayer && d.length > 2) { MS.addToProp(MS.tr(l, "ADBE Position_2"), d[2] || 0); }
        } else {
            MS.addToProp(p, d);
        }
    };
    MS.posSet = function (l, v, t) {
        var cur = MS.posGet(l, t, false);
        MS.posAdd(l, MS.vsub(MS.vfit(cur, v), cur));
    };
    MS.posKey = function (l, t) {
        var p = MS.tr(l, "ADBE Position"), dims, i, q;
        if (p.dimensionsSeparated) {
            dims = l.threeDLayer ? 3 : 2;
            for (i = 0; i < dims; i++) { q = MS.tr(l, "ADBE Position_" + i); q.setValueAtTime(t, q.valueAtTime(t, true)); }
        } else {
            p.setValueAtTime(t, p.valueAtTime(t, true));
        }
    };
    MS.posExpr = function (l, expr) {
        var p = MS.tr(l, "ADBE Position");
        if (p.dimensionsSeparated) { p.dimensionsSeparated = false; }
        p.expression = expr;
    };
    MS.isProp = function (p) { return p && p.propertyType === PropertyType.PROPERTY; };
    MS.walk = function (group, fn) {   // depth-first over leaf properties (one odd property never aborts the walk)
        var i, p, n = 0;
        try { n = group.numProperties; } catch (e0) { n = 0; }
        for (i = 1; i <= n; i++) {
            p = null;
            try { p = group.property(i); } catch (e1) { p = null; }
            if (!p) { continue; }
            if (p.propertyType === PropertyType.PROPERTY) { try { fn(p); } catch (e2) {} } else { MS.walk(p, fn); }
        }
    };
    MS.walkGroups = function (group, mn, fn) {
        var i, p;
        for (i = 1; i <= group.numProperties; i++) {
            p = group.property(i);
            if (!p) { continue; }
            if (p.propertyType !== PropertyType.PROPERTY) {
                if (p.matchName === mn) { fn(p); }
                MS.walkGroups(p, mn, fn);
            }
        }
    };
    MS.findFirst = function (group, mn) {
        var i, p, r;
        for (i = 1; i <= group.numProperties; i++) {
            p = group.property(i);
            if (!p) { continue; }
            if (p.matchName === mn) { return p; }
            if (p.propertyType !== PropertyType.PROPERTY) { r = MS.findFirst(p, mn); if (r) { return r; } }
        }
        return null;
    };
    MS.firstOfType = function (group, pvt, nth) {   // pvt "point" = any 2D point parameter
        var found = [];
        MS.walk(group, function (p) {
            var v = p.propertyValueType;
            if (pvt === "point" ? (v === PropertyValueType.TwoD_SPATIAL || v === PropertyValueType.TwoD) : v === pvt) { found.push(p); }
        });
        return found[nth || 0] || null;
    };
    MS.trySet = function (group, mn, v) {
        try { var p = group.property(mn); if (p) { p.setValue(v); return p; } } catch (e) {}
        return null;
    };
    MS.ensureExpr = function (p, expr) { p.expression = expr; try { p.expressionEnabled = true; } catch (e) {} };

    /* ------------------------------ effects & controls ------------------------------ */
    MS.fx = function (l) { return l.property("ADBE Effect Parade"); };
    MS.addFx = function (l, mn, name) {
        var g = MS.fx(l), e;
        if (!g) { MS.fail("This layer type cannot hold effects."); }
        if (!g.canAddProperty(mn)) { MS.fail("Effect not available in this After Effects: " + mn); }
        e = g.addProperty(mn);
        if (name) { e.name = name; }
        return e;
    };
    MS.getFx = function (l, name) {
        var g = MS.fx(l), i;
        if (!g) { return null; }
        for (i = 1; i <= g.numProperties; i++) { if (g.property(i).name === name) { return g.property(i); } }
        return null;
    };
    MS.ctrl = function (l, mn, name, val) {   // reuse a named expression control or create it
        var e = MS.getFx(l, name);
        if (!e || e.matchName !== mn) { e = MS.addFx(l, mn, name); if (val !== undefined) { e.property(1).setValue(val); } }
        return e.property(1);
    };
    MS.slider = function (l, name, val) { return MS.ctrl(l, "ADBE Slider Control", name, val); };
    MS.colorCtrl = function (l, name, rgb) { return MS.ctrl(l, "ADBE Color Control", name, rgb ? [rgb[0], rgb[1], rgb[2], 1] : undefined); };
    MS.removeFxNamed = function (l, prefix) {
        var g = MS.fx(l), i, n = 0;
        if (!g) { return 0; }
        for (i = g.numProperties; i >= 1; i--) { if (g.property(i).name.indexOf(prefix) === 0) { g.property(i).remove(); n++; } }
        return n;
    };

    /* ------------------------------ layer factory ------------------------------ */
    MS.newNull = function (comp, name, w, h) {
        var n = comp.layers.addNull(comp.duration);
        n.name = MS.uniq(comp, name);
        if (w && h) {
            try { n.source.width = Math.max(4, Math.round(w)); n.source.height = Math.max(4, Math.round(h)); } catch (e) {}
            MS.tr(n, "ADBE Anchor Point").setValue([n.source.width / 2, n.source.height / 2, 0]);
        }
        return n;
    };
    MS.newShape = function (comp, name) {
        var s = comp.layers.addShape();
        s.name = MS.uniq(comp, name);
        return s;
    };
    MS.shapeGroup = function (layerOrContents, name) {
        var root = (layerOrContents.matchName === "ADBE Root Vectors Group" || layerOrContents.matchName === "ADBE Vectors Group") ? layerOrContents : layerOrContents.property("ADBE Root Vectors Group");
        var g = root.addProperty("ADBE Vector Group");
        if (name) { g.name = name; }
        return g;
    };
    MS.newGroupIdx = function (layer, name) { return MS.shapeGroup(layer, name).propertyIndex; };
    MS.grpContents = function (layer, gIdx) { return layer.property("ADBE Root Vectors Group").property(gIdx).property("ADBE Vectors Group"); };
    MS.grpXf = function (layer, gIdx) { return layer.property("ADBE Root Vectors Group").property(gIdx).property("ADBE Vector Transform Group"); };
    MS.addRect = function (contents, size, pos, round) {
        var r = contents.addProperty("ADBE Vector Shape - Rect");
        r.property("ADBE Vector Rect Size").setValue(size);
        if (pos) { r.property("ADBE Vector Rect Position").setValue(pos); }
        if (round) { r.property("ADBE Vector Rect Roundness").setValue(round); }
        return r;
    };
    MS.addEllipse = function (contents, size, pos) {
        var e = contents.addProperty("ADBE Vector Shape - Ellipse");
        e.property("ADBE Vector Ellipse Size").setValue(size);
        if (pos) { e.property("ADBE Vector Ellipse Position").setValue(pos); }
        return e;
    };
    MS.addPath = function (contents, verts, closed) {
        var p = contents.addProperty("ADBE Vector Shape - Group"), s = new Shape();
        s.vertices = verts;
        s.closed = !!closed;
        p.property("ADBE Vector Shape").setValue(s);
        return p;
    };
    MS.addFill = function (contents, rgb) {
        var f = contents.addProperty("ADBE Vector Graphic - Fill");
        f.property("ADBE Vector Fill Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
        return f;
    };
    MS.addStroke = function (contents, rgb, w, cap) {
        var s = contents.addProperty("ADBE Vector Graphic - Stroke");
        s.property("ADBE Vector Stroke Color").setValue([rgb[0], rgb[1], rgb[2], 1]);
        s.property("ADBE Vector Stroke Width").setValue(w || 4);
        if (cap) { s.property("ADBE Vector Stroke Line Cap").setValue(cap); }
        return s;
    };
    MS.ellipseShape = function (cx, cy, rx, ry) {
        var k = 0.5522847498, s = new Shape();
        s.vertices = [[cx, cy - ry], [cx + rx, cy], [cx, cy + ry], [cx - rx, cy]];
        s.inTangents = [[-rx * k, 0], [0, -ry * k], [rx * k, 0], [0, ry * k]];
        s.outTangents = [[rx * k, 0], [0, ry * k], [-rx * k, 0], [0, -ry * k]];
        s.closed = true;
        return s;
    };
    MS.rectShape = function (x, y, w, h) {
        var s = new Shape();
        s.vertices = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
        s.closed = true;
        return s;
    };
    MS.addMask = function (l, shape, name) {
        var m = l.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
        m.property("ADBE Mask Shape").setValue(shape);
        if (name) { m.name = name; }
        return m;
    };

    /* ------------------------------ keyframes ------------------------------ */
    MS.keyProps = function (comp) {   // properties with selected keyframes
        var sp = comp.selectedProperties, out = [], i, p;
        for (i = 0; i < sp.length; i++) {
            p = sp[i];
            if (p.propertyType === PropertyType.PROPERTY && p.selectedKeys && p.selectedKeys.length > 0) { out.push(p); }
        }
        return out;
    };
    MS.needKeyProps = function (comp) {
        var r = MS.keyProps(comp);
        if (!r.length) { MS.fail("Select keyframes in the timeline first."); }
        return r;
    };
    MS.selProps = function (comp) {   // selected leaf properties (keyframes not required)
        var sp = comp.selectedProperties, out = [], i;
        for (i = 0; i < sp.length; i++) { if (sp[i].propertyType === PropertyType.PROPERTY) { out.push(sp[i]); } }
        return out;
    };
    MS.ownerLayer = function (p) {
        return p.propertyGroup(p.propertyDepth);   // the Layer that owns this property
    };
    MS.easeArr = function (n, speed, inf) {
        var i, a = [];
        for (i = 0; i < n; i++) { a.push(new KeyframeEase(speed, MS.clamp(inf, 0.1, 100))); }
        return a;
    };
    MS.easeNeg = function (arr, p) {
        var i, o = [];
        for (i = 0; i < arr.length; i++) { o.push(new KeyframeEase(p.isSpatial ? arr[i].speed : -arr[i].speed, arr[i].influence)); }
        return o;
    };
    MS.readKey = function (p, k) {
        var d = { t: p.keyTime(k), v: p.keyValue(k), inT: p.keyInInterpolationType(k), outT: p.keyOutInterpolationType(k), ie: null, oe: null };
        try { d.ie = p.keyInTemporalEase(k); d.oe = p.keyOutTemporalEase(k); } catch (e) {}
        try { d.tc = p.keyTemporalContinuous(k); d.tab = p.keyTemporalAutoBezier(k); } catch (e2) {}
        if (p.isSpatial) {
            try { d.ist = p.keyInSpatialTangent(k); d.ost = p.keyOutSpatialTangent(k); d.sc = p.keySpatialContinuous(k); d.sab = p.keySpatialAutoBezier(k); d.rov = p.keyRoving(k); } catch (e3) {}
        }
        return d;
    };
    MS.writeKey = function (p, t, d, rev, valOverride) {
        var k, inT, outT;
        p.setValueAtTime(t, (valOverride !== undefined) ? valOverride : d.v);
        k = p.nearestKeyIndex(t);
        inT = rev ? d.outT : d.inT;
        outT = rev ? d.inT : d.outT;
        try { p.setInterpolationTypeAtKey(k, inT, outT); } catch (e) {}
        if (d.ie && d.oe) {
            try { p.setTemporalEaseAtKey(k, rev ? MS.easeNeg(d.oe, p) : d.ie, rev ? MS.easeNeg(d.ie, p) : d.oe); } catch (e1) {}
        }
        try { if (d.tc !== undefined) { p.setTemporalContinuousAtKey(k, d.tc); } if (d.tab !== undefined) { p.setTemporalAutoBezierAtKey(k, d.tab); } } catch (e2) {}
        if (p.isSpatial && d.ist) {
            try {
                p.setSpatialTangentsAtKey(k, rev ? d.ost : d.ist, rev ? d.ist : d.ost);
                p.setSpatialContinuousAtKey(k, d.sc);
                p.setSpatialAutoBezierAtKey(k, d.sab);
            } catch (e3) {}
        }
        return k;
    };
    MS.selKeyData = function (p) {
        var ks = p.selectedKeys, out = [], i;
        for (i = 0; i < ks.length; i++) { out.push(MS.readKey(p, ks[i])); }
        return out;
    };
    MS.removeKeysIn = function (p, t0, t1) {   // inclusive range
        var k;
        for (k = p.numKeys; k >= 1; k--) { if (p.keyTime(k) >= t0 - 1e-6 && p.keyTime(k) <= t1 + 1e-6) { p.removeKey(k); } }
    };
    MS.clearKeys = function (p) { while (p.numKeys > 0) { p.removeKey(1); } };
    MS.canKey = function (p) {
        return p && p.propertyType === PropertyType.PROPERTY && p.canVaryOverTime && p.propertyValueType !== PropertyValueType.NO_VALUE && p.propertyValueType !== PropertyValueType.CUSTOM_VALUE;
    };
    MS.animProps = function (layer, transformOnly) {   // keyframed leaf properties of a layer
        var out = [], root = transformOnly ? layer.property("ADBE Transform Group") : layer;
        MS.walk(root, function (p) { if (p.numKeys > 1 && MS.canKey(p)) { out.push(p); } });
        return out;
    };
    MS.same = function (a, b) {
        var i;
        if (MS.isArr(a) && MS.isArr(b)) {
            if (a.length !== b.length) { return false; }
            for (i = 0; i < a.length; i++) { if (Math.abs(a[i] - b[i]) > 1e-7) { return false; } }
            return true;
        }
        if (typeof a === "number" && typeof b === "number") { return Math.abs(a - b) < 1e-7; }
        return false;
    };
    MS.bakeProp = function (p, comp, layer, step) {
        var pvt, fd, f0, f1, f, times = [], vals = [], isStatic = true, i, t0, t1;
        if (!p.canSetExpression || !p.expression || !p.expressionEnabled) { return false; }
        pvt = p.propertyValueType;
        if (pvt === PropertyValueType.NO_VALUE || pvt === PropertyValueType.CUSTOM_VALUE || pvt === PropertyValueType.LAYER_INDEX || pvt === PropertyValueType.MASK_INDEX) { return false; }
        fd = comp.frameDuration;
        t0 = Math.max(0, layer.inPoint);
        t1 = Math.min(comp.duration, layer.outPoint);
        f0 = Math.ceil(t0 / fd - 0.001);
        f1 = Math.floor(t1 / fd - 0.001);
        if (f1 < f0) { f1 = f0; }
        step = Math.max(1, step || 1);
        for (f = f0; f <= f1; f += step) { times.push(f * fd); vals.push(p.valueAtTime(f * fd, false)); }
        if (times[times.length - 1] < f1 * fd - 1e-6) { times.push(f1 * fd); vals.push(p.valueAtTime(f1 * fd, false)); }
        for (i = 1; i < vals.length; i++) { if (!MS.same(vals[i], vals[0])) { isStatic = false; break; } }
        if (typeof vals[0] !== "number" && !MS.isArr(vals[0])) { isStatic = (vals.length === 1); }
        p.expression = "";
        MS.clearKeys(p);
        if (isStatic) { p.setValue(vals[0]); } else { p.setValuesAtTimes(times, vals); }
        return true;
    };
    MS.bakeLayer = function (comp, l, step, filterFn) {
        var n = 0, list = [];
        MS.walk(l, function (p) { if (p.canSetExpression && p.expression && p.expressionEnabled && (!filterFn || filterFn(p))) { list.push(p); } });
        var i;
        for (i = 0; i < list.length; i++) { try { if (MS.bakeProp(list[i], comp, l, step)) { n++; } } catch (e) {} }
        return n;
    };

    /* ------------------------------ geometry probe ------------------------------
     * Uses a temporary null + Point Controls driven by expressions so that
     * After Effects itself resolves parenting, 3D, scale and rotation exactly.
     * --------------------------------------------------------------------------- */
    MS.probe = function (comp, exprs, t) {
        var nl, src, i, res = [], err = "", g, pp;
        if (!exprs.length) { return res; }
        nl = comp.layers.addNull(comp.duration);
        src = nl.source;
        nl.name = "MS_PROBE_TEMP";
        try {
            nl.moveToEnd();
            nl.enabled = false;
            for (i = 0; i < exprs.length; i++) { nl.property("ADBE Effect Parade").addProperty("ADBE Point Control"); }
            g = nl.property("ADBE Effect Parade");
            for (i = 0; i < exprs.length; i++) { g.property(i + 1).property(1).expression = exprs[i]; }
            for (i = 0; i < exprs.length; i++) {
                pp = nl.property("ADBE Effect Parade").property(i + 1).property(1);
                res.push(pp.valueAtTime(t, false));
                try { if (pp.expressionError) { err = pp.expressionError; } } catch (e0) {}
            }
        } finally {
            try { nl.remove(); } catch (e1) {}
            try { if (src && src.usedIn.length === 0) { src.remove(); } } catch (e2) {}
        }
        if (err) { MS.fail("Geometry probe failed: " + err); }
        return res;
    };
    MS.L = function (l) { return "var L=thisComp.layer(" + l.index + ");"; };
    MS.exprRectWorld = function (l) {
        return MS.L(l) + "var r=L.sourceRectAtTime(time," + (MS.ext(l) ? "true" : "false") + ");" +
            "var a=L.toWorld([r.left,r.top]),b=L.toWorld([r.left+r.width,r.top]),c=L.toWorld([r.left,r.top+r.height]),d=L.toWorld([r.left+r.width,r.top+r.height]);";
    };
    /* geo(): world-space bounds + world anchor for each layer */
    MS.geo = function (comp, layers, t) {
        var ex = [], i, l, r, out = [], o;
        for (i = 0; i < layers.length; i++) {
            l = layers[i];
            if (MS.isAV(l)) {
                ex.push(MS.exprRectWorld(l) + "[Math.min(a[0],b[0],c[0],d[0]),Math.min(a[1],b[1],c[1],d[1])]");
                ex.push(MS.exprRectWorld(l) + "[Math.max(a[0],b[0],c[0],d[0]),Math.max(a[1],b[1],c[1],d[1])]");
                ex.push(MS.L(l) + "var w=L.toWorld(L.anchorPoint);[w[0],w[1]]");
                ex.push(MS.exprRectWorld(l) + "var w=L.toWorld(L.anchorPoint);var m=L.toWorld([r.left+r.width/2,r.top+r.height/2]);[w.length>2?w[2]:0,m.length>2?m[2]:0]");
            } else {
                ex.push(MS.L(l) + "var w=L.toWorld([0,0,0]);[w[0],w[1]]");
                ex.push(MS.L(l) + "var w=L.toWorld([0,0,0]);[w[0],w[1]]");
                ex.push(MS.L(l) + "var w=L.toWorld([0,0,0]);[w[0],w[1]]");
                ex.push(MS.L(l) + "var w=L.toWorld([0,0,0]);[w[2],w[2]]");
            }
        }
        r = MS.probe(comp, ex, t);
        for (i = 0; i < layers.length; i++) {
            o = { l: layers[i], minX: r[i * 4][0], minY: r[i * 4][1], maxX: r[i * 4 + 1][0], maxY: r[i * 4 + 1][1], ax: r[i * 4 + 2][0], ay: r[i * 4 + 2][1], az: r[i * 4 + 3][0], cz: r[i * 4 + 3][1] };
            o.w = o.maxX - o.minX;
            o.h = o.maxY - o.minY;
            o.cx = (o.minX + o.maxX) / 2;
            o.cy = (o.minY + o.maxY) / 2;
            out.push(o);
        }
        return out;
    };
    MS.union = function (gs) {
        var u = { minX: 1e12, minY: 1e12, maxX: -1e12, maxY: -1e12 }, i;
        for (i = 0; i < gs.length; i++) {
            u.minX = Math.min(u.minX, gs[i].minX); u.minY = Math.min(u.minY, gs[i].minY);
            u.maxX = Math.max(u.maxX, gs[i].maxX); u.maxY = Math.max(u.maxY, gs[i].maxY);
        }
        u.w = u.maxX - u.minX; u.h = u.maxY - u.minY; u.cx = (u.minX + u.maxX) / 2; u.cy = (u.minY + u.maxY) / 2;
        return u;
    };
    /* moveWorld(): shift layers by world-space deltas; handles parenting, 3D, separated dims & keys */
    MS.moveWorld = function (comp, items, t) {
        var ex = [], map = [], i, it, r, P, q, w;
        for (i = 0; i < items.length; i++) {
            it = items[i];
            if (it.l.parent) {
                w = [it.g.ax + (it.d[0] || 0), it.g.ay + (it.d[1] || 0), it.g.az + (it.d[2] || 0)];
                ex.push(MS.L(it.l) + "var q=L.parent.fromWorld([" + MS.f(w[0]) + "," + MS.f(w[1]) + "," + MS.f(w[2]) + "]);[q[0],q[1]]");
                ex.push(MS.L(it.l) + "var q=L.parent.fromWorld([" + MS.f(w[0]) + "," + MS.f(w[1]) + "," + MS.f(w[2]) + "]);[q.length>2?q[2]:0,0]");
                map.push(i);
            }
        }
        r = MS.probe(comp, ex, t);
        for (i = 0; i < items.length; i++) {
            it = items[i];
            if (!it.l.parent) {
                MS.posAdd(it.l, [it.d[0] || 0, it.d[1] || 0, it.l.threeDLayer ? (it.d[2] || 0) : 0]);
            }
        }
        for (i = 0; i < map.length; i++) {
            it = items[map[i]];
            q = [r[i * 2][0], r[i * 2][1], r[i * 2 + 1][0]];
            P = MS.posGet(it.l, t, false);
            MS.posAdd(it.l, MS.vsub(MS.vfit(P, q), P));
        }
    };
    /* relocateAnchors(): move anchor to layer-space point "a" without visual jump.
     * Optional it.snap=[x,y] (world) + it.c (layer-space content center): the content
     * center is additionally moved onto "snap" (used by Alt = center layer in comp). */
    MS.relocateAnchors = function (comp, list, t) {
        var ex = [], i, it, r, ap, curA, newA, q, P, z, pt, core;
        for (i = 0; i < list.length; i++) {
            it = list[i];
            curA = MS.tr(it.l, "ADBE Anchor Point").valueAtTime(t, false);
            z = (it.a.length > 2) ? it.a[2] : ((MS.isArr(curA) && curA.length > 2) ? curA[2] : 0);
            if (it.a.length < 3) { it.a = [it.a[0], it.a[1], z]; }
            pt = "[" + MS.f(it.a[0]) + "," + MS.f(it.a[1]) + "," + MS.f(z) + "]";
            core = MS.L(it.l) + "var w=L.toWorld(" + pt + ");";
            if (it.snap && it.c) {
                core += "var m=L.toWorld([" + MS.f(it.c[0]) + "," + MS.f(it.c[1]) + "]);" +
                    "w=[w[0]+" + MS.f(it.snap[0]) + "-m[0],w[1]+" + MS.f(it.snap[1]) + "-m[1],w.length>2?w[2]:0];";
            }
            core += "var q=L.hasParent?L.parent.fromWorld(w):w;";
            ex.push(core + "[q[0],q[1]]");
            ex.push(core + "[q.length>2?q[2]:0,0]");
        }
        r = MS.probe(comp, ex, t);
        for (i = 0; i < list.length; i++) {
            it = list[i];
            ap = MS.tr(it.l, "ADBE Anchor Point");
            curA = ap.valueAtTime(t, false);
            if (ap.expression && ap.expressionEnabled) { ap.expression = ""; MS.setVal(ap, curA, t); }
            newA = MS.vfit(curA, it.a);
            MS.addToProp(ap, MS.vsub(newA, curA));
            q = [r[i * 2][0], r[i * 2][1], r[i * 2 + 1][0]];
            P = MS.posGet(it.l, t, false);
            MS.posAdd(it.l, MS.vsub(MS.vfit(P, q), P));
        }
    };

    /* ------------------------------ paths (masks & shape paths) ------------------------------ */
    MS.sampleShape = function (sh, steps) {
        var pts = [], v = sh.vertices, it = sh.inTangents, ot = sh.outTangents, n = v.length, i, j, s, u, p0, p1, p2, p3, a, b, c, d, segs;
        steps = steps || 10;
        if (!n) { return pts; }
        segs = sh.closed ? n : n - 1;
        pts.push([v[0][0], v[0][1]]);
        for (i = 0; i < segs; i++) {
            j = (i + 1) % n;
            p0 = v[i]; p3 = v[j];
            p1 = [v[i][0] + ot[i][0], v[i][1] + ot[i][1]];
            p2 = [v[j][0] + it[j][0], v[j][1] + it[j][1]];
            for (s = 1; s <= steps; s++) {
                u = s / steps;
                a = (1 - u) * (1 - u) * (1 - u); b = 3 * u * (1 - u) * (1 - u); c = 3 * u * u * (1 - u); d = u * u * u;
                pts.push([a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]]);
            }
        }
        return pts;
    };
    MS.boundsOf = function (pts) {
        var i, b = { left: 1e12, top: 1e12, right: -1e12, bottom: -1e12 };
        for (i = 0; i < pts.length; i++) {
            b.left = Math.min(b.left, pts[i][0]); b.top = Math.min(b.top, pts[i][1]);
            b.right = Math.max(b.right, pts[i][0]); b.bottom = Math.max(b.bottom, pts[i][1]);
        }
        b.width = b.right - b.left; b.height = b.bottom - b.top;
        return b;
    };
    MS.groupXform = function (grp, t) {
        var tg = grp.property("ADBE Vector Transform Group");
        return {
            a: tg.property("ADBE Vector Anchor").valueAtTime(t, false),
            p: tg.property("ADBE Vector Position").valueAtTime(t, false),
            s: tg.property("ADBE Vector Scale").valueAtTime(t, false),
            r: tg.property("ADBE Vector Rotation").valueAtTime(t, false)
        };
    };
    MS.applyXform = function (pt, x) {
        var dx = (pt[0] - x.a[0]) * x.s[0] / 100, dy = (pt[1] - x.a[1]) * x.s[1] / 100, rr = x.r * Math.PI / 180;
        return [x.p[0] + dx * Math.cos(rr) - dy * Math.sin(rr), x.p[1] + dx * Math.sin(rr) + dy * Math.cos(rr)];
    };
    MS.groupChain = function (shapePathProp) {   // ancestor "ADBE Vector Group"s, innermost first
        var out = [], p = shapePathProp.parentProperty;
        while (p && p.matchName !== "ADBE Root Vectors Group") {
            if (p.matchName === "ADBE Vector Group") { out.push(p); }
            p = p.parentProperty;
        }
        return out;
    };
    MS.toLayerSpace = function (shapePathProp, pts, t) {
        var chain = MS.groupChain(shapePathProp), i, j, x;
        for (i = 0; i < chain.length; i++) {
            x = MS.groupXform(chain[i], t);
            for (j = 0; j < pts.length; j++) { pts[j] = MS.applyXform(pts[j], x); }
        }
        return pts;
    };
    MS.findPath = function (l) {   // returns {type:"mask"|"shape", prop: <path property>, mask: <mask group>}
        var sp = l.selectedProperties, i, p, mp;
        for (i = 0; i < sp.length; i++) {
            p = sp[i];
            if (p.matchName === "ADBE Mask Atom") { return { type: "mask", prop: p.property("ADBE Mask Shape"), grp: p }; }
            if (p.matchName === "ADBE Mask Shape") { return { type: "mask", prop: p, grp: p.parentProperty }; }
            if (p.matchName === "ADBE Vector Shape - Group") { return { type: "shape", prop: p.property("ADBE Vector Shape"), grp: p }; }
            if (p.matchName === "ADBE Vector Shape") { return { type: "shape", prop: p, grp: p.parentProperty }; }
        }
        mp = l.property("ADBE Mask Parade");
        if (mp && mp.numProperties > 0) { return { type: "mask", prop: mp.property(1).property("ADBE Mask Shape"), grp: mp.property(1) }; }
        if (l instanceof ShapeLayer) {
            p = MS.findFirst(l.property("ADBE Root Vectors Group"), "ADBE Vector Shape - Group");
            if (p) { return { type: "shape", prop: p.property("ADBE Vector Shape"), grp: p }; }
        }
        return null;
    };
    MS.pathRect = function (l, t) {   // layer-space bounds of the selected/first mask or shape path
        var fp = MS.findPath(l), pts;
        if (!fp) { return null; }
        pts = MS.sampleShape(fp.prop.valueAtTime(t, false), 12);
        if (fp.type === "shape") { pts = MS.toLayerSpace(fp.prop, pts, t); }
        var b = MS.boundsOf(pts);
        return { left: b.left, top: b.top, width: b.width, height: b.height };
    };
    /* expression code that reads a path (mask or shape path) and returns layer-space point(s) */
    MS.pathExprRef = function (l, fp) {
        var names = [], p, chain = [], s = "";
        if (fp.type === "mask") {
            return { ref: "L.mask(" + MS.q(fp.grp.name) + ").maskPath", chain: "" };
        }
        p = fp.grp;
        while (p && p.matchName !== "ADBE Root Vectors Group") {
            if (p.matchName === "ADBE Vector Group" || p.matchName === "ADBE Vector Shape - Group") { names.unshift(p.name); }
            p = p.parentProperty;
        }
        var i, base = "L";
        for (i = 0; i < names.length; i++) {
            base += ".content(" + MS.q(names[i]) + ")";
            if (i < names.length - 1) { chain.unshift(base + ".transform"); }
        }
        for (i = 0; i < chain.length; i++) { s += "p=tf(p," + chain[i] + ");"; }
        return { ref: base + ".path", chain: s };
    };
    MS.TF_FN = "function tf(p,t){var a=t.anchorPoint,s=t.scale,r=degreesToRadians(t.rotation),x=(p[0]-a[0])*s[0]/100,y=(p[1]-a[1])*s[1]/100;return [t.position[0]+x*Math.cos(r)-y*Math.sin(r),t.position[1]+x*Math.sin(r)+y*Math.cos(r)];}";


    /* =====================================================================
     * MODULE 1 - ANCHOR & SMART EASE
     * ===================================================================== */
    MS.anchorLayers = function (comp, all) {
        var s = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select a visible layer (not a camera, light or audio layer).");
        return all ? s : [s[0]];
    };
    MS.anchorPt = function (l, c, t, useMask) {
        var fx = MS.num(c.args.fx, 0.5), fy = MS.num(c.args.fy, 0.5);
        var r = useMask ? MS.pathRect(l, t) : MS.rect(l, t);
        if (!r) { MS.fail("\"" + l.name + "\" has no mask or shape path."); }
        return { a: [r.left + r.width * fx, r.top + r.height * fy], c: [r.left + r.width / 2, r.top + r.height / 2] };
    };
    MS.anchorRun = function (c, opt) {
        var comp = MS.comp(), t = comp.time, ls = MS.anchorLayers(comp, opt.all), list = [], i, pt;
        for (i = 0; i < ls.length; i++) {
            pt = MS.anchorPt(ls[i], c, t, opt.mask);
            list.push({ l: ls[i], a: pt.a, c: pt.c, snap: opt.snap ? [comp.width / 2, comp.height / 2] : null });
        }
        MS.relocateAnchors(comp, list, t);
        return ls;
    };
    MS.T.anchor = {
        name: "Anchor Point",
        // Tier 1: move anchor of the active (first selected) layer, position compensated
        click: function (c) { MS.anchorRun(c, { all: false }); },
        // Tier 2: move anchor + snap the layer's geometric center to the comp center
        alt: function (c) { MS.anchorRun(c, { all: false, snap: true }); },
        // Tier 3: all selected layers simultaneously
        shift: function (c) { MS.anchorRun(c, { all: true }); },
        // Tier 4: anchor from active mask / shape path bounds
        ctrl: function (c) { MS.anchorRun(c, { all: false, mask: true }); },
        // Tier 5: lock anchor with a live expression (follows content bounds)
        ctrlAlt: function (c) {
            var comp = MS.comp(), t = comp.time, ls = MS.anchorRun(c, { all: true }), i, l, fx = MS.num(c.args.fx, 0.5), fy = MS.num(c.args.fy, 0.5);
            for (i = 0; i < ls.length; i++) {
                l = ls[i];
                MS.ensureExpr(MS.tr(l, "ADBE Anchor Point"),
                    "var r=sourceRectAtTime(time," + (MS.ext(l) ? "true" : "false") + ");\n" +
                    "[r.left+r.width*" + MS.f(fx) + ",r.top+r.height*" + MS.f(fy) + (l.threeDLayer ? ",value[2]]" : "]"));
            }
        },
        // Tier 6: bake anchor point expressions into static values / keyframes
        shiftCtrl: function (c) {
            var comp = MS.comp(), ls = MS.anchorLayers(comp, true), n = 0, i;
            for (i = 0; i < ls.length; i++) { if (MS.bakeProp(MS.tr(ls[i], "ADBE Anchor Point"), comp, ls[i], 1)) { n++; } }
            if (!n) { MS.fail("No anchor point expressions found on the selected layers."); }
        }
    };

    /* ---------------- Smart Easing (sliders) ---------------- */
    MS.T.ease = {
        name: "Smart Ease",
        click: function (c) {
            var comp = MS.comp(), props = MS.needKeyProps(comp), which = c.args.which || "master";
            var vin = MS.num(c.args.vin, 33), vout = MS.num(c.args.vout, 33), i, j, p, ks, k, ie, oe, inT, outT, n;
            var doIn = (which === "master" || which === "in"), doOut = (which === "master" || which === "out");
            for (i = 0; i < props.length; i++) {
                p = props[i];
                ks = p.selectedKeys;
                for (j = 0; j < ks.length; j++) {
                    k = ks[j];
                    ie = p.keyInTemporalEase(k);
                    oe = p.keyOutTemporalEase(k);
                    n = ie.length;
                    inT = p.keyInInterpolationType(k);
                    outT = p.keyOutInterpolationType(k);
                    if (doIn) { if (vin <= 0) { inT = KeyframeInterpolationType.LINEAR; } else { inT = KeyframeInterpolationType.BEZIER; ie = MS.easeArr(n, 0, vin); } }
                    if (doOut) { if (vout <= 0) { outT = KeyframeInterpolationType.LINEAR; } else { outT = KeyframeInterpolationType.BEZIER; oe = MS.easeArr(n, 0, vout); } }
                    p.setInterpolationTypeAtKey(k, inT, outT);
                    if (inT === KeyframeInterpolationType.BEZIER || outT === KeyframeInterpolationType.BEZIER) {
                        try { p.setTemporalEaseAtKey(k, ie, oe); } catch (e) {}
                    }
                }
            }
        }
    };
    /* Diamond = Linear, Square = Hold, Circle = Easy Ease */
    MS.T.interp = {
        name: "Keyframe Interpolation",
        click: function (c) {
            var comp = MS.comp(), props = MS.needKeyProps(comp), type = c.args.type, i, j, p, ks, n;
            var L = KeyframeInterpolationType.LINEAR, H = KeyframeInterpolationType.HOLD, B = KeyframeInterpolationType.BEZIER;
            for (i = 0; i < props.length; i++) {
                p = props[i];
                ks = p.selectedKeys;
                for (j = 0; j < ks.length; j++) {
                    if (type === "linear") { p.setInterpolationTypeAtKey(ks[j], L, L); }
                    else if (type === "hold") { p.setInterpolationTypeAtKey(ks[j], H, H); }
                    else {
                        p.setInterpolationTypeAtKey(ks[j], B, B);
                        n = p.keyInTemporalEase(ks[j]).length;
                        p.setTemporalEaseAtKey(ks[j], MS.easeArr(n, 0, 33.33), MS.easeArr(n, 0, 33.33));
                    }
                }
            }
        }
    };


    /* =====================================================================
     * MODULE 2 - SMART ALIGNMENT & DISTRIBUTE
     * mode: 0 Composition | 1 Selection | 2 First Selected (key layer) | 3 Mask/Path bounds
     * ===================================================================== */
    MS.maskWorldRect = function (comp, l, t) {
        var r = MS.pathRect(l, t), ex = [], res, pts, i;
        if (!r) { MS.fail("Key layer \"" + l.name + "\" has no mask or shape path."); }
        pts = [[r.left, r.top], [r.left + r.width, r.top], [r.left, r.top + r.height], [r.left + r.width, r.top + r.height]];
        for (i = 0; i < 4; i++) { ex.push(MS.L(l) + "var w=L.toWorld([" + MS.f(pts[i][0]) + "," + MS.f(pts[i][1]) + "]);[w[0],w[1]]"); }
        res = MS.probe(comp, ex, t);
        var gs = [];
        for (i = 0; i < 4; i++) { gs.push({ minX: res[i][0], minY: res[i][1], maxX: res[i][0], maxY: res[i][1] }); }
        return MS.union(gs);
    };
    MS.alignSetup = function (c, comp, t, distribute) {
        var mode = parseInt(c.args.mode, 10) || 0, ls, gs, key = null, target, movers;
        ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select the (visible) layers to align.");
        if (c.mod === "ctrl") {
            var i;
            for (i = 0; i < ls.length; i++) { if (!ls[i].threeDLayer) { ls[i].threeDLayer = true; } }
        }
        gs = MS.geo(comp, ls, t);
        movers = gs;
        if (mode === 0) {
            target = { minX: 0, minY: 0, maxX: comp.width, maxY: comp.height, w: comp.width, h: comp.height, cx: comp.width / 2, cy: comp.height / 2 };
        } else if (mode === 1) {
            target = MS.union(gs);
            if (distribute && gs.length < 3) { MS.fail("Distribute to selection needs 3 or more layers."); }
        } else {
            if (gs.length < 2) { MS.fail("Select the key layer first, then the layers to align to it."); }
            var ki = 0, j;
            if (mode === 3) {   // key = first selected layer that owns a mask / shape path
                ki = -1;
                for (j = 0; j < gs.length; j++) { if (MS.findPath(gs[j].l)) { ki = j; break; } }
                if (ki < 0) { MS.fail("Mask/Path mode: one selected layer needs a mask or shape path (it becomes the key layer)."); }
            }
            key = gs[ki];
            movers = gs.slice(0, ki).concat(gs.slice(ki + 1));
            target = (mode === 3) ? MS.maskWorldRect(comp, key.l, t) : key;
        }
        return { mode: mode, gs: gs, key: key, target: target, movers: movers };
    };
    MS.alignDeltas = function (S, op) {
        var T = S.target, m = S.movers, out = [], i, g, dx, dy, axis, sorted, n, start, end, val, first, last;
        var isDist = op.charAt(0) === "d";
        if (!isDist) {
            for (i = 0; i < m.length; i++) {
                g = m[i]; dx = 0; dy = 0;
                if (op === "left") { dx = T.minX - g.minX; }
                if (op === "hcenter") { dx = T.cx - g.cx; }
                if (op === "right") { dx = T.maxX - g.maxX; }
                if (op === "top") { dy = T.minY - g.minY; }
                if (op === "vcenter") { dy = T.cy - g.cy; }
                if (op === "bottom") { dy = T.maxY - g.maxY; }
                out.push({ g: g, l: g.l, d: [dx, dy, 0] });
            }
            return out;
        }
        axis = (op === "dleft" || op === "dhcenter" || op === "dright") ? "x" : "y";
        function v(g) {
            if (op === "dleft") { return g.minX; }
            if (op === "dhcenter") { return g.cx; }
            if (op === "dright") { return g.maxX; }
            if (op === "dtop") { return g.minY; }
            if (op === "dvcenter") { return g.cy; }
            return g.maxY;
        }
        sorted = m.slice(0);
        sorted.sort(function (a, b) { return v(a) - v(b); });
        n = sorted.length;
        if (n < 2) { MS.fail("Distribute needs at least 2 layers."); }
        first = sorted[0]; last = sorted[n - 1];
        if (S.mode === 1) {
            start = v(first); end = v(last);
        } else {
            var lo = (axis === "x") ? T.minX : T.minY, hi = (axis === "x") ? T.maxX : T.maxY;
            var s0 = (axis === "x") ? first.w : first.h, s1 = (axis === "x") ? last.w : last.h;
            if (op === "dleft" || op === "dtop") { start = lo; end = hi - s1; }
            else if (op === "dright" || op === "dbottom") { start = lo + s0; end = hi; }
            else { start = lo + s0 / 2; end = hi - s1 / 2; }
        }
        for (i = 0; i < n; i++) {
            val = start + (end - start) * (n === 1 ? 0 : i / (n - 1));
            dx = (axis === "x") ? val - v(sorted[i]) : 0;
            dy = (axis === "y") ? val - v(sorted[i]) : 0;
            out.push({ g: sorted[i], l: sorted[i].l, d: [dx, dy, 0] });
        }
        return out;
    };
    MS.alignDeltasZ = function (S, op) {
        var m = S.movers, out = [], i, tz = 0, sum = 0, mn = 1e12, mx = -1e12, sorted, n;
        for (i = 0; i < m.length; i++) { sum += m[i].az; mn = Math.min(mn, m[i].az); mx = Math.max(mx, m[i].az); }
        if (op.charAt(0) !== "d") {
            if (S.mode === 0) { tz = 0; }
            else if (S.mode === 1) { tz = (op === "left" || op === "top") ? mn : ((op === "right" || op === "bottom") ? mx : sum / m.length); }
            else { tz = S.key.az; }
            for (i = 0; i < m.length; i++) { out.push({ g: m[i], l: m[i].l, d: [0, 0, tz - m[i].az] }); }
            return out;
        }
        sorted = m.slice(0);
        sorted.sort(function (a, b) { return a.az - b.az; });
        n = sorted.length;
        if (Math.abs(mx - mn) < 0.001) { mx = mn + 100 * (n - 1); }
        for (i = 0; i < n; i++) { out.push({ g: sorted[i], l: sorted[i].l, d: [0, 0, mn + (mx - mn) * (n === 1 ? 0 : i / (n - 1)) - sorted[i].az] }); }
        return out;
    };
    MS.alignRefLayer = function (comp, S, t) {
        if (S.key) { return { l: S.key.l, w: [S.key.ax, S.key.ay, S.key.az] }; }
        var nl = MS.newNull(comp, "MS Align Ref");
        MS.tr(nl, "ADBE Anchor Point").setValue([50, 50, 0]);
        MS.tr(nl, "ADBE Position").setValue([S.target.cx, S.target.cy, 0]);
        var arr = [], i;
        for (i = 0; i < S.gs.length; i++) { arr.push(S.gs[i].l); }
        MS.placeAbove(nl, MS.topOf(arr));
        return { l: nl, w: [S.target.cx, S.target.cy, 0] };
    };
    MS.alignRun = function (c, op) {
        var comp = MS.comp(), t = comp.time, isDist = op.charAt(0) === "d", S, items, i, it, ref, P0 = [], P1, expr, o;
        S = MS.alignSetup(c, comp, t, isDist);
        items = (c.mod === "ctrl") ? MS.alignDeltasZ(S, op) : MS.alignDeltas(S, op);
        if (c.mod === "shiftCtrl") { for (i = 0; i < items.length; i++) { P0.push(MS.posGet(items[i].l, t, true)); } }
        MS.moveWorld(comp, items, t);

        if (c.mod === "alt") {                       // Tier 2: align + position keyframe at CTI
            for (i = 0; i < items.length; i++) { MS.posKey(items[i].l, t); }
        } else if (c.mod === "shift") {              // Tier 3: align + parent to the reference
            ref = MS.alignRefLayer(comp, S, t);
            for (i = 0; i < items.length; i++) { if (!MS.eqL(items[i].l, ref.l)) { try { items[i].l.parent = ref.l; } catch (e1) {} } }
        } else if (c.mod === "ctrlAlt") {            // Tier 5: expression offset link (no parenting)
            ref = MS.alignRefLayer(comp, S, t);
            for (i = 0; i < items.length; i++) {
                it = items[i];
                if (MS.eqL(it.l, ref.l)) { continue; }
                o = [it.g.ax + it.d[0] - ref.w[0], it.g.ay + it.d[1] - ref.w[1], it.g.az + it.d[2] - ref.w[2]];
                expr = "var R=thisComp.layer(" + MS.q(ref.l.name) + ");\nvar w=R.toWorld(R.anchorPoint);\n" +
                    "var p=[w[0]+" + MS.f(o[0]) + ",w[1]+" + MS.f(o[1]) + ",(w.length>2?w[2]:0)+" + MS.f(o[2]) + "];\n" +
                    "var q=hasParent?parent.fromWorld(p):p;\n" + (it.l.threeDLayer ? "[q[0],q[1],q.length>2?q[2]:value[2]]" : "[q[0],q[1]]");
                MS.posExpr(it.l, expr);
            }
        } else if (c.mod === "shiftCtrl") {          // Tier 6: procedural linear motion into the new layout
            for (i = 0; i < items.length; i++) {
                it = items[i];
                P1 = P0[i];
                expr = "var a=[" + MS.f(P1[0]) + "," + MS.f(P1[1]) + (it.l.threeDLayer ? "," + MS.f(P1.length > 2 ? P1[2] : 0) : "") + "];\n" +
                    "var k=linear(time," + MS.f(t) + "," + MS.f(t + 1) + ",0,1);\n" +
                    "[a[0]+(value[0]-a[0])*k,a[1]+(value[1]-a[1])*k" + (it.l.threeDLayer ? ",a[2]+(value[2]-a[2])*k" : "") + "]";
                MS.posExpr(it.l, expr);
            }
        }
    };
    MS.T.align = {
        name: "Align & Distribute",
        click: function (c) { MS.alignRun(c, c.args.op); },
        alt: function (c) { MS.alignRun(c, c.args.op); },
        shift: function (c) { MS.alignRun(c, c.args.op); },
        ctrl: function (c) { MS.alignRun(c, c.args.op); },
        ctrlAlt: function (c) { MS.alignRun(c, c.args.op); },
        shiftCtrl: function (c) { MS.alignRun(c, c.args.op); }
    };

    /* ---------------- 2.3 Text to Shape Center ---------------- */
    MS.textShapePair = function (comp) {
        var ls = MS.sel(comp, 2), txt = null, shp = null, i;
        for (i = 0; i < ls.length; i++) {
            if (!txt && MS.isText(ls[i])) { txt = ls[i]; }
            else if (!shp && MS.isVisual(ls[i]) && ls[i] !== txt) { shp = ls[i]; }
        }
        if (!txt || !shp) { MS.fail("Select one text layer and one shape (or any visual) layer."); }
        return { txt: txt, shp: shp };
    };
    MS.textCenterExpr = function (l) {
        return "var r=sourceRectAtTime(time,false);\n[r.left+r.width/2,r.top+r.height/2" + (l.threeDLayer ? ",value[2]]" : "]");
    };
    MS.centerTextOn = function (comp, pair, t) {
        var g = MS.geo(comp, [pair.txt, pair.shp], t);
        MS.moveWorld(comp, [{ l: pair.txt, g: g[0], d: [g[1].cx - g[0].cx, g[1].cy - g[0].cy, 0] }], t);
    };
    MS.T.textShape = {
        name: "Text to Shape Center",
        click: function () {
            var comp = MS.comp();
            MS.centerTextOn(comp, MS.textShapePair(comp), comp.time);
        },
        alt: function () {
            var comp = MS.comp(), t = comp.time, pair = MS.textShapePair(comp), r = pair.txt.sourceRectAtTime(t, false), s = pair.shp, ext = MS.ext(s) ? "true" : "false";
            MS.relocateAnchors(comp, [{ l: pair.txt, a: [r.left + r.width / 2, r.top + r.height / 2] }], t);
            MS.ensureExpr(MS.tr(pair.txt, "ADBE Anchor Point"), MS.textCenterExpr(pair.txt));
            MS.posExpr(pair.txt, "var S=thisComp.layer(" + MS.q(s.name) + ");\nvar r=S.sourceRectAtTime(time," + ext + ");\n" +
                "var c=S.toWorld([r.left+r.width/2,r.top+r.height/2]);\nvar q=hasParent?parent.fromWorld(c):c;\n" +
                (pair.txt.threeDLayer ? "[q[0],q[1],q.length>2?q[2]:value[2]]" : "[q[0],q[1]]"));
        },
        shift: function () {
            var comp = MS.comp(), t = comp.time, pair = MS.textShapePair(comp), s = pair.shp, rectP, grp;
            if (!MS.isShape(s)) { MS.fail("Auto-resize needs a shape layer as the background."); }
            MS.slider(s, "MS Padding", 24);
            rectP = MS.findFirst(s.property("ADBE Root Vectors Group"), "ADBE Vector Shape - Rect");
            if (!rectP) {
                grp = MS.newGroupIdx(s, "MS Text Box");
                MS.addRect(MS.grpContents(s, grp), [200, 100], [0, 0], 0);
                MS.addFill(MS.grpContents(s, grp), [0.12, 0.12, 0.14]);
                rectP = MS.findFirst(s.property("ADBE Root Vectors Group"), "ADBE Vector Shape - Rect");
            }
            MS.ensureExpr(rectP.property("ADBE Vector Rect Size"),
                "var T=thisComp.layer(" + MS.q(pair.txt.name) + ");\nvar r=T.sourceRectAtTime(time,false);\n" +
                "var pad=effect(\"MS Padding\")(1);\nvar ts=T.transform.scale, ss=transform.scale;\n" +
                "[(r.width*ts[0]/100+pad*2)/(ss[0]/100),(r.height*ts[1]/100+pad*2)/(ss[1]/100)]");
            MS.centerTextOn(comp, pair, t);
        }
    };

    /* ---------------- 2.3 Text paragraph justification ---------------- */
    MS.T.justify = {
        name: "Text Justification",
        click: function (c) {
            var comp = MS.comp(), t = comp.time, ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isText), "Select text layers."), i, p, td;
            var j = c.args.j === "center" ? ParagraphJustification.CENTER_JUSTIFY : (c.args.j === "right" ? ParagraphJustification.RIGHT_JUSTIFY : ParagraphJustification.LEFT_JUSTIFY);
            for (i = 0; i < ls.length; i++) {
                p = ls[i].property("ADBE Text Properties").property("ADBE Text Document");
                td = p.valueAtTime(t, true);
                td.justification = j;
                MS.setVal(p, td, t);
            }
        }
    };


    /* =====================================================================
     * MODULE 3A - LAYER CREATION SUITE
     * ===================================================================== */
    MS.newSolidBase = function (c, name, rgb) {
        var comp = MS.comp(), sel = MS.sel(comp), col = rgb || MS.argColor(c);
        var l = comp.layers.addSolid(col, MS.uniq(comp, name), comp.width, comp.height, comp.pixelAspect, comp.duration);
        MS.placeAbove(l, MS.topOf(sel));
        return { comp: comp, l: l, col: col };
    };
    MS.T.solid = {
        name: "New Solid",
        alt: function (c) {     // New Shape Layer (comp size rectangle + fill)
            var comp = MS.comp(), sel = MS.sel(comp), col = MS.argColor(c), s = MS.newShape(comp, "MS Shape"), gi;
            gi = MS.newGroupIdx(s, "Rectangle 1");
            MS.addRect(MS.grpContents(s, gi), [comp.width, comp.height], [0, 0]);
            MS.addFill(MS.grpContents(s, gi), col);
            MS.tr(s, "ADBE Anchor Point").setValue([0, 0]);
            MS.tr(s, "ADBE Position").setValue([comp.width / 2, comp.height / 2]);
            MS.placeAbove(s, MS.topOf(sel));
        },
        click: function (c) {   // Solid + Fill effect
            var o = MS.newSolidBase(c, "MS Solid"), e = MS.addFx(o.l, "ADBE Fill", "MS Fill");
            MS.firstOfType(e, PropertyValueType.COLOR).setValue([o.col[0], o.col[1], o.col[2], 1]);
        },
        ctrl: function (c) {    // Solid + 4-Color Gradient
            var o = MS.newSolidBase(c, "MS 4-Color Gradient"), pal = MS.argPalette(c), w = o.comp.width, h = o.comp.height;
            var e = MS.addFx(o.l, "ADBE 4ColorGradient", "MS 4-Color Gradient"), pts = [[w * 0.1, h * 0.1], [w * 0.9, h * 0.1], [w * 0.1, h * 0.9], [w * 0.9, h * 0.9]], i, cp, pp;
            for (i = 0; i < 4; i++) {
                pp = MS.firstOfType(MS.getFx(o.l, "MS 4-Color Gradient"), "point", i);
                if (pp) { pp.setValue(pts[i]); }
                cp = MS.firstOfType(MS.getFx(o.l, "MS 4-Color Gradient"), PropertyValueType.COLOR, i);
                if (cp) { cp.setValue([pal[i % pal.length][0], pal[i % pal.length][1], pal[i % pal.length][2], 1]); }
            }
        },
        shiftCtrlAlt: function (c) {   // Solid + Fractal Noise (evolving)
            var o = MS.newSolidBase(c, "MS Fractal Noise", [0, 0, 0]), e = MS.addFx(o.l, "ADBE Fractal Noise", "MS Fractal Noise");
            // Evolution is located by its (English) name; other languages keep a static noise.
            try { if (e.property("Evolution")) { e.property("Evolution").expression = "time*90"; } } catch (e1) {}
        },
        shift: function (c) {   // Solid + Gradient Ramp
            var o = MS.newSolidBase(c, "MS Gradient Ramp"), pal = MS.argPalette(c), w = o.comp.width, h = o.comp.height;
            var e = MS.addFx(o.l, "ADBE Ramp", "MS Gradient Ramp"), p0 = MS.firstOfType(e, "point", 0);
            if (p0) { p0.setValue([w / 2, 0]); }
            e = MS.getFx(o.l, "MS Gradient Ramp");
            var p1 = MS.firstOfType(e, "point", 1);
            if (p1) { p1.setValue([w / 2, h]); }
            var c0 = MS.firstOfType(MS.getFx(o.l, "MS Gradient Ramp"), PropertyValueType.COLOR, 0);
            if (c0) { c0.setValue([o.col[0], o.col[1], o.col[2], 1]); }
            var c1 = MS.firstOfType(MS.getFx(o.l, "MS Gradient Ramp"), PropertyValueType.COLOR, 1), k = pal.length > 1 ? pal[1] : [0, 0, 0];
            if (c1) { c1.setValue([k[0], k[1], k[2], 1]); }
        },
        ctrlAlt: function (c) { // Solid + Grid
            var o = MS.newSolidBase(c, "MS Grid", [0, 0, 0]), e = MS.addFx(o.l, "ADBE Grid", "MS Grid"), cp = MS.firstOfType(e, PropertyValueType.COLOR, 0), col = MS.argColor(c);
            if (cp) { cp.setValue([col[0], col[1], col[2], 1]); }
        },
        shiftCtrl: function (c) {   // Vignette setup (mask based - works in every AE version)
            var o = MS.newSolidBase(c, "MS Vignette", [0, 0, 0]), w = o.comp.width, h = o.comp.height, m;
            m = MS.addMask(o.l, MS.ellipseShape(w / 2, h / 2, w * 0.62, h * 0.62), "MS Vignette Mask");
            m.inverted = true;
            m.property("ADBE Mask Feather").setValue([Math.round(Math.min(w, h) * 0.45), Math.round(Math.min(w, h) * 0.45)]);
            MS.tr(o.l, "ADBE Opacity").setValue(75);
        }
    };

    /* ---------------- New Null / Adjustment Layer (shared modifier matrix) ---------------- */
    MS.helperLayer = function (c, kind) {
        var comp = MS.comp(), t = comp.time, sel = MS.sel(comp), vis = MS.filter(sel, MS.isVisual), l, g = null, w = comp.width, h = comp.height, cx = w / 2, cy = h / 2, base, i;
        if (c.mod === "alt") {
            if (!vis.length) { MS.fail("Select a layer to match its dimensions."); }
            g = MS.geo(comp, [vis[0]], t)[0];
            w = Math.max(4, g.w); h = Math.max(4, g.h); cx = g.cx; cy = g.cy;
        } else if (c.mod === "shift" && vis.length) {
            g = MS.union(MS.geo(comp, vis, t));
            cx = g.cx; cy = g.cy;
        }
        if (kind === "null") {
            base = MS.newNull(comp, "MS Null", w, h);
            l = base;
        } else {
            l = comp.layers.addSolid([1, 1, 1], MS.uniq(comp, "MS Adjustment"), Math.round(w), Math.round(h), comp.pixelAspect, comp.duration);
            l.adjustmentLayer = true;
            l.label = 5;
        }
        MS.tr(l, "ADBE Position").setValue([cx, cy, 0]);
        MS.placeAbove(l, MS.topOf(sel));
        if (c.mod === "shift") {                   // auto-parent selected layers
            for (i = 0; i < sel.length; i++) { if (!MS.eqL(sel[i], l)) { try { sel[i].parent = l; } catch (e1) {} } }
        } else if (c.mod === "ctrl") {             // start at CTI
            l.inPoint = Math.min(t, comp.duration - comp.frameDuration);
        } else if (c.mod === "ctrlAlt") {          // expression-link selected layers to the new layer
            var nm = l.name, p0 = [cx, cy];
            for (i = 0; i < sel.length; i++) {
                if (MS.eqL(sel[i], l) || !MS.isAV(sel[i]) && !(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) { continue; }
                MS.posExpr(sel[i], "var N=thisComp.layer(" + MS.q(nm) + ");\nvar p=N.transform.position;\n" +
                    "var d=[p[0]-" + MS.f(p0[0]) + ",p[1]-" + MS.f(p0[1]) + "];\n" +
                    (sel[i].threeDLayer ? "[value[0]+d[0],value[1]+d[1],value[2]]" : "[value[0]+d[0],value[1]+d[1]]"));
                try { MS.ensureExpr(MS.tr(sel[i], "ADBE Rotate Z"), "value+thisComp.layer(" + MS.q(nm) + ").transform.rotation"); } catch (e2) {}
                try { MS.ensureExpr(MS.tr(sel[i], "ADBE Opacity"), "value*thisComp.layer(" + MS.q(nm) + ").transform.opacity/100"); } catch (e3) {}
            }
        } else if (c.mod === "shiftCtrl") {        // trim to work area
            var wa0 = comp.workAreaStart, wa1 = comp.workAreaStart + comp.workAreaDuration;
            l.inPoint = wa0;
            l.outPoint = wa1;
        }
        return l;
    };
    MS.T.nullObj = {
        name: "New Null Object",
        click: function (c) { MS.helperLayer(c, "null"); },
        alt: function (c) { MS.helperLayer(c, "null"); },
        shift: function (c) { MS.helperLayer(c, "null"); },
        ctrl: function (c) { MS.helperLayer(c, "null"); },
        ctrlAlt: function (c) { MS.helperLayer(c, "null"); },
        shiftCtrl: function (c) { MS.helperLayer(c, "null"); }
    };
    MS.T.adjLayer = {
        name: "New Adjustment Layer",
        click: function (c) { MS.helperLayer(c, "adj"); },
        alt: function (c) { MS.helperLayer(c, "adj"); },
        shift: function (c) { MS.helperLayer(c, "adj"); },
        ctrl: function (c) { MS.helperLayer(c, "adj"); },
        ctrlAlt: function (c) { MS.helperLayer(c, "adj"); },
        shiftCtrl: function (c) { MS.helperLayer(c, "adj"); }
    };

    /* ---------------- New Camera ---------------- */
    MS.camOpt = function (cam, mn) { return cam.property("ADBE Camera Options Group").property(mn); };
    MS.newCam = function (comp, name) {
        var cam = comp.layers.addCamera(MS.uniq(comp, name), [comp.width / 2, comp.height / 2]);
        return cam;
    };
    MS.null3D = function (comp, name, pos) {
        var n = MS.newNull(comp, name);
        n.threeDLayer = true;
        MS.tr(n, "ADBE Anchor Point").setValue([50, 50, 0]);
        MS.tr(n, "ADBE Position").setValue(pos);
        n.label = 2;
        return n;
    };
    MS.T.camera = {
        name: "New Camera",
        click: function () { MS.newCam(MS.comp(), "MS Camera"); },
        alt: function () {
            var comp = MS.comp(), sel = MS.sel(comp, 1), cam = MS.newCam(comp, "MS Camera");
            cam.inPoint = Math.max(0, sel[0].inPoint);
        },
        shift: function () {
            var comp = MS.comp(), cam = MS.newCam(comp, "MS Camera"), ctl = MS.null3D(comp, "MS Camera Control", [comp.width / 2, comp.height / 2, 0]);
            cam.parent = ctl;
            cam.moveAfter(ctl);
        },
        ctrl: function () {
            var cam = MS.newCam(MS.comp(), "MS Camera 1-Node");
            cam.autoOrient = AutoOrientType.NO_AUTO_ORIENT;
        },
        ctrlAlt: function () {   // Pro rig: Position null -> Orbit null -> Tilt null -> one-node camera
            var comp = MS.comp(), c0 = [comp.width / 2, comp.height / 2, 0];
            var cam = MS.newCam(comp, "MS Pro Camera"), zoom = MS.camOpt(cam, "ADBE Camera Zoom").value;
            cam.autoOrient = AutoOrientType.NO_AUTO_ORIENT;
            MS.tr(cam, "ADBE Position").setValue([c0[0], c0[1], -zoom]);
            var tilt = MS.null3D(comp, "MS CAM Tilt", c0), orbit = MS.null3D(comp, "MS CAM Orbit", c0), pos = MS.null3D(comp, "MS CAM Position", c0);
            orbit.parent = pos;
            tilt.parent = orbit;
            cam.parent = tilt;
            orbit.moveAfter(pos);
            tilt.moveAfter(orbit);
            cam.moveAfter(tilt);
            MS.slider(pos, "MS Dolly (Z)", 0);
            MS.ensureExpr(MS.tr(cam, "ADBE Position"), "[value[0],value[1],value[2]+thisComp.layer(" + MS.q(pos.name) + ").effect(\"MS Dolly (Z)\")(1)]");
        },
        shiftCtrl: function () { // Auto Depth of Field focused on the selected layer
            var comp = MS.comp(), sel = MS.filter(MS.sel(comp), MS.isVisual), target, cam;
            if (sel.length) { target = sel[0]; if (!target.threeDLayer) { target.threeDLayer = true; } }
            else { target = MS.null3D(comp, "MS Focus Target", [comp.width / 2, comp.height / 2, 0]); }
            cam = MS.newCam(comp, "MS DoF Camera");
            MS.camOpt(cam, "ADBE Camera Depth of Field").setValue(1);
            try { MS.camOpt(cam, "ADBE Camera Aperture").setValue(60); } catch (e1) {}
            try { MS.camOpt(cam, "ADBE Camera Blur Level").setValue(100); } catch (e2) {}
            MS.ensureExpr(MS.camOpt(cam, "ADBE Camera Focus Distance"),
                "var T=thisComp.layer(" + MS.q(target.name) + ");\nvar v=sub(T.toWorld(T.anchorPoint),toWorld([0,0,0]));\nMath.max(1,Math.abs(dot(v,toWorldVec([0,0,1]))))");
        }
    };

    /* ---------------- 3B New Composition ---------------- */
    MS.makeComp = function (name, w, h, pa, dur, fps) {
        var base = MS.compOrNull(), comp;
        w = Math.round(MS.clamp(w, 4, 30000)); h = Math.round(MS.clamp(h, 4, 30000));
        fps = MS.clamp(fps, 1, 999); dur = MS.clamp(dur, 1 / fps, 10800);
        comp = app.project.items.addComp(name, w, h, pa || 1, dur, fps);
        try { if (base) { comp.parentFolder = base.parentFolder; } } catch (e) {}
        try { comp.openInViewer(); } catch (e2) {}
        return comp;
    };
    MS.compBase = function () {
        var b = MS.compOrNull();
        return { w: b ? b.width : 1920, h: b ? b.height : 1080, fps: b ? b.frameRate : 30, dur: b ? b.duration : 10, pa: b ? b.pixelAspect : 1 };
    };
    MS.T.newComp = {
        name: "New Composition",
        click: function () { var b = MS.compBase(); MS.makeComp("MS Comp", b.w, b.h, b.pa, b.dur, b.fps); },
        alt: function () {
            var b = MS.compBase(), it = null, s = app.project.selection, cmp, sl;
            if (s && s.length && (s[0] instanceof AVItem)) { it = s[0]; }
            if (!it) { cmp = MS.compOrNull(); sl = cmp ? cmp.selectedLayers : []; if (sl.length && sl[0].source && (sl[0].source instanceof AVItem)) { it = sl[0].source; } }
            if (!it) { MS.fail("Select a footage/comp item in the Project panel (or a layer)."); }
            MS.makeComp(it.name + " Comp", it.width, it.height, it.pixelAspect || 1, it.duration > 0 ? it.duration : b.dur, it.frameRate > 0 ? it.frameRate : b.fps);
        },
        shift: function () { var b = MS.compBase(); MS.makeComp("MS 1080p", 1920, 1080, 1, b.dur, 30); },
        ctrl: function () { var b = MS.compBase(); MS.makeComp("MS 4K UHD", 3840, 2160, 1, b.dur, b.fps); },
        ctrlAlt: function () { var b = MS.compBase(); MS.makeComp("MS Square 1x1", 1080, 1080, 1, b.dur, b.fps); },
        shiftCtrl: function () {
            var b = MS.compBase(), s = prompt("Custom composition:  Width x Height @ FPS , Duration (sec)", Math.round(b.w) + "x" + Math.round(b.h) + "@" + b.fps + "," + Math.round(b.dur * 100) / 100, "MotionSeeds - New Composition"), m;
            if (s === null) { return; }
            m = String(s).match(/(\d+)\s*[xX\*]\s*(\d+)\s*(?:@\s*([\d\.]+))?\s*(?:,\s*([\d\.]+))?/);
            if (!m) { MS.fail("Format: 1920x1080@30,10"); }
            MS.makeComp("MS Custom Comp", parseInt(m[1], 10), parseInt(m[2], 10), 1, m[4] ? parseFloat(m[4]) : b.dur, m[3] ? parseFloat(m[3]) : b.fps);
        },
        shiftCtrlAlt: function () { var b = MS.compBase(); MS.makeComp("MS Reels 9x16", 1080, 1920, 1, b.dur, b.fps); }
    };

    /* ---------------- Pre-compose ---------------- */
    MS.precomp = function (c) {
        var comp = MS.comp(), sel = MS.sel(comp, 1), idx = [], i, nc, nm, move = (c.mod !== "alt");
        if (!move && sel.length !== 1) { MS.fail("\"Leave all attributes\" works with exactly one selected layer."); }
        for (i = 0; i < sel.length; i++) { idx.push(sel[i].index); }
        idx.sort(function (a, b) { return a - b; });
        nm = (sel.length === 1 ? sel[0].name : "MS Precomp") + " Comp";
        nc = comp.layers.precompose(idx, nm, move);
        return { comp: comp, nc: nc, layer: comp.selectedLayers.length ? comp.selectedLayers[0] : null };
    };
    MS.findCompLayer = function (comp, nc) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) { try { if (comp.layer(i).source && comp.layer(i).source.id === nc.id) { return comp.layer(i); } } catch (e) {} }
        return null;
    };
    MS.T.precompose = {
        name: "Pre-compose",
        click: function (c) { MS.precomp(c); },
        alt: function (c) { MS.precomp(c); },
        shift: function (c) {     // trim precomp duration to its layers
            var r = MS.precomp(c), nc = r.nc, i, mn = 1e9, mx = -1e9, l, pl;
            for (i = 1; i <= nc.numLayers; i++) { mn = Math.min(mn, nc.layer(i).inPoint); mx = Math.max(mx, nc.layer(i).outPoint); }
            mn = Math.max(0, mn);
            if (mx - mn < nc.frameDuration) { return; }
            for (i = 1; i <= nc.numLayers; i++) { l = nc.layer(i); l.startTime = l.startTime - mn; }
            nc.duration = mx - mn;
            pl = MS.findCompLayer(r.comp, nc);
            if (pl) { pl.startTime = mn; pl.inPoint = mn; pl.outPoint = mx; }
        },
        ctrl: function (c) { var r = MS.precomp(c); try { r.nc.openInViewer(); } catch (e) {} },
        ctrlAlt: function (c) {   // bake expressions inside the precomp
            var r = MS.precomp(c), i;
            for (i = 1; i <= r.nc.numLayers; i++) { MS.bakeLayer(r.nc, r.nc.layer(i), 1); }
        },
        shiftCtrl: function (c) { // crop precomp dimensions to its content region
            var r = MS.precomp(c), nc = r.nc, t = r.comp.time, vis = [], i, u, W, H, l, pl, cam;
            for (i = 1; i <= nc.numLayers; i++) { if (MS.isVisual(nc.layer(i)) && nc.layer(i).enabled) { vis.push(nc.layer(i)); } }
            if (!vis.length) { return; }
            u = MS.union(MS.geo(nc, vis, Math.max(0, t)));
            W = Math.max(4, Math.ceil(u.w)); H = Math.max(4, Math.ceil(u.h));
            if (W > 30000 || H > 30000) { MS.fail("Region too large to crop."); }
            for (i = 1; i <= nc.numLayers; i++) {
                l = nc.layer(i);
                if (l.parent) { continue; }
                MS.posAdd(l, [-u.minX, -u.minY, 0]);
                cam = (l instanceof CameraLayer) || (l instanceof LightLayer);
                if (cam) { try { MS.addToProp(MS.tr(l, "ADBE Anchor Point"), [-u.minX, -u.minY, 0]); } catch (e1) {} }
            }
            nc.width = W; nc.height = H;
            pl = MS.findCompLayer(r.comp, nc);
            if (pl) {
                MS.tr(pl, "ADBE Anchor Point").setValue([W / 2, H / 2, 0]);
                MS.tr(pl, "ADBE Position").setValue([u.minX + W / 2, u.minY + H / 2, 0]);
            }
        }
    };

    /* ---------------- Split Layer ---------------- */
    MS.splitAt = function (l, t) {
        if (t <= l.inPoint + 1e-6 || t >= l.outPoint - 1e-6) { return null; }
        var d = l.duplicate();
        l.outPoint = t;
        d.inPoint = t;
        return d;
    };
    MS.T.split = {
        name: "Split Layer",
        click: function () {
            var comp = MS.comp(), sel = MS.sel(comp, 1), i, n = 0;
            for (i = 0; i < sel.length; i++) { if (MS.splitAt(sel[i], comp.time)) { n++; } }
            if (!n) { MS.fail("Move the time indicator inside the selected layer(s) first."); }
        },
        alt: function () {
            var comp = MS.comp(), sel = MS.sel(comp, 1), i;
            for (i = 0; i < sel.length; i++) { if (comp.time > sel[i].inPoint) { sel[i].outPoint = comp.time; } }
        },
        shift: function () {
            var comp = MS.comp(), t = comp.time, sel = MS.sel(comp, 1), i, d, n = 0;
            for (i = 0; i < sel.length; i++) {
                d = MS.splitAt(sel[i], t);
                if (!d) { continue; }
                n++;
                MS.walk(sel[i], function (p) { if (p.numKeys > 0 && p.propertyValueType !== PropertyValueType.MARKER) { MS.removeKeysIn(p, t + 1e-4, 1e7); } });
                MS.walk(d, function (p) { if (p.numKeys > 0 && p.propertyValueType !== PropertyValueType.MARKER) { MS.removeKeysIn(p, -1e7, t - 1e-4); } });
            }
            if (!n) { MS.fail("Move the time indicator inside the selected layer(s) first."); }
        },
        ctrl: function () {
            var comp = MS.comp(), sel = MS.sel(comp, 1), i;
            for (i = 0; i < sel.length; i++) { if (comp.time < sel[i].outPoint) { sel[i].inPoint = comp.time; } }
        },
        ctrlAlt: function () {  // split + 5-frame crossfade
            var comp = MS.comp(), t = comp.time, sel = MS.sel(comp, 1), fd = comp.frameDuration * 5, i, l, d, op, end, n = 0;
            for (i = 0; i < sel.length; i++) {
                l = sel[i];
                if (t <= l.inPoint || t + fd >= l.outPoint) { continue; }
                d = l.duplicate();
                l.outPoint = t + fd;
                d.inPoint = t;
                op = MS.tr(d, "ADBE Opacity");
                end = op.valueAtTime(t + fd, true);
                op.setValueAtTime(t, 0);
                op.setValueAtTime(t + fd, end);
                n++;
            }
            if (!n) { MS.fail("Need at least 5 frames of layer after the time indicator."); }
        },
        shiftCtrl: function () {
            var comp = MS.comp(), sel = MS.sel(comp, 1), a = comp.workAreaStart, b = comp.workAreaStart + comp.workAreaDuration, i, l;
            for (i = 0; i < sel.length; i++) {
                l = sel[i];
                if (l.outPoint <= a || l.inPoint >= b) { continue; }
                if (l.inPoint < a) { l.inPoint = a; }
                if (l.outPoint > b) { l.outPoint = b; }
            }
        }
    };

    /* ---------------- Add Fill ---------------- */
    MS.applyFillFx = function (l, rgb) {
        var e = MS.getFx(l, "MS Fill");
        if (!e) { e = MS.addFx(l, "ADBE Fill", "MS Fill"); }
        MS.firstOfType(MS.getFx(l, "MS Fill"), PropertyValueType.COLOR).setValue([rgb[0], rgb[1], rgb[2], 1]);
        return e;
    };
    MS.T.fill = {
        name: "Add Fill",
        click: function (c) {
            var comp = MS.comp(), ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select visual layers."), i, col = MS.argColor(c);
            for (i = 0; i < ls.length; i++) { MS.applyFillFx(ls[i], col); }
        },
        alt: function () {      // pick color from the layer itself (sampled at the CTI)
            var comp = MS.comp(), ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select visual layers."), i, col;
            for (i = 0; i < ls.length; i++) {
                col = MS.dominantColor(comp, ls[i], comp.time);
                MS.applyFillFx(ls[i], col);
            }
            return MS.rgb2hex(col);
        }
    };


    /* =====================================================================
     * MODULE 3C - EXPRESSIONS & CLONING
     * ===================================================================== */
    MS.NUMERIC = function (p) {
        var v = p.propertyValueType;
        return v === PropertyValueType.OneD || v === PropertyValueType.TwoD || v === PropertyValueType.ThreeD ||
            v === PropertyValueType.TwoD_SPATIAL || v === PropertyValueType.ThreeD_SPATIAL || v === PropertyValueType.COLOR;
    };
    /* selected keyframed properties, or (fallback) keyframed transform properties of selected layers */
    MS.exprTargets = function (comp, minKeys, allowFallback, transformOnly) {
        var sp = MS.selProps(comp), out = [], i, ls;
        for (i = 0; i < sp.length; i++) { if (sp[i].canSetExpression && MS.NUMERIC(sp[i]) && sp[i].numKeys >= minKeys) { out.push(sp[i]); } }
        if (!out.length && allowFallback) {
            ls = MS.sel(comp);
            for (i = 0; i < ls.length; i++) {
                MS.walk(transformOnly ? ls[i].property("ADBE Transform Group") : ls[i], function (p) {
                    if (p.canSetExpression && MS.NUMERIC(p) && p.numKeys >= minKeys) { out.push(p); }
                });
            }
        }
        return out;
    };
    MS.propsWithExpr = function (comp, test) {   // selected props, or every prop of selected layers
        var sp = MS.selProps(comp), out = [], i, ls;
        for (i = 0; i < sp.length; i++) { if (sp[i].canSetExpression && sp[i].expression && test(sp[i].expression)) { out.push(sp[i]); } }
        if (!out.length) {
            ls = MS.sel(comp);
            for (i = 0; i < ls.length; i++) { MS.walk(ls[i], function (p) { if (p.canSetExpression && p.expression && test(p.expression)) { out.push(p); } }); }
        }
        return out;
    };

    /* ---------------- Bounce ---------------- */
    MS.BOUNCE_SIG = "Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t)";
    MS.bounceExpr = function (amp, freq, decay) {
        return "n = 0;\nif (numKeys > 0) {\nn = nearestKey(time).index;\nif (key(n).time > time){\nn--;\n}\n}\n" +
            "if (n == 0) {\nt = 0;\n} else {\nt = time - key(n).time;\n}\n" +
            "if (n > 0 && t < 1){\nv = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n" +
            "amp = " + amp + ";\nfreq = " + freq + ";\ndecay = " + decay + ";\n" +
            "value + (v/100)*amp*Math.sin(freq*t*2*Math.PI)/Math.exp(decay*t);\n}else{\nvalue;\n}";
    };
    MS.isBounce = function (e) { return e.indexOf(MS.BOUNCE_SIG) !== -1; };
    MS.T.bounce = {
        name: "Bounce Expression",
        click: function () {
            var comp = MS.comp(), ps = MS.needSome(MS.exprTargets(comp, 1, false), "Select a keyframed property (e.g. Position, Scale)."), i;
            for (i = 0; i < ps.length; i++) { MS.ensureExpr(ps[i], MS.bounceExpr("4", "2.0", "6.0")); }
        },
        alt: function () {      // bounce + 3 master slider controls
            var comp = MS.comp(), ps = MS.needSome(MS.exprTargets(comp, 1, false), "Select a keyframed property (e.g. Position, Scale)."), i, l, done = [], refs = [], p;
            for (i = 0; i < ps.length; i++) { refs.push({ l: MS.ownerLayer(ps[i]), path: MS.propPath(ps[i]) }); }
            for (i = 0; i < refs.length; i++) {
                l = refs[i].l;
                if (MS.idxL(done, l) === -1) {
                    MS.slider(l, "MS Bounce Amplitude", 4);
                    MS.slider(l, "MS Bounce Frequency", 2);
                    MS.slider(l, "MS Bounce Decay", 6);
                    done.push(l);
                }
            }
            for (i = 0; i < refs.length; i++) {
                p = MS.resolvePath(refs[i].l, refs[i].path);
                if (p) { MS.ensureExpr(p, MS.bounceExpr("effect(\"MS Bounce Amplitude\")(1)", "effect(\"MS Bounce Frequency\")(1)", "effect(\"MS Bounce Decay\")(1)")); }
            }
        },
        shift: function () {    // all keyframed transform properties of the selected layers
            var comp = MS.comp(), ls = MS.sel(comp, 1), i, n = 0;
            for (i = 0; i < ls.length; i++) {
                MS.walk(ls[i].property("ADBE Transform Group"), function (p) {
                    if (p.numKeys > 0 && p.canSetExpression && MS.NUMERIC(p)) { MS.ensureExpr(p, MS.bounceExpr("4", "2.0", "6.0")); n++; }
                });
            }
            if (!n) { MS.fail("No keyframed transform properties on the selected layers."); }
        },
        ctrl: function () {
            var comp = MS.comp(), ps = MS.needSome(MS.propsWithExpr(comp, MS.isBounce), "No bounce expressions found."), i;
            for (i = 0; i < ps.length; i++) { ps[i].expression = ""; }
        },
        ctrlAlt: function () {  // bake physics into keyframes
            var comp = MS.comp(), ps = MS.needSome(MS.propsWithExpr(comp, MS.isBounce), "No bounce expressions found to bake."), i;
            for (i = 0; i < ps.length; i++) { MS.bakeProp(ps[i], comp, MS.ownerLayer(ps[i]), 1); }
        },
        shiftCtrl: function () { // randomize bounce parameters per property
            var comp = MS.comp(), ps = MS.propsWithExpr(comp, MS.isBounce), i;
            if (!ps.length) { ps = MS.needSome(MS.exprTargets(comp, 1, true, true), "Select keyframed properties or layers."); }
            for (i = 0; i < ps.length; i++) {
                MS.ensureExpr(ps[i], MS.bounceExpr(MS.f(Math.round(MS.rnd(2, 8) * 10) / 10), MS.f(Math.round(MS.rnd(1.2, 3.4) * 10) / 10), MS.f(Math.round(MS.rnd(4, 9) * 10) / 10)));
            }
        }
    };

    /* ---------------- Text Animation ---------------- */
    MS.TXT_ANIMS = function (l) { return l.property("ADBE Text Properties").property("ADBE Text Animators"); };
    MS.addTextAnimator = function (l, name, propMns, selectorMn) {
        var an = MS.TXT_ANIMS(l).addProperty("ADBE Text Animator"), idx = an.propertyIndex, i;
        an.name = name;
        for (i = 0; i < propMns.length; i++) { MS.TXT_ANIMS(l).property(idx).property("ADBE Text Animator Properties").addProperty(propMns[i]); }
        MS.TXT_ANIMS(l).property(idx).property("ADBE Text Selectors").addProperty(selectorMn);
        return idx;
    };
    MS.animProp = function (l, idx, mn) { return MS.TXT_ANIMS(l).property(idx).property("ADBE Text Animator Properties").property(mn); };
    MS.animSel = function (l, idx) { return MS.TXT_ANIMS(l).property(idx).property("ADBE Text Selectors").property(1); };
    MS.textLayers = function (comp) { return MS.needSome(MS.filter(MS.sel(comp, 1), MS.isText), "Select one or more text layers."); };
    MS.TEXT_BOUNCE = "delay = 0.09; myDelay = delay*textIndex; t = (time - inPoint) - myDelay; if (t >= 0) { freq =2; amplitude = 50; decay = 7.0; s = amplitude*Math.cos(freq*t*2*Math.PI)/Math.exp(decay*t); [s,s] } else { value }";
    MS.T.textAnim = {
        name: "Text Animation",
        click: function () {    // Scale animator + bounce expression
            var comp = MS.comp(), ls = MS.textLayers(comp), i, idx;
            for (i = 0; i < ls.length; i++) {
                idx = MS.addTextAnimator(ls[i], "MS Scale Bounce", ["ADBE Text Scale 3D"], "ADBE Text Expressible Selector");
                MS.animProp(ls[i], idx, "ADBE Text Scale 3D").setValue([0, 0, 0]);
                MS.animSel(ls[i], idx).property("ADBE Text Expressible Amount").expression = MS.TEXT_BOUNCE;
            }
        },
        alt: function () {      // position drop + overshoot
            var comp = MS.comp(), ls = MS.textLayers(comp), i, idx;
            for (i = 0; i < ls.length; i++) {
                idx = MS.addTextAnimator(ls[i], "MS Drop Overshoot", ["ADBE Text Position 3D", "ADBE Text Opacity"], "ADBE Text Expressible Selector");
                MS.animProp(ls[i], idx, "ADBE Text Position 3D").setValue([0, -220, 0]);
                MS.animProp(ls[i], idx, "ADBE Text Opacity").setValue(0);
                MS.animSel(ls[i], idx).property("ADBE Text Expressible Amount").expression =
                    "var delay = 0.05;\nvar t = (time - inPoint) - delay*(textIndex-1);\n" +
                    "if (t < 0) { [100,100,100] } else { var freq = 2.2, decay = 6.5;\n" +
                    "var s = 100*Math.cos(freq*t*2*Math.PI)/Math.exp(decay*t);\n[s,s,s] }";
            }
        },
        shift: function () {    // opacity fade stagger
            var comp = MS.comp(), ls = MS.textLayers(comp), i, idx;
            for (i = 0; i < ls.length; i++) {
                idx = MS.addTextAnimator(ls[i], "MS Fade Stagger", ["ADBE Text Opacity"], "ADBE Text Expressible Selector");
                MS.animProp(ls[i], idx, "ADBE Text Opacity").setValue(0);
                MS.animSel(ls[i], idx).property("ADBE Text Expressible Amount").expression =
                    "var delay = 0.05;\nvar t = (time - inPoint) - delay*(textIndex-1);\nvar k = linear(t, 0, 0.4, 100, 0);\n[k,k,k]";
            }
        },
        ctrl: function () {     // remove MotionSeeds text animators
            var comp = MS.comp(), ls = MS.textLayers(comp), i, j, g, n = 0;
            for (i = 0; i < ls.length; i++) {
                g = MS.TXT_ANIMS(ls[i]);
                for (j = g.numProperties; j >= 1; j--) { if (g.property(j).name.indexOf("MS ") === 0) { g.property(j).remove(); n++; g = MS.TXT_ANIMS(ls[i]); } }
            }
            if (!n) { MS.fail("No MotionSeeds text animators on the selected layers."); }
        },
        ctrlAlt: function () {  // expanding tracking
            var comp = MS.comp(), ls = MS.textLayers(comp), i, idx;
            for (i = 0; i < ls.length; i++) {
                idx = MS.addTextAnimator(ls[i], "MS Tracking Expand", ["ADBE Text Tracking Amount"], "ADBE Text Selector");
                MS.ensureExpr(MS.animProp(ls[i], idx, "ADBE Text Tracking Amount"), "linear(time, inPoint, outPoint, 0, 60)");
            }
        },
        shiftCtrl: function () { // 3D tumble per character
            var comp = MS.comp(), ls = MS.textLayers(comp), i, idx;
            for (i = 0; i < ls.length; i++) {
                ls[i].threeDLayer = true;
                try { ls[i].threeDPerChar = true; } catch (e) {}
                idx = MS.addTextAnimator(ls[i], "MS 3D Tumble", ["ADBE Text Rotation X", "ADBE Text Rotation Y", "ADBE Text Opacity"], "ADBE Text Expressible Selector");
                MS.animProp(ls[i], idx, "ADBE Text Rotation X").setValue(-90);
                MS.animProp(ls[i], idx, "ADBE Text Rotation Y").setValue(120);
                MS.animProp(ls[i], idx, "ADBE Text Opacity").setValue(0);
                MS.animSel(ls[i], idx).property("ADBE Text Expressible Amount").expression =
                    "var delay = 0.05;\nvar t = (time - inPoint) - delay*(textIndex-1);\nvar k = ease(t, 0, 0.6, 100, 0);\n[k,k,k]";
            }
        }
    };

    /* ---------------- Loop Expression ---------------- */
    MS.MLOOP = "/*MS LOOP*/\nvar m = thisLayer.marker, n = 0;\nif (m.numKeys > 0) { n = m.nearestKey(time).index; if (m.key(n).time > time) { n--; } }\n" +
        "if (n == 0 || numKeys < 2) { value } else {\nvar d = key(numKeys).time - key(1).time;\nvalueAtTime(key(1).time + Math.min(time - m.key(n).time, d)) }";
    MS.isLoop = function (e) { return e.indexOf("loopOut(") !== -1 || e.indexOf("/*MS LOOP*/") !== -1; };
    MS.loopApply = function (expr) {
        var comp = MS.comp(), ps = MS.needSome(MS.exprTargets(comp, 2, true), "Select a property with 2+ keyframes (or a layer that has them)."), i;
        for (i = 0; i < ps.length; i++) { MS.ensureExpr(ps[i], expr); }
        return ps;
    };
    MS.T.loop = {
        name: "Loop Expression",
        click: function () { MS.loopApply("loopOut(\"cycle\")"); },
        alt: function () { MS.loopApply("loopOut(\"pingpong\")"); },
        shift: function () { MS.loopApply("loopOut(\"offset\")"); },
        ctrl: function () {
            var comp = MS.comp(), ps = MS.needSome(MS.propsWithExpr(comp, MS.isLoop), "No loop expressions found."), i;
            for (i = 0; i < ps.length; i++) { ps[i].expression = ""; }
        },
        ctrlAlt: function () { MS.loopApply("loopOut(\"continue\")"); },
        shiftCtrl: function () {   // marker-triggered loop (restarts the animation at every layer marker)
            var comp = MS.comp(), ps = MS.loopApply(MS.MLOOP), i, l, done = [], mv;
            for (i = 0; i < ps.length; i++) {
                l = MS.ownerLayer(ps[i]);
                if (MS.idxL(done, l) !== -1) { continue; }
                done.push(l);
                mv = l.property("ADBE Marker");
                if (mv.numKeys === 0) { mv.setValueAtTime(comp.time, new MarkerValue("Loop")); }
            }
        }
    };

    /* ---------------- Keyframe Clone ---------------- */
    MS.propPath = function (p) {   // path from the layer: [{mn,name,idx,indexed}]
        var out = [], x = p, par;
        while (x && x.propertyDepth > 0) {
            par = x.parentProperty;
            out.unshift({ mn: x.matchName, name: x.name, idx: x.propertyIndex, indexed: par && par.propertyType === PropertyType.INDEXED_GROUP });
            x = par;
        }
        return out;
    };
    MS.resolvePath = function (layer, path) {
        var x = layer, i, s, c;
        for (i = 0; i < path.length; i++) {
            s = path[i];
            c = null;
            if (s.indexed) { try { c = x.property(s.name); } catch (e) {} if (!c || c.matchName !== s.mn) { try { c = x.property(s.idx); } catch (e2) {} } }
            if (!c || c.matchName !== s.mn) { try { c = x.property(s.mn); } catch (e3) { c = null; } }
            if (!c) { return null; }
            x = c;
        }
        return x;
    };
    MS.cloneRun = function (c, rev, toOthers) {
        var comp = MS.comp(), t0 = comp.time, src = MS.needKeyProps(comp), data = [], mn = 1e9, mx = -1e9, i, j, d, p, dsts, srcLayers = [], ls, tgt, l;
        for (i = 0; i < src.length; i++) {
            d = MS.selKeyData(src[i]);
            data.push({ p: src[i], keys: d, path: MS.propPath(src[i]) });
            for (j = 0; j < d.length; j++) { mn = Math.min(mn, d[j].t); mx = Math.max(mx, d[j].t); }
            l = MS.ownerLayer(src[i]);
            if (MS.idxL(srcLayers, l) === -1) { srcLayers.push(l); }
        }
        if (toOthers) {
            ls = MS.filter(MS.sel(comp), function (x) { return MS.idxL(srcLayers, x) === -1; });
            if (!ls.length) { MS.fail("Also select the destination layers (keys stay selected on the source layer)."); }
        }
        for (i = 0; i < data.length; i++) {
            dsts = [];
            if (toOthers) {
                for (j = 0; j < ls.length; j++) { tgt = MS.resolvePath(ls[j], data[i].path); if (tgt && tgt.propertyType === PropertyType.PROPERTY) { dsts.push(tgt); } }
            } else {
                dsts.push(data[i].p);
            }
            for (j = 0; j < dsts.length; j++) {
                p = dsts[j];
                var k;
                for (k = 0; k < data[i].keys.length; k++) {
                    d = data[i].keys[k];
                    try { MS.writeKey(p, rev ? t0 + (mx - d.t) : t0 + (d.t - mn), d, rev); } catch (e) {}
                }
            }
        }
    };
    MS.T.keyClone = {
        name: "Keyframe Clone",
        click: function (c) { MS.cloneRun(c, false, false); },
        shift: function (c) { MS.cloneRun(c, true, false); },
        ctrl: function (c) { MS.cloneRun(c, false, true); }
    };


    /* =====================================================================
     * MODULE 4A - SHAPE MASTERY
     * ===================================================================== */
    MS.idxPath = function (p) {
        var out = [], x = p;
        while (x && x.propertyDepth > 0) { out.unshift(x.propertyIndex); x = x.parentProperty; }
        return out;
    };
    MS.resolveIdx = function (layer, path) {
        var x = layer, i;
        for (i = 0; i < path.length; i++) { x = x.property(path[i]); if (!x) { return null; } }
        return x;
    };
    MS.copyLeaf = function (s, d) {
        var k, n;
        if (!s || !d || s.propertyValueType === PropertyValueType.NO_VALUE) { return; }
        try {
            n = s.numKeys;
            if (n > 0) {
                for (k = 1; k <= n; k++) { MS.writeKey(d, s.keyTime(k), MS.readKey(s, k), false); }
            } else if (s.isModified) {
                d.setValue(s.value);
            }
        } catch (e) {}
        try { if (s.canSetExpression && s.expression) { d.expression = s.expression; d.expressionEnabled = s.expressionEnabled; } } catch (e2) {}
    };
    /* copy one item (group / path / fill / operator...) into an indexed container */
    MS.copyItem = function (sl, sPath, dl, dContainerPath) {
        var s = MS.resolveIdx(sl, sPath), dst = MS.resolveIdx(dl, dContainerPath), dc, mn, nm, en;
        if (!s || !dst || !dst.canAddProperty(s.matchName)) { return -1; }
        mn = s.matchName; nm = s.name; en = s.enabled;
        dc = dst.addProperty(mn);
        var di = dc.propertyIndex;
        try { dc.name = nm; } catch (e) {}
        try { MS.resolveIdx(dl, dContainerPath.concat([di])).enabled = en; } catch (e1) {}
        if (s.propertyType === PropertyType.PROPERTY) {
            MS.copyLeaf(MS.resolveIdx(sl, sPath), MS.resolveIdx(dl, dContainerPath.concat([di])));
        } else {
            MS.copyTree(sl, sPath, dl, dContainerPath.concat([di]));
        }
        return di;
    };
    MS.copyTree = function (sl, sPath, dl, dPath) {
        var src = MS.resolveIdx(sl, sPath), n, i, sc, mn, nm, leaf, en, canEn, dst, dc, di, indexed;
        if (!src) { return; }
        n = src.numProperties;
        for (i = 1; i <= n; i++) {
            sc = MS.resolveIdx(sl, sPath.concat([i]));
            if (!sc) { continue; }
            mn = sc.matchName; nm = sc.name; leaf = sc.propertyType === PropertyType.PROPERTY;
            en = sc.enabled; canEn = false;
            try { canEn = sc.canSetEnabled; } catch (e0) {}
            dst = MS.resolveIdx(dl, dPath);
            if (!dst) { return; }
            indexed = dst.propertyType === PropertyType.INDEXED_GROUP;
            dc = null;
            if (indexed) { if (dst.canAddProperty(mn)) { dc = dst.addProperty(mn); } }
            else { try { dc = dst.property(mn); } catch (e1) { dc = null; } }
            if (!dc) { continue; }
            di = dc.propertyIndex;
            if (indexed) { try { dc.name = nm; } catch (e2) {} }
            if (canEn) { try { MS.resolveIdx(dl, dPath.concat([di])).enabled = en; } catch (e3) {} }
            if (leaf) { MS.copyLeaf(MS.resolveIdx(sl, sPath.concat([i])), MS.resolveIdx(dl, dPath.concat([di]))); }
            else { MS.copyTree(sl, sPath.concat([i]), dl, dPath.concat([di])); }
        }
    };
    MS.shapeLayers = function (comp) { return MS.needSome(MS.filter(MS.sel(comp, 1), MS.isShape), "Select one or more shape layers."); };
    MS.rootGroups = function (l) {
        var root = l.property("ADBE Root Vectors Group"), out = [], i;
        for (i = 1; i <= root.numProperties; i++) { if (root.property(i).matchName === "ADBE Vector Group") { out.push(i); } }
        return out;
    };
    MS.easeKeys = function (p) {
        var k, n;
        for (k = 1; k <= p.numKeys; k++) {
            try {
                p.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                n = p.keyInTemporalEase(k).length;
                p.setTemporalEaseAtKey(k, MS.easeArr(n, 0, 33.33), MS.easeArr(n, 0, 33.33));
            } catch (e) {}
        }
    };
    MS.keys = function (p, times, vals, ease) {
        var i;
        for (i = 0; i < times.length; i++) { p.setValueAtTime(times[i], vals[i]); }
        if (ease) { MS.easeKeys(p); }
    };

    /* ---------------- Explode / Merge ---------------- */
    MS.explode = function (comp, l, staggerFr) {
        var groups = MS.rootGroups(l), made = [], g, j, d, dr, nm;
        if (groups.length < 2) { MS.fail("\"" + l.name + "\" needs 2+ groups to explode."); }
        for (g = 0; g < groups.length; g++) {
            nm = l.property("ADBE Root Vectors Group").property(groups[g]).name;
            d = l.duplicate();
            d.name = MS.uniq(comp, l.name + " - " + nm);
            dr = d.property("ADBE Root Vectors Group");
            for (j = dr.numProperties; j >= 1; j--) {
                if (j !== groups[g] && d.property("ADBE Root Vectors Group").property(j).matchName === "ADBE Vector Group") { d.property("ADBE Root Vectors Group").property(j).remove(); }
            }
            made.push(d);
        }
        l.enabled = false;
        if (staggerFr) { for (g = 0; g < made.length; g++) { made[g].startTime += g * staggerFr * comp.frameDuration; } }
        return made;
    };
    MS.bakeXformInto = function (item, xf, op) {   // item: copied shape item; xf: parent group transform
        var mn = item.matchName, s = (Math.abs(xf.s[0]) + Math.abs(xf.s[1])) / 200, k, p;
        function eachVal(prop, fn) {
            if (!prop) { return; }
            if (prop.numKeys > 0) { for (k = 1; k <= prop.numKeys; k++) { prop.setValueAtKey(k, fn(prop.keyValue(k))); } }
            else { prop.setValue(fn(prop.value)); }
        }
        function lin(v) { var r = xf.r * Math.PI / 180, x = v[0] * xf.s[0] / 100, y = v[1] * xf.s[1] / 100; return [x * Math.cos(r) - y * Math.sin(r), x * Math.sin(r) + y * Math.cos(r)]; }
        if (mn === "ADBE Vector Group") {
            p = item.property("ADBE Vector Transform Group");
            eachVal(p.property("ADBE Vector Position"), function (v) { return MS.applyXform(v, xf); });
            eachVal(p.property("ADBE Vector Rotation"), function (v) { return v + xf.r; });
            eachVal(p.property("ADBE Vector Scale"), function (v) { return [v[0] * xf.s[0] / 100, v[1] * xf.s[1] / 100]; });
            eachVal(p.property("ADBE Vector Group Opacity"), function (v) { return v * op / 100; });
        } else if (mn === "ADBE Vector Shape - Group") {
            eachVal(item.property("ADBE Vector Shape"), function (sh) {
                var n = new Shape(), i, vv = [], it = [], ot = [];
                for (i = 0; i < sh.vertices.length; i++) { vv.push(MS.applyXform(sh.vertices[i], xf)); it.push(lin(sh.inTangents[i])); ot.push(lin(sh.outTangents[i])); }
                n.vertices = vv; n.inTangents = it; n.outTangents = ot; n.closed = sh.closed;
                return n;
            });
        } else if (mn === "ADBE Vector Shape - Rect" || mn === "ADBE Vector Shape - Ellipse") {
            var pre = (mn === "ADBE Vector Shape - Rect") ? "ADBE Vector Rect " : "ADBE Vector Ellipse ";
            eachVal(item.property(pre + "Position"), function (v) { return MS.applyXform(v, xf); });
            eachVal(item.property(pre + "Size"), function (v) { return [v[0] * Math.abs(xf.s[0]) / 100, v[1] * Math.abs(xf.s[1]) / 100]; });
        } else if (mn === "ADBE Vector Shape - Star") {
            eachVal(item.property("ADBE Vector Star Position"), function (v) { return MS.applyXform(v, xf); });
            eachVal(item.property("ADBE Vector Star Rotation"), function (v) { return v + xf.r; });
            eachVal(item.property("ADBE Vector Star Outer Radius"), function (v) { return v * s; });
            try { eachVal(item.property("ADBE Vector Star Inner Radius"), function (v) { return v * s; }); } catch (e) {}
        } else if (mn === "ADBE Vector Graphic - Stroke") {
            eachVal(item.property("ADBE Vector Stroke Width"), function (v) { return v * s; });
            eachVal(item.property("ADBE Vector Stroke Opacity"), function (v) { return v * op / 100; });
        } else if (mn === "ADBE Vector Graphic - Fill") {
            eachVal(item.property("ADBE Vector Fill Opacity"), function (v) { return v * op / 100; });
        }
    };
    MS.selShapeItems = function (comp, groupsOnly) {   // [{l, path}] selected shape items
        var sp = comp.selectedProperties, out = [], i, p, par;
        for (i = 0; i < sp.length; i++) {
            p = sp[i];
            par = p.parentProperty;
            if (!par || (par.matchName !== "ADBE Root Vectors Group" && par.matchName !== "ADBE Vectors Group")) { continue; }
            if (groupsOnly && p.matchName !== "ADBE Vector Group") { continue; }
            out.push({ l: MS.ownerLayer(p), path: MS.idxPath(p) });
        }
        return out;
    };
    MS.T.explode = {
        name: "Explode / Merge Shapes",
        click: function () {
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i;
            for (i = 0; i < ls.length; i++) { MS.explode(comp, ls[i], 0); }
        },
        alt: function () {      // merge selected shape layers into one layer of groups
            var comp = MS.comp(), t = comp.time, ls = MS.shapeLayers(comp), dest, i, gi, l, xf, g, sc, rot, op;
            if (ls.length < 2) { MS.fail("Select 2+ shape layers to merge."); }
            ls.sort(function (a, b) { return a.index - b.index; });
            g = MS.geo(comp, ls, t);
            dest = MS.newShape(comp, "MS Merged Shapes");
            MS.placeAbove(dest, ls[0]);
            MS.tr(dest, "ADBE Anchor Point").setValue([0, 0, 0]);
            MS.tr(dest, "ADBE Position").setValue([0, 0, 0]);
            for (i = 0; i < ls.length; i++) {
                l = ls[i];
                gi = MS.newGroupIdx(dest, l.name);
                MS.copyTree(l, ["ADBE Root Vectors Group"], dest, ["ADBE Root Vectors Group", gi, "ADBE Vectors Group"]);
                xf = MS.grpXf(dest, gi);
                sc = MS.tr(l, "ADBE Scale").valueAtTime(t, false);
                rot = MS.tr(l, "ADBE Rotate Z").valueAtTime(t, false);
                op = MS.tr(l, "ADBE Opacity").valueAtTime(t, false);
                xf.property("ADBE Vector Anchor").setValue(MS.tr(l, "ADBE Anchor Point").valueAtTime(t, false).slice(0, 2));
                MS.grpXf(dest, gi).property("ADBE Vector Position").setValue([g[i].ax, g[i].ay]);
                MS.grpXf(dest, gi).property("ADBE Vector Scale").setValue([sc[0], sc[1]]);
                MS.grpXf(dest, gi).property("ADBE Vector Rotation").setValue(rot);
                MS.grpXf(dest, gi).property("ADBE Vector Group Opacity").setValue(op);
                l.enabled = false;
            }
        },
        shift: function () {    // center each group's anchor on its own content
            var comp = MS.comp(), t = comp.time, ls = MS.shapeLayers(comp), i, j, k, l, root, states, groups, r, C, xf, dx, dy, rr, ux, uy, tg, A1, n;
            for (i = 0; i < ls.length; i++) {
                l = ls[i];
                root = l.property("ADBE Root Vectors Group");
                states = []; groups = MS.rootGroups(l);
                for (j = 1; j <= root.numProperties; j++) { states.push(l.property("ADBE Root Vectors Group").property(j).enabled); }
                for (j = 0; j < groups.length; j++) {
                    if (!states[groups[j] - 1]) { continue; }
                    for (k = 0; k < groups.length; k++) { l.property("ADBE Root Vectors Group").property(groups[k]).enabled = (k === j); }
                    r = l.sourceRectAtTime(t, true);
                    if (r.width <= 0 && r.height <= 0) { continue; }
                    C = [r.left + r.width / 2, r.top + r.height / 2];
                    xf = MS.groupXform(l.property("ADBE Root Vectors Group").property(groups[j]), t);
                    dx = C[0] - xf.p[0]; dy = C[1] - xf.p[1]; rr = -xf.r * Math.PI / 180;
                    ux = dx * Math.cos(rr) - dy * Math.sin(rr); uy = dx * Math.sin(rr) + dy * Math.cos(rr);
                    ux = (xf.s[0] !== 0) ? ux / (xf.s[0] / 100) : 0; uy = (xf.s[1] !== 0) ? uy / (xf.s[1] / 100) : 0;
                    A1 = [xf.a[0] + ux, xf.a[1] + uy];
                    tg = MS.grpXf(l, groups[j]);
                    MS.addToProp(tg.property("ADBE Vector Anchor"), MS.vsub(A1, xf.a));
                    MS.addToProp(MS.grpXf(l, groups[j]).property("ADBE Vector Position"), MS.vsub(C, xf.p));
                }
                n = l.property("ADBE Root Vectors Group").numProperties;
                for (j = 1; j <= n; j++) { l.property("ADBE Root Vectors Group").property(j).enabled = states[j - 1]; }
            }
        },
        ctrl: function () {     // group items
            var comp = MS.comp(), items = MS.selShapeItems(comp, false), i, l, cPath, idxs = [], cont, gi, ng;
            if (!items.length) {
                var ls = MS.shapeLayers(comp), j, root;
                l = ls[0];
                root = l.property("ADBE Root Vectors Group");
                for (j = 1; j <= root.numProperties; j++) { items.push({ l: l, path: MS.idxPath(root.property(j)) }); }
                if (!items.length) { MS.fail("The shape layer has no contents."); }
            }
            l = items[0].l;
            cPath = items[0].path.slice(0, items[0].path.length - 1);
            for (i = 0; i < items.length; i++) {
                if (items[i].l === l && items[i].path.slice(0, items[i].path.length - 1).join(",") === cPath.join(",")) { idxs.push(items[i].path[items[i].path.length - 1]); }
            }
            idxs.sort(function (a, b) { return a - b; });
            cont = MS.resolveIdx(l, cPath);
            ng = cont.addProperty("ADBE Vector Group");
            ng.name = "MS Group";
            gi = ng.propertyIndex;
            for (i = 0; i < idxs.length; i++) { MS.copyItem(l, cPath.concat([idxs[i]]), l, cPath.concat([gi, MS.resolveIdx(l, cPath.concat([gi])).property("ADBE Vectors Group").propertyIndex])); }
            for (i = idxs.length - 1; i >= 0; i--) { MS.resolveIdx(l, cPath.concat([idxs[i]])).remove(); }
            MS.resolveIdx(l, cPath.concat([gi - idxs.length])).moveTo(idxs[0]);
        },
        ctrlAlt: function () {  // ungroup items (group transform is baked into the children)
            var comp = MS.comp(), t = comp.time, items = MS.selShapeItems(comp, true), i, it, l, g, cPath, gi, xf, op, cIdx, m, k, N, ident, newIdx;
            if (!items.length) {
                var ls = MS.shapeLayers(comp), j, gs;
                for (j = 0; j < ls.length; j++) { gs = MS.rootGroups(ls[j]); for (k = 0; k < gs.length; k++) { items.push({ l: ls[j], path: MS.idxPath(ls[j].property("ADBE Root Vectors Group").property(gs[k])) }); } }
            }
            if (!items.length) { MS.fail("Select shape groups (or shape layers with groups) to ungroup."); }
            items.sort(function (a, b) { return b.path[b.path.length - 1] - a.path[a.path.length - 1]; });
            for (i = 0; i < items.length; i++) {
                it = items[i]; l = it.l;
                g = MS.resolveIdx(l, it.path);
                if (!g || g.matchName !== "ADBE Vector Group") { continue; }
                cPath = it.path.slice(0, it.path.length - 1);
                gi = it.path[it.path.length - 1];
                xf = MS.groupXform(g, t);
                op = g.property("ADBE Vector Transform Group").property("ADBE Vector Group Opacity").valueAtTime(t, false);
                ident = MS.same(xf.p, xf.a) && Math.abs(xf.s[0] - 100) < 1e-6 && Math.abs(xf.s[1] - 100) < 1e-6 && Math.abs(xf.r) < 1e-6 && op >= 100;
                cIdx = g.property("ADBE Vectors Group").propertyIndex;
                m = g.property("ADBE Vectors Group").numProperties;
                for (k = 1; k <= m; k++) {
                    newIdx = MS.copyItem(l, it.path.concat([cIdx, k]), l, cPath);
                    if (newIdx > 0 && !ident) { try { MS.bakeXformInto(MS.resolveIdx(l, cPath.concat([newIdx])), xf, op); } catch (e) {} }
                }
                MS.resolveIdx(l, it.path).remove();
                N = MS.resolveIdx(l, cPath).numProperties;
                for (k = 0; k < m; k++) { MS.resolveIdx(l, cPath.concat([N - m + 1 + k])).moveTo(gi + k); }
            }
        },
        shiftCtrl: function (c) {   // explode with staggered timeline spacing
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i, fr = Math.max(1, MS.num(c.args.frames, 5));
            for (i = 0; i < ls.length; i++) { MS.explode(comp, ls[i], fr); }
        }
    };

    /* ---------------- Smart Trim Paths ---------------- */
    MS.addTrimTo = function (l, contPath) {   // returns index path of the new trim
        var cont = MS.resolveIdx(l, contPath), tr = cont.addProperty("ADBE Vector Filter - Trim");
        return contPath.concat([tr.propertyIndex]);
    };
    MS.trimP = function (l, path, mn) { return MS.resolveIdx(l, path).property(mn); };
    MS.T.trim = {
        name: "Smart Trim Paths",
        click: function () {
            var comp = MS.comp(), t = comp.time, ls = MS.shapeLayers(comp), i, p;
            for (i = 0; i < ls.length; i++) {
                p = MS.addTrimTo(ls[i], [MS.idxPath(ls[i].property("ADBE Root Vectors Group"))[0]]);
                MS.keys(MS.trimP(ls[i], p, "ADBE Vector Trim End"), [t, t + 1], [0, 100], true);
            }
        },
        alt: function () {      // infinite radar loop
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i, p;
            for (i = 0; i < ls.length; i++) {
                p = MS.addTrimTo(ls[i], [MS.idxPath(ls[i].property("ADBE Root Vectors Group"))[0]]);
                MS.trimP(ls[i], p, "ADBE Vector Trim End").setValue(25);
                MS.ensureExpr(MS.trimP(ls[i], p, "ADBE Vector Trim Offset"), "time*180");
            }
        },
        shift: function () {    // symmetrical dual trim (grows from the middle both ways)
            var comp = MS.comp(), t = comp.time, ls = MS.shapeLayers(comp), i, p;
            for (i = 0; i < ls.length; i++) {
                p = MS.addTrimTo(ls[i], [MS.idxPath(ls[i].property("ADBE Root Vectors Group"))[0]]);
                MS.keys(MS.trimP(ls[i], p, "ADBE Vector Trim Start"), [t, t + 1], [50, 0], true);
                MS.keys(MS.trimP(ls[i], p, "ADBE Vector Trim End"), [t, t + 1], [50, 100], true);
            }
        },
        ctrl: function () {     // glitch offset
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i, p;
            for (i = 0; i < ls.length; i++) {
                p = MS.addTrimTo(ls[i], [MS.idxPath(ls[i].property("ADBE Root Vectors Group"))[0]]);
                MS.ensureExpr(MS.trimP(ls[i], p, "ADBE Vector Trim Start"), "seedRandom(Math.floor(time*12),true);\nrandom(0,45)");
                MS.ensureExpr(MS.trimP(ls[i], p, "ADBE Vector Trim End"), "seedRandom(Math.floor(time*12)+77,true);\nrandom(55,100)");
                MS.ensureExpr(MS.trimP(ls[i], p, "ADBE Vector Trim Offset"), "seedRandom(Math.floor(time*8),true);\nrandom(-180,180)");
            }
        },
        ctrlAlt: function () {  // linked master slider controls
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i, p, l;
            for (i = 0; i < ls.length; i++) {
                l = ls[i];
                MS.slider(l, "MS Trim Start", 0);
                MS.slider(l, "MS Trim End", 100);
                MS.slider(l, "MS Trim Offset", 0);
                p = MS.addTrimTo(l, [MS.idxPath(l.property("ADBE Root Vectors Group"))[0]]);
                MS.ensureExpr(MS.trimP(l, p, "ADBE Vector Trim Start"), "clamp(effect(\"MS Trim Start\")(1),0,100)");
                MS.ensureExpr(MS.trimP(l, p, "ADBE Vector Trim End"), "clamp(effect(\"MS Trim End\")(1),0,100)");
                MS.ensureExpr(MS.trimP(l, p, "ADBE Vector Trim Offset"), "effect(\"MS Trim Offset\")(1)*3.6");
            }
        },
        shiftCtrl: function (c) {   // staggered trim across shapes
            var comp = MS.comp(), t = comp.time, ls = MS.shapeLayers(comp), fr = Math.max(1, MS.num(c.args.frames, 5)) * comp.frameDuration, i, j, gs, p, n = 0, rootPath;
            for (i = 0; i < ls.length; i++) {
                rootPath = [MS.idxPath(ls[i].property("ADBE Root Vectors Group"))[0]];
                gs = (ls.length === 1) ? MS.rootGroups(ls[i]) : [];
                if (gs.length > 1) {
                    for (j = 0; j < gs.length; j++) {
                        p = MS.addTrimTo(ls[i], rootPath.concat([gs[j], MS.resolveIdx(ls[i], rootPath.concat([gs[j]])).property("ADBE Vectors Group").propertyIndex]));
                        MS.keys(MS.trimP(ls[i], p, "ADBE Vector Trim End"), [t + j * fr, t + j * fr + 1], [0, 100], true);
                    }
                } else {
                    p = MS.addTrimTo(ls[i], rootPath);
                    MS.keys(MS.trimP(ls[i], p, "ADBE Vector Trim End"), [t + n * fr, t + n * fr + 1], [0, 100], true);
                    n++;
                }
            }
        }
    };

    /* ---------------- Dynamic Auto-Box ---------------- */
    MS.makeBox = function (comp, txt, opt, col) {
        var box = MS.newShape(comp, "MS Box - " + txt.name), gi, rIdx, T = "var T=thisComp.layer(" + MS.q(txt.name) + ");\nvar r=T.sourceRectAtTime(time,false);\nvar p=effect(\"MS Padding\")(1);\n", rect;
        MS.slider(box, "MS Padding", opt.accent ? 14 : 24);
        if (opt.round) { MS.slider(box, "MS Roundness", 18); }
        if (opt.opacity) { MS.slider(box, "MS Box Opacity", 100); }
        if (opt.round) { MS.addFx(box, "ADBE Drop Shadow", "MS Drop Shadow"); }
        gi = MS.newGroupIdx(box, opt.accent ? "Accent Bar" : "Box");
        rect = MS.addRect(MS.grpContents(box, gi), [100, 100], [0, 0], 0);
        rIdx = rect.propertyIndex;
        if (opt.stroke) { MS.addStroke(MS.grpContents(box, gi), col, 4, 2); } else { MS.addFill(MS.grpContents(box, gi), col); }
        rect = MS.grpContents(box, gi).property(rIdx);
        if (opt.accent) {
            MS.ensureExpr(rect.property("ADBE Vector Rect Size"), T + "[8,r.height+p*2]");
            MS.ensureExpr(MS.grpContents(box, gi).property(rIdx).property("ADBE Vector Rect Position"), T + "[r.left-p-4,r.top+r.height/2]");
        } else {
            MS.ensureExpr(rect.property("ADBE Vector Rect Size"), T + "[r.width+p*2,r.height+p*2]");
            MS.ensureExpr(MS.grpContents(box, gi).property(rIdx).property("ADBE Vector Rect Position"), T + "[r.left+r.width/2,r.top+r.height/2]");
        }
        if (opt.round) { MS.ensureExpr(MS.grpContents(box, gi).property(rIdx).property("ADBE Vector Rect Roundness"), "effect(\"MS Roundness\")(1)"); }
        if (opt.skew) {
            MS.ensureExpr(MS.grpXf(box, gi).property("ADBE Vector Anchor"), T + "[r.left+r.width/2,r.top+r.height/2]");
            MS.ensureExpr(MS.grpXf(box, gi).property("ADBE Vector Position"), T + "[r.left+r.width/2,r.top+r.height/2]");
            MS.grpXf(box, gi).property("ADBE Vector Skew").setValue(-14);
        }
        if (txt.threeDLayer) { box.threeDLayer = true; }
        box.parent = txt;
        MS.tr(box, "ADBE Anchor Point").setValue([0, 0, 0]);
        MS.tr(box, "ADBE Position").setValue([0, 0, 0]);
        MS.tr(box, "ADBE Scale").setValue([100, 100, 100]);
        MS.tr(box, "ADBE Rotate Z").setValue(0);
        if (opt.opacity) { MS.ensureExpr(MS.tr(box, "ADBE Opacity"), "thisComp.layer(" + MS.q(txt.name) + ").transform.opacity*effect(\"MS Box Opacity\")(1)/100"); }
        box.moveAfter(txt);
        box.inPoint = txt.inPoint;
        box.outPoint = txt.outPoint;
        return box;
    };
    MS.boxRun = function (c, opt) {
        var comp = MS.comp(), ls = MS.textLayers(comp), i, col = MS.argColor(c);
        for (i = 0; i < ls.length; i++) { MS.makeBox(comp, ls[i], opt, col); }
    };
    MS.T.autoBox = {
        name: "Dynamic Auto-Box",
        click: function (c) { MS.boxRun(c, {}); },
        alt: function (c) { MS.boxRun(c, { round: true }); },
        shift: function (c) { MS.boxRun(c, { opacity: true }); },
        ctrl: function (c) { MS.boxRun(c, { stroke: true }); },
        ctrlAlt: function (c) { MS.boxRun(c, { skew: true }); },
        shiftCtrl: function (c) { MS.boxRun(c, { accent: true }); }
    };

    /* ---------------- Quick Burst ---------------- */
    MS.burstBase = function (c, name) {
        var comp = MS.comp(), t = comp.time, sel = MS.filter(MS.sel(comp), MS.isVisual), cx = comp.width / 2, cy = comp.height / 2, g, l;
        if (sel.length) { g = MS.geo(comp, [sel[0]], t)[0]; cx = g.cx; cy = g.cy; }
        l = MS.newShape(comp, name);
        MS.placeAbove(l, MS.topOf(MS.sel(comp)));
        MS.tr(l, "ADBE Anchor Point").setValue([0, 0, 0]);
        MS.tr(l, "ADBE Position").setValue([cx, cy, 0]);
        return { comp: comp, t: t, l: l, cx: cx, cy: cy, col: MS.argColor(c) };
    };
    MS.burstLines = function (o, loop, randomColors) {
        var l = o.l, t = o.t, gi, cont, trimIdx, i, n = 10;
        if (randomColors) {
            for (i = 0; i < n; i++) {
                gi = MS.newGroupIdx(l, "Ray " + (i + 1));
                MS.addPath(MS.grpContents(l, gi), [[0, -40], [0, -120]], false);
                trimIdx = MS.grpContents(l, gi).addProperty("ADBE Vector Filter - Trim").propertyIndex;
                MS.addStroke(MS.grpContents(l, gi), MS.randColor(), 6, 2);
                MS.keys(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim End"), [t, t + 0.35], [0, 100], true);
                MS.keys(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim Start"), [t + 0.15, t + 0.5], [0, 100], true);
                MS.grpXf(l, gi).property("ADBE Vector Rotation").setValue(i * 360 / n);
            }
        } else {
            gi = MS.newGroupIdx(l, "Rays");
            MS.addPath(MS.grpContents(l, gi), [[0, -40], [0, -120]], false);
            trimIdx = MS.grpContents(l, gi).addProperty("ADBE Vector Filter - Trim").propertyIndex;
            MS.addStroke(MS.grpContents(l, gi), o.col, 6, 2);
            cont = MS.grpContents(l, gi);
            var rep = cont.addProperty("ADBE Vector Filter - Repeater"), repIdx = rep.propertyIndex;
            rep = MS.grpContents(l, gi).property(repIdx);
            rep.property("ADBE Vector Repeater Copies").setValue(n);
            rep.property("ADBE Vector Repeater Transform").property("ADBE Vector Repeater Position").setValue([0, 0]);
            MS.grpContents(l, gi).property(repIdx).property("ADBE Vector Repeater Transform").property("ADBE Vector Repeater Rotation").setValue(360 / n);
            if (loop) {
                MS.ensureExpr(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim End"), "var t=(time-inPoint)%1.2;\nease(t,0,0.35,0,100)");
                MS.ensureExpr(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim Start"), "var t=(time-inPoint)%1.2;\nease(t,0.15,0.5,0,100)");
            } else {
                MS.keys(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim End"), [t, t + 0.35], [0, 100], true);
                MS.keys(MS.grpContents(l, gi).property(trimIdx).property("ADBE Vector Trim Start"), [t + 0.15, t + 0.5], [0, 100], true);
            }
        }
        l.inPoint = t;
        if (!loop) { l.outPoint = Math.min(o.comp.duration, t + 1); }
    };
    MS.T.burst = {
        name: "Quick Burst",
        click: function (c) { MS.burstLines(MS.burstBase(c, "MS Line Burst"), false, false); },
        alt: function (c) { MS.burstLines(MS.burstBase(c, "MS Color Burst"), false, true); },
        shift: function (c) {   // circle scale burst
            var o = MS.burstBase(c, "MS Circle Burst"), l = o.l, t = o.t, gi = MS.newGroupIdx(l, "Ring"), e, s;
            e = MS.addEllipse(MS.grpContents(l, gi), [20, 20], [0, 0]).propertyIndex;
            s = MS.addStroke(MS.grpContents(l, gi), o.col, 18, 2).propertyIndex;
            MS.keys(MS.grpContents(l, gi).property(e).property("ADBE Vector Ellipse Size"), [t, t + 0.5], [[0, 0], [280, 280]], true);
            MS.keys(MS.grpContents(l, gi).property(s).property("ADBE Vector Stroke Width"), [t, t + 0.5], [24, 0], true);
            l.inPoint = t; l.outPoint = Math.min(o.comp.duration, t + 1);
        },
        ctrl: function (c) {    // star polygon burst
            var o = MS.burstBase(c, "MS Star Burst"), l = o.l, t = o.t, gi = MS.newGroupIdx(l, "Star"), st;
            st = MS.grpContents(l, gi).addProperty("ADBE Vector Shape - Star");
            st.property("ADBE Vector Star Type").setValue(1);
            st.property("ADBE Vector Star Points").setValue(5);
            st.property("ADBE Vector Star Outer Radius").setValue(110);
            st.property("ADBE Vector Star Inner Radius").setValue(48);
            MS.addStroke(MS.grpContents(l, gi), o.col, 8, 2);
            MS.keys(MS.grpXf(l, gi).property("ADBE Vector Scale"), [t, t + 0.5], [[0, 0], [100, 100]], true);
            MS.keys(MS.grpXf(l, gi).property("ADBE Vector Rotation"), [t, t + 0.7], [0, 144], true);
            MS.keys(MS.grpXf(l, gi).property("ADBE Vector Group Opacity"), [t + 0.4, t + 0.8], [100, 0], true);
            l.inPoint = t; l.outPoint = Math.min(o.comp.duration, t + 1);
        },
        ctrlAlt: function (c) { // 3D z-space particle burst
            var o = MS.burstBase(c, "MS 3D Burst"), comp = o.comp, t = o.t, ctl = o.l, i, p, gi, d, n = 12, P;
            ctl.name = MS.uniq(comp, "MS 3D Burst Control");
            ctl.threeDLayer = true;
            for (i = 0; i < n; i++) {
                p = MS.newShape(comp, "MS Burst Particle " + (i + 1));
                gi = MS.newGroupIdx(p, "Dot");
                MS.addEllipse(MS.grpContents(p, gi), [18, 18], [0, 0]);
                MS.addFill(MS.grpContents(p, gi), i % 2 ? o.col : MS.randColor());
                p.threeDLayer = true;
                MS.tr(p, "ADBE Anchor Point").setValue([0, 0, 0]);
                MS.tr(p, "ADBE Position").setValue([o.cx, o.cy, 0]);
                p.parent = ctl;
                P = MS.tr(p, "ADBE Position").value;
                d = [MS.rnd(-1, 1), MS.rnd(-1, 1), MS.rnd(-1, 1)];
                var len = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]) || 1, r = MS.rnd(160, 320);
                MS.keys(MS.tr(p, "ADBE Position"), [t, t + 0.7], [P, [P[0] + d[0] / len * r, P[1] + d[1] / len * r, P[2] + d[2] / len * r]], true);
                MS.keys(MS.tr(p, "ADBE Scale"), [t, t + 0.7], [[100, 100, 100], [0, 0, 0]], true);
                p.inPoint = t; p.outPoint = Math.min(comp.duration, t + 1);
                p.moveAfter(ctl);
            }
            ctl.inPoint = t; ctl.outPoint = Math.min(comp.duration, t + 1);
        },
        shiftCtrl: function (c) { MS.burstLines(MS.burstBase(c, "MS Loop Burst"), true, false); }
    };

    /* =====================================================================
     * MODULE 8 - Round / Butt Cap (+ dashed, joins, taper, zig-zag)
     * ===================================================================== */
    MS.strokesOf = function (layers) {
        var out = [], i;
        for (i = 0; i < layers.length; i++) {
            (function (l) {
                MS.walkGroups(l.property("ADBE Root Vectors Group"), "ADBE Vector Graphic - Stroke", function (g) { out.push({ l: l, path: MS.idxPath(g) }); });
            }(layers[i]));
        }
        return out;
    };
    MS.capLayers = function (comp, all) {
        if (all) { return MS.needSome(MS.filter(MS.allLayers(comp), MS.isShape), "No shape layers in this composition."); }
        return MS.shapeLayers(comp);
    };
    MS.capRun = function (c, all) {
        var comp = MS.comp(), st = MS.needSome(MS.strokesOf(MS.capLayers(comp, all)), "No strokes found on the shape layer(s)."), i, v = (c.args.cap === "butt") ? 1 : 2;
        for (i = 0; i < st.length; i++) { MS.resolveIdx(st[i].l, st[i].path).property("ADBE Vector Stroke Line Cap").setValue(v); }
        return st;
    };
    MS.T.cap = {
        name: "Stroke Caps",
        click: function (c) { MS.capRun(c, false); },
        alt: function (c) {     // dashed stroke configuration
            var st = MS.capRun(c, false), i, d, dp;
            for (i = 0; i < st.length; i++) {
                dp = st[i].path.concat([MS.resolveIdx(st[i].l, st[i].path).property("ADBE Vector Stroke Dashes").propertyIndex]);
                d = MS.resolveIdx(st[i].l, dp);
                if (d.numProperties === 0) {
                    d.addProperty("ADBE Vector Stroke Dash 1");
                    MS.resolveIdx(st[i].l, dp).addProperty("ADBE Vector Stroke Gap 1");
                }
                try { MS.resolveIdx(st[i].l, dp).property("ADBE Vector Stroke Dash 1").setValue(24); } catch (e1) {}
                try { MS.resolveIdx(st[i].l, dp).property("ADBE Vector Stroke Gap 1").setValue(16); } catch (e2) {}
            }
        },
        shift: function (c) { MS.capRun(c, true); },
        ctrl: function () {     // toggle round / miter join
            var comp = MS.comp(), st = MS.needSome(MS.strokesOf(MS.shapeLayers(comp)), "No strokes found."), i, j, first;
            first = MS.resolveIdx(st[0].l, st[0].path).property("ADBE Vector Stroke Line Join").value;
            for (i = 0; i < st.length; i++) {
                j = MS.resolveIdx(st[i].l, st[i].path).property("ADBE Vector Stroke Line Join");
                j.setValue(first === 2 ? 1 : 2);
            }
        },
        ctrlAlt: function () {  // tapered stroke (AE 2020 17.1+)
            var comp = MS.comp(), st = MS.needSome(MS.strokesOf(MS.shapeLayers(comp)), "No strokes found."), i, tp, s;
            if (!$.global.MotionSeedsCompat.hasTaper) { MS.fail("Tapered strokes need After Effects 2020 (17.1) or newer."); }
            for (i = 0; i < st.length; i++) {
                s = MS.resolveIdx(st[i].l, st[i].path);
                tp = s.property("ADBE Vector Stroke Taper");
                if (!tp) { MS.fail("Stroke taper is not available in this After Effects version."); }
                try { tp.property("ADBE Vector Taper Start Length").setValue(35); } catch (e1) {}
                try { MS.resolveIdx(st[i].l, st[i].path).property("ADBE Vector Stroke Taper").property("ADBE Vector Taper End Length").setValue(35); } catch (e2) {}
            }
        },
        shiftCtrl: function () {    // wave / zig-zag modifier
            var comp = MS.comp(), ls = MS.shapeLayers(comp), i, z, zi, root;
            for (i = 0; i < ls.length; i++) {
                root = ls[i].property("ADBE Root Vectors Group");
                z = root.addProperty("ADBE Vector Filter - Zigzag");
                zi = z.propertyIndex;
                try { ls[i].property("ADBE Root Vectors Group").property(zi).property("ADBE Vector Zigzag Size").setValue(10); } catch (e1) {}
                try { ls[i].property("ADBE Root Vectors Group").property(zi).property("ADBE Vector Zigzag Detail").setValue(8); } catch (e2) {}
                try { ls[i].property("ADBE Root Vectors Group").property(zi).property("ADBE Vector Zigzag Points").setValue(2); } catch (e3) {}
            }
        }
    };


    /* =====================================================================
     * MODULE 4B - TEXT UTILITIES
     * ===================================================================== */
    MS.textDoc = function (l) { return l.property("ADBE Text Properties").property("ADBE Text Document"); };
    MS.cleanTextClone = function (src) {
        var d = src.duplicate(), p = MS.textDoc(d);
        try { if (p.expression) { p.expression = ""; } } catch (e) {}
        MS.clearKeys(MS.textDoc(d));
        return d;
    };
    MS.removeAnimators = function (l) {
        var g = MS.TXT_ANIMS(l), i;
        for (i = g.numProperties; i >= 1; i--) { MS.TXT_ANIMS(l).property(i).remove(); }
    };
    MS.setText = function (l, str, just, t, base) {
        var p = MS.textDoc(l), td = base || p.valueAtTime(t, true);
        td.text = str;
        if (just !== null && just !== undefined) { td.justification = just; }
        MS.setVal(MS.textDoc(l), td, t);
    };
    MS.splitText = function (comp, l, mode, t) {
        var p = MS.textDoc(l), td = p.valueAtTime(t, false), full = String(td.text), J = td.justification, LEFT = ParagraphJustification.LEFT_JUSTIFY;
        var lines = full.split(/\r\n|\r|\n|\u0003/), M, pieces = [], li, line, dy, rb, rl, rLo, rLl, dxLine, re, mm, pre, rP, rS, made = [], i, d, list = [], r, pc, k;
        M = MS.cleanTextClone(l);
        MS.removeAnimators(M);
        function rect(str, just) { MS.setText(M, str, just, t); return M.sourceRectAtTime(t, false); }
        for (li = 0; li < lines.length; li++) {
            line = lines[li];
            if (!line.replace(/\s/g, "").length) { continue; }
            dy = 0;
            if (li > 0) {
                rb = rect(lines.slice(0, li + 1).join("\r"), J);
                rl = rect(line, J);
                dy = (rb.top + rb.height) - (rl.top + rl.height);
            }
            if (mode === "lines") { pieces.push({ s: line, dx: 0, dy: dy, j: J }); continue; }
            rLo = rect(line, J); rLl = rect(line, LEFT);
            dxLine = rLo.left - rLl.left;
            if (mode === "words") {
                re = /\S+/g;
                while ((mm = re.exec(line)) !== null) {
                    pre = line.substr(0, mm.index);
                    rP = rect(pre + mm[0], LEFT); rS = rect(mm[0], LEFT);
                    pieces.push({ s: mm[0], dx: (rP.left + rP.width - rS.width) + dxLine - rS.left, dy: dy, j: LEFT });
                }
            } else {
                for (k = 0; k < line.length; k++) {
                    if (/\s/.test(line.charAt(k))) { continue; }
                    pre = line.substr(0, k);
                    rP = rect(pre + line.charAt(k), LEFT); rS = rect(line.charAt(k), LEFT);
                    pieces.push({ s: line.charAt(k), dx: (rP.left + rP.width - rS.width) + dxLine - rS.left, dy: dy, j: LEFT });
                }
            }
        }
        MS.removeLayer(M);
        if (!pieces.length) { MS.fail("\"" + l.name + "\" has no text to split."); }
        for (i = 0; i < pieces.length; i++) {
            pc = pieces[i];
            d = MS.cleanTextClone(l);
            MS.setText(d, pc.s, pc.j, t);
            d.name = MS.uniq(comp, pc.s.substr(0, 28));
            MS.addToProp(MS.tr(d, "ADBE Anchor Point"), [-pc.dx, -pc.dy, 0]);
            made.push(d);
        }
        for (i = 0; i < made.length; i++) {
            r = made[i].sourceRectAtTime(t, false);
            list.push({ l: made[i], a: [r.left + r.width / 2, r.top + r.height / 2] });
        }
        MS.relocateAnchors(comp, list, t);
        return made;
    };
    MS.splitRun = function (c, mode, keep, after) {
        var comp = MS.comp(), ls = MS.textLayers(comp), i, made, all = [];
        for (i = 0; i < ls.length; i++) {
            made = MS.splitText(comp, ls[i], mode, comp.time);
            if (after) { made = after(comp, made) || made; }
            all = all.concat(made);
            if (keep) { ls[i].enabled = false; ls[i].name = MS.uniq(comp, ls[i].name + " (backup)"); } else { ls[i].remove(); }
        }
        MS.selectOnly(comp, all);
        c.selSet = true;
        return all;
    };
    /* After Effects' own "Layer > Create > Create Shapes from Text" on the given text layers.
       Returns the new shape layers (AE places each one above its text layer and hides the text). */
    MS.CMD_SHAPES_FROM_TEXT = 3781;
    MS.shapesFromText = function (comp, texts) {
        var before = MS.allLayers(comp), id = 0, i, L, out = [];
        try { id = app.findMenuCommandId("Create Shapes from Text"); } catch (e) { id = 0; }
        if (!id) { id = MS.CMD_SHAPES_FROM_TEXT; }
        MS.selectOnly(comp, texts);
        app.executeCommand(id);
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if ((L instanceof ShapeLayer) && MS.idxL(before, L) === -1) { out.push(L); }
        }
        if (!out.length) { MS.fail("After Effects could not create shapes from this text (is the font missing?)."); }
        return out;
    };
    /* centre each layer's anchor on its own content (no visual jump) */
    MS.centerAnchors = function (comp, layers, t) {
        var list = [], i, r;
        for (i = 0; i < layers.length; i++) {
            r = MS.rect(layers[i], t);
            if (r.width > 0 || r.height > 0) { list.push({ l: layers[i], a: [r.left + r.width / 2, r.top + r.height / 2] }); }
        }
        if (list.length) { MS.relocateAnchors(comp, list, t); }
    };
    /* merge 2+ text layers into ONE text layer, in reading order (top->bottom, left->right) */
    MS.mergeTexts = function (comp, ls, t) {
        var g = MS.geo(comp, ls, t), i, j, items = [], lines = [], line, it, txt, prev, gap, out = [], base, M, gm, u;
        for (i = 0; i < g.length; i++) {
            txt = String(MS.textDoc(g[i].l).valueAtTime(t, false).text);
            if (txt.replace(/\s/g, "").length) { items.push({ g: g[i], s: txt }); }
        }
        if (items.length < 2) { MS.fail("Select 2 or more text layers (with text) to merge."); }
        items.sort(function (a, b2) { return a.g.cy - b2.g.cy; });
        for (i = 0; i < items.length; i++) {
            it = items[i];
            line = lines.length ? lines[lines.length - 1] : null;
            if (line && Math.abs(it.g.cy - line.cy) <= Math.max(line.h, it.g.h) * 0.5) {
                line.items.push(it);
                line.cy = (line.cy * (line.items.length - 1) + it.g.cy) / line.items.length;
                line.h = Math.max(line.h, it.g.h);
            } else {
                lines.push({ cy: it.g.cy, h: it.g.h, items: [it] });
            }
        }
        for (i = 0; i < lines.length; i++) {
            lines[i].items.sort(function (a, b2) { return a.g.minX - b2.g.minX; });
            txt = "";
            for (j = 0; j < lines[i].items.length; j++) {
                it = lines[i].items[j];
                if (j > 0) {
                    prev = lines[i].items[j - 1];
                    gap = it.g.minX - prev.g.maxX;
                    if (gap > Math.max(it.g.h, prev.g.h) * 0.18) { txt += " "; }   // word gap vs. letter gap
                }
                txt += it.s;
            }
            out.push(txt);
        }
        base = lines[0].items[0].g.l;
        M = MS.cleanTextClone(base);
        MS.removeAnimators(M);
        MS.setText(M, out.join("\r"), ParagraphJustification.LEFT_JUSTIFY, t);
        M.name = MS.uniq(comp, "Merged Text");
        MS.placeAbove(M, MS.topOf(ls));
        u = MS.union(g);
        gm = MS.geo(comp, [M], t)[0];
        MS.moveWorld(comp, [{ l: M, g: gm, d: [u.minX - gm.minX, u.minY - gm.minY, 0] }], t);
        MS.centerAnchors(comp, [M], t);
        for (i = 0; i < ls.length; i++) { ls[i].enabled = false; }
        return M;
    };
    MS.T.splitText = {
        name: "Split Text Layer",
        // Explode text into one shape layer (original text kept, hidden - like AE's own command)
        click: function (c) {
            var comp = MS.comp(), ls = MS.textLayers(comp), shapes = MS.shapesFromText(comp, ls);
            MS.selectOnly(comp, shapes);
            c.selSet = true;
            c.info = shapes.length + " shape layer" + (shapes.length === 1 ? "" : "s") + " created";
        },
        // Explode to shapes and make a separate layer for every letter (text) or every group (shape layer)
        alt: function (c) {
            var comp = MS.comp(), t = comp.time, sel = MS.sel(comp, 1), texts = MS.filter(sel, MS.isText), shps = MS.filter(sel, MS.isShape), i, k, chars, shapes, all = [], ch, sh, nm, parts;
            shps = MS.filter(shps, function (l) { return MS.rootGroups(l).length >= 2; });   // a 1-group shape is already one layer
            if (!texts.length && !shps.length) { MS.fail("Select text layers and/or shape layers with 2+ groups."); }
            for (i = 0; i < texts.length; i++) {
                chars = MS.splitText(comp, texts[i], "chars", t);
                shapes = MS.shapesFromText(comp, chars);
                for (k = 0; k < chars.length; k++) {
                    ch = chars[k];
                    nm = ch.name;
                    sh = (ch.index > 1) ? comp.layer(ch.index - 1) : null;
                    MS.removeLayer(ch);
                    if (sh && (sh instanceof ShapeLayer) && MS.idxL(shapes, sh) !== -1) { sh.name = MS.uniq(comp, nm + " Shape"); }
                }
                texts[i].enabled = false;
                all = all.concat(shapes);
            }
            for (i = 0; i < shps.length; i++) {
                parts = MS.explode(comp, shps[i], 0);       // one layer per group, original hidden
                MS.centerAnchors(comp, parts, t);
                all = all.concat(parts);
            }
            MS.selectOnly(comp, all);
            c.selSet = true;
            c.info = all.length + " layers created";
        },
        shift: function (c) { MS.splitRun(c, "chars", false); },     // Split by Characters
        ctrl: function (c) { MS.splitRun(c, "words", false); },      // Split by Words
        ctrlAlt: function (c) { MS.splitRun(c, "lines", false); },   // Split by Lines
        // Merge: only text layers -> one text layer; any shape layer involved -> one shape layer
        shiftCtrl: function (c) {
            var comp = MS.comp(), t = comp.time, sel = MS.sel(comp, 2), texts = MS.filter(sel, MS.isText), shps = MS.filter(sel, MS.isShape), temp = [], dest, i, before;
            if (texts.length + shps.length < 2) { MS.fail("Select 2 or more text or shape layers to merge."); }
            if (!shps.length) {
                dest = MS.mergeTexts(comp, texts, t);
            } else {
                if (texts.length) { temp = MS.shapesFromText(comp, texts); }
                MS.selectOnly(comp, shps.concat(temp));
                before = MS.allLayers(comp);
                MS.T.explode.alt(c);
                dest = null;
                for (i = 1; i <= comp.numLayers; i++) { if (MS.idxL(before, comp.layer(i)) === -1) { dest = comp.layer(i); break; } }
                for (i = 0; i < temp.length; i++) { MS.removeLayer(temp[i]); }
                if (dest) { dest.name = MS.uniq(comp, "Merged Shapes"); MS.centerAnchors(comp, [dest], t); }
            }
            if (dest) { MS.selectOnly(comp, [dest]); c.selSet = true; }
            c.info = "Merged " + (texts.length + shps.length) + " layers";
        },
        shiftCtrlAlt: function (c) {                                 // Split (lines) + Precomp Each
            MS.splitRun(c, "lines", false, function (comp, made) {
                var i, nc, out = [], L;
                for (i = 0; i < made.length; i++) {
                    nc = comp.layers.precompose([made[i].index], MS.uniq(comp, made[i].name + " Comp"), true);
                    L = MS.findCompLayer(comp, nc);
                    if (L) { out.push(L); }
                }
                return out;
            });
        }
    };

    /* ---------------- Smart Counter ---------------- */
    MS.counterTargets = function (comp, c) {
        var ls = MS.filter(MS.sel(comp), MS.isText), l, p, td;
        if (ls.length) { return ls; }
        l = comp.layers.addText("0");
        p = MS.textDoc(l);
        td = p.value;
        td.fontSize = 120;
        td.justification = ParagraphJustification.CENTER_JUSTIFY;
        td.applyFill = true;
        td.fillColor = MS.argColor(c);
        p.setValue(td);
        MS.tr(l, "ADBE Position").setValue([comp.width / 2, comp.height / 2, 0]);
        l.name = MS.uniq(comp, "MS Counter");
        return [l];
    };
    MS.counterRun = function (c, expr, slider, keys, defVal) {
        var comp = MS.comp(), t = comp.time, ls = MS.counterTargets(comp, c), i;
        for (i = 0; i < ls.length; i++) {
            if (slider) {
                MS.slider(ls[i], slider, keys ? keys[0] : (defVal || 0));
                if (keys) { MS.keys(MS.getFx(ls[i], slider).property(1), [t, t + keys[2]], [keys[0], keys[1]], true); }
            }
            MS.ensureExpr(MS.textDoc(ls[i]), expr);
        }
        return ls;
    };
    MS.T.counter = {
        name: "Smart Counter",
        click: function (c) { MS.counterRun(c, "Math.round(effect(\"MS Counter\")(1))", "MS Counter", [0, 100, 2]); },
        alt: function (c) {
            MS.counterRun(c, "var v=Math.round(effect(\"MS Counter\")(1));\nvar s=String(Math.abs(v)).replace(/\\B(?=(\\d{3})+(?!\\d))/g,\",\");\n(v<0?\"-\":\"\")+\"$\"+s", "MS Counter", [0, 25000, 2]);
        },
        shift: function (c) {
            MS.counterRun(c, "var d=effect(\"MS Countdown (sec)\")(1);\nvar r=Math.max(0,d-(time-inPoint));\nvar m=Math.floor(r/60), s=Math.floor(r%60);\n(m<10?\"0\":\"\")+m+\":\"+(s<10?\"0\":\"\")+s", "MS Countdown (sec)", null, 10);
        },
        ctrl: function (c) {
            MS.counterRun(c, "function p(n){return (n<10?\"0\":\"\")+n;}\nvar t=Math.max(0,time-inPoint)+effect(\"MS Clock Offset (sec)\")(1);\nvar h=Math.floor(t/3600)%24, m=Math.floor(t/60)%60, s=Math.floor(t)%60;\np(h)+\":\"+p(m)+\":\"+p(s)", "MS Clock Offset (sec)", null);
        },
        ctrlAlt: function (c) { MS.counterRun(c, "timeToCurrentFormat()", null, null); },
        shiftCtrl: function (c) {   // odometer rolling digits
            var ls = MS.counterRun(c, "var v=Math.max(0,effect(\"MS Counter\")(1));\nvar s=String(Math.floor(v));\nwhile (s.length<4) { s=\"0\"+s; }\ns", "MS Counter", [0, 9999, 3]), i, idx, fs;
            for (i = 0; i < ls.length; i++) {
                fs = MS.textDoc(ls[i]).value.fontSize || 100;
                idx = MS.addTextAnimator(ls[i], "MS Odometer Roll", ["ADBE Text Position 3D", "ADBE Text Opacity"], "ADBE Text Expressible Selector");
                MS.animProp(ls[i], idx, "ADBE Text Position 3D").setValue([0, -fs * 0.7, 0]);
                MS.animProp(ls[i], idx, "ADBE Text Opacity").setValue(0);
                MS.animSel(ls[i], idx).property("ADBE Text Expressible Amount").expression =
                    "var v=Math.max(0,effect(\"MS Counter\")(1));\nvar place=textTotal-textIndex;\nvar f=(v/Math.pow(10,place))%1;\n" +
                    "var k=(f>0.9)?(f-0.9)/0.1*100:0;\n[k,k,k]";
            }
        }
    };

    /* ---------------- Typewriter Pro ---------------- */
    MS.typeRun = function (c, expr, setup) {
        var comp = MS.comp(), ls = MS.textLayers(comp), i;
        for (i = 0; i < ls.length; i++) {
            if (setup) { setup(ls[i], comp); }
            MS.ensureExpr(MS.textDoc(ls[i]), expr);
        }
    };
    MS.CURSOR = "var cur=(Math.floor(time*2)%2==0)?\"\\u2588\":\" \";\n";
    MS.T.typewriter = {
        name: "Typewriter Pro",
        click: function (c) {
            MS.typeRun(c, "var speed=14;\nvar txt=String(value);\nvar n=Math.max(0,Math.floor((time-inPoint)*speed));\n" + MS.CURSOR + "txt.substr(0,n)+cur");
        },
        alt: function (c) {
            MS.typeRun(c, "var speed=effect(\"MS Type Speed (chars/sec)\")(1);\nvar dl=effect(\"MS Start Delay (sec)\")(1);\nvar txt=String(value);\n" +
                "var n=Math.max(0,Math.floor((time-inPoint-dl)*speed));\n" + MS.CURSOR + "txt.substr(0,n)+cur", function (l) {
                MS.slider(l, "MS Type Speed (chars/sec)", 14);
                MS.slider(l, "MS Start Delay (sec)", 0);
            });
        },
        shift: function (c) {
            MS.typeRun(c, "var rate=4;\nvar w=String(value).split(\" \");\nvar n=Math.max(0,Math.floor((time-inPoint)*rate));\n" + MS.CURSOR + "w.slice(0,n).join(\" \")+cur");
        },
        ctrl: function (c) {     // terminal hacker style
            MS.typeRun(c, "var txt=String(value);\nseedRandom(7,true);\nvar t=Math.max(0,time-inPoint), n=0, acc=0;\n" +
                "while (n<txt.length && acc+random(0.03,0.12)<=t) { acc+=random(0.03,0.12); n++; }\n" +
                "var cur=(Math.floor(time*3)%2==0)?\"_\":\" \";\n\"> \"+txt.substr(0,n)+cur", function (l) {
                var p = MS.textDoc(l), td = p.value;
                td.applyFill = true;
                td.fillColor = [0.2, 1, 0.35];
                try { td.font = "CourierNewPSMT"; } catch (e) {}
                try { p.setValue(td); } catch (e2) { td = MS.textDoc(l).value; td.applyFill = true; td.fillColor = [0.2, 1, 0.35]; MS.textDoc(l).setValue(td); }
            });
        },
        ctrlAlt: function (c) {  // audio / marker triggered: each marker reveals the next word
            var comp = MS.comp(), sel = MS.sel(comp, 1), audio = null, i, ref = "thisLayer";
            for (i = 0; i < sel.length; i++) { if (MS.isAV(sel[i]) && sel[i].hasAudio && !sel[i].hasVideo) { audio = sel[i]; break; } }
            if (audio) { ref = "thisComp.layer(" + MS.q(audio.name) + ")"; }
            MS.typeRun(c, "var m=" + ref + ".marker, k=0;\nif (m.numKeys>0) { k=m.nearestKey(time).index; if (m.key(k).time>time) { k--; } }\n" +
                "var w=String(value).split(\" \");\nw.slice(0,k).join(\" \")", function (l, cp) {
                var mk = (audio || l).property("ADBE Marker"), w, j;
                if (mk.numKeys === 0) {
                    w = String(MS.textDoc(l).value.text).split(" ");
                    for (j = 0; j < w.length; j++) { mk.setValueAtTime(cp.time + j * 0.25, new MarkerValue("Type " + (j + 1))); }
                }
            });
        },
        shiftCtrl: function (c) { // scramble / decrypt
            MS.typeRun(c, "var txt=String(value);\nvar chars=\"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&*@\";\nvar p=clamp((time-inPoint)/1.2,0,1);\n" +
                "var n=Math.floor(txt.length*p);\nseedRandom(Math.floor(time*20),true);\nvar out=txt.substr(0,n);\n" +
                "for (var i=n;i<txt.length;i++) { var ch=txt.charAt(i); out+=(ch==\" \"||ch==\"\\r\")?ch:chars.charAt(Math.floor(random(chars.length))); }\nout");
        }
    };

    /* ---------------- Look-At / Orient ---------------- */
    MS.ensureCam = function (comp) {
        var i;
        for (i = 1; i <= comp.numLayers; i++) { if (comp.layer(i) instanceof CameraLayer && comp.layer(i).enabled) { return comp.layer(i); } }
        return MS.newCam(comp, "MS Camera");
    };
    MS.lookPair = function (comp, need3D, useCam) {
        var sel = MS.sel(comp, 1), L = sel[0], T = sel.length > 1 ? sel[1] : null;
        if (!T && useCam) { T = MS.ensureCam(comp); }
        if (need3D && !(L instanceof CameraLayer) && !(L instanceof LightLayer) && !L.threeDLayer) { L.threeDLayer = true; }
        return { L: L, T: T };
    };
    MS.targetRef = function (T) { return (T instanceof CameraLayer || T instanceof LightLayer) ? "T.toWorld([0,0,0])" : "T.toWorld(T.anchorPoint)"; };
    MS.SELFPOS = "var P=hasParent?parent.toWorld(position):position;\n";
    MS.T.lookAt = {
        name: "Look-At / Orient",
        click: function () {    // 2D target tracking
            var comp = MS.comp(), o = MS.lookPair(comp, false, false), T = o.T, g;
            if (!T) {
                g = MS.geo(comp, [o.L], comp.time)[0];
                T = MS.newNull(comp, "MS Look Target");
                MS.tr(T, "ADBE Anchor Point").setValue([50, 50, 0]);
                MS.tr(T, "ADBE Position").setValue([g.ax + 250, g.ay, 0]);
            }
            MS.ensureExpr(MS.tr(o.L, "ADBE Rotate Z"), "var T=thisComp.layer(" + MS.q(T.name) + ");\nvar a=" + MS.targetRef(T) + ";\n" + MS.SELFPOS +
                "radiansToDegrees(Math.atan2(a[1]-P[1],a[0]-P[0]))");
        },
        alt: function () {      // 3D orient to a null
            var comp = MS.comp(), o = MS.lookPair(comp, true, false), T = o.T, P;
            if (!T) {
                P = MS.posGet(o.L, comp.time, false);
                T = MS.null3D(comp, "MS Orient Target", [P[0], P[1], (P.length > 2 ? P[2] : 0) - 400]);
            }
            try { o.L.autoOrient = AutoOrientType.NO_AUTO_ORIENT; } catch (e) {}
            MS.ensureExpr(MS.tr(o.L, "ADBE Orientation"), "var T=thisComp.layer(" + MS.q(T.name) + ");\n" + MS.SELFPOS + "lookAt(" + MS.targetRef(T) + ",P)");
        },
        shift: function () {    // face the active camera
            var comp = MS.comp(), sel = MS.sel(comp, 1), i;
            MS.ensureCam(comp);
            for (i = 0; i < sel.length; i++) {
                if (sel[i] instanceof CameraLayer || sel[i] instanceof LightLayer) { continue; }
                if (!sel[i].threeDLayer) { sel[i].threeDLayer = true; }
                try { sel[i].autoOrient = AutoOrientType.NO_AUTO_ORIENT; } catch (e) {}
                MS.ensureExpr(MS.tr(sel[i], "ADBE Orientation"), "var C=thisComp.activeCamera;\n" + MS.SELFPOS + "lookAt(C.toWorld([0,0,0]),P)");
            }
        },
        ctrl: function () {     // Y-axis rotation only
            var comp = MS.comp(), o = MS.lookPair(comp, true, true);
            MS.ensureExpr(MS.tr(o.L, "ADBE Rotate Y"), "var T=thisComp.layer(" + MS.q(o.T.name) + ");\n" + MS.SELFPOS + "var r=lookAt(" + MS.targetRef(o.T) + ",P);\nr[1]");
        },
        ctrlAlt: function () {  // X-axis rotation only
            var comp = MS.comp(), o = MS.lookPair(comp, true, true);
            MS.ensureExpr(MS.tr(o.L, "ADBE Rotate X"), "var T=thisComp.layer(" + MS.q(o.T.name) + ");\n" + MS.SELFPOS + "var r=lookAt(" + MS.targetRef(o.T) + ",P);\nr[0]");
        },
        shiftCtrl: function () { // instant 180 degree flip
            var comp = MS.comp(), sel = MS.sel(comp, 1), i, l;
            for (i = 0; i < sel.length; i++) {
                l = sel[i];
                if (l.threeDLayer || l instanceof CameraLayer || l instanceof LightLayer) { MS.addToProp(MS.tr(l, "ADBE Rotate Y"), 180); }
                else { MS.addToProp(MS.tr(l, "ADBE Rotate Z"), 180); }
            }
        }
    };


    /* =====================================================================
     * MODULE 5 - PALETTE SWATCHES & GLOBAL COLOR LINKER
     * ===================================================================== */
    MS.sampleColors = function (comp, l, t, grid) {
        var r = MS.rect(l, t), ex = [], i, j, x, y, rx, ry, res, out = [];
        if (r.width <= 0 || r.height <= 0) { MS.fail("\"" + l.name + "\" has no visible pixels at the current time."); }
        rx = Math.max(1, r.width / (grid * 2)); ry = Math.max(1, r.height / (grid * 2));
        for (i = 0; i < grid; i++) {
            for (j = 0; j < grid; j++) {
                x = r.left + r.width * (i + 0.5) / grid; y = r.top + r.height * (j + 0.5) / grid;
                var s = MS.L(l) + "var c=L.sampleImage([" + MS.f(x) + "," + MS.f(y) + "],[" + MS.f(rx) + "," + MS.f(ry) + "],true,time);";
                ex.push(s + "[c[0],c[1]]");
                ex.push(s + "[c[2],c[3]]");
            }
        }
        res = MS.probe(comp, ex, t);
        for (i = 0; i < res.length; i += 2) { out.push([res[i][0], res[i][1], res[i + 1][0], res[i + 1][1]]); }
        return out;
    };
    MS.dominantColor = function (comp, l, t) {
        var s = MS.sampleColors(comp, l, t, 5), bins = [], i, h, b, best = -1, bi = -1, w, tot = [0, 0, 0, 0];
        for (i = 0; i < 13; i++) { bins.push({ w: 0, c: [0, 0, 0] }); }
        for (i = 0; i < s.length; i++) {
            if (s[i][3] < 0.1) { continue; }
            h = MS.rgb2hsl(s[i]);
            b = (h[1] < 0.12) ? 12 : Math.floor(h[0] * 12) % 12;
            w = s[i][3] * (0.3 + h[1]);
            bins[b].w += w;
            bins[b].c[0] += s[i][0] * w; bins[b].c[1] += s[i][1] * w; bins[b].c[2] += s[i][2] * w;
            tot[0] += s[i][0]; tot[1] += s[i][1]; tot[2] += s[i][2]; tot[3]++;
        }
        for (i = 0; i < 13; i++) { if (bins[i].w > best) { best = bins[i].w; bi = i; } }
        if (best <= 0) { if (!tot[3]) { MS.fail("Could not sample any color from \"" + l.name + "\"."); } return [tot[0] / tot[3], tot[1] / tot[3], tot[2] / tot[3]]; }
        return [bins[bi].c[0] / best, bins[bi].c[1] / best, bins[bi].c[2] / best];
    };
    MS.extractPalette = function (comp, l, t, k) {
        var s = MS.filter(MS.sampleColors(comp, l, t, 7), function (c) { return c[3] > 0.1; }), cent = [], i, j, it, best, bd, d, sums, lum;
        if (s.length < k) { MS.fail("Not enough visible pixels to extract a palette."); }
        cent.push(s[0]);
        while (cent.length < k) {   // farthest-point seeding
            best = null; bd = -1;
            for (i = 0; i < s.length; i++) {
                d = 1e9;
                for (j = 0; j < cent.length; j++) { d = Math.min(d, Math.pow(s[i][0] - cent[j][0], 2) + Math.pow(s[i][1] - cent[j][1], 2) + Math.pow(s[i][2] - cent[j][2], 2)); }
                if (d > bd) { bd = d; best = s[i]; }
            }
            cent.push(best);
        }
        for (it = 0; it < 10; it++) {
            sums = [];
            for (j = 0; j < k; j++) { sums.push([0, 0, 0, 0]); }
            for (i = 0; i < s.length; i++) {
                bd = 1e9; best = 0;
                for (j = 0; j < k; j++) {
                    d = Math.pow(s[i][0] - cent[j][0], 2) + Math.pow(s[i][1] - cent[j][1], 2) + Math.pow(s[i][2] - cent[j][2], 2);
                    if (d < bd) { bd = d; best = j; }
                }
                sums[best][0] += s[i][0]; sums[best][1] += s[i][1]; sums[best][2] += s[i][2]; sums[best][3]++;
            }
            for (j = 0; j < k; j++) { if (sums[j][3]) { cent[j] = [sums[j][0] / sums[j][3], sums[j][1] / sums[j][3], sums[j][2] / sums[j][3]]; } }
        }
        lum = function (c) { return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
        cent.sort(function (a, b) { return lum(a) - lum(b); });
        var out = [];
        for (j = 0; j < cent.length; j++) { out.push(MS.rgb2hex(cent[j])); }
        return out;
    };

    /* ---------------- color application ---------------- */
    MS.shapeColorProps = function (l, kind) {   // kind "fill" | "stroke"
        var out = [], gm = (kind === "stroke") ? "ADBE Vector Graphic - Stroke" : "ADBE Vector Graphic - Fill", pm = (kind === "stroke") ? "ADBE Vector Stroke Color" : "ADBE Vector Fill Color";
        MS.walkGroups(l.property("ADBE Root Vectors Group"), gm, function (g) { out.push(g.property(pm)); });
        return out;
    };
    MS.setTextColor = function (l, rgb, t, stroke) {
        var p = MS.textDoc(l), td = p.valueAtTime(t, true);
        if (stroke) { td.applyStroke = true; td.strokeColor = rgb; if (!td.strokeWidth) { td.strokeWidth = 3; } }
        else { td.applyFill = true; td.fillColor = rgb; }
        MS.setVal(MS.textDoc(l), td, t);
    };
    MS.isSolidLayer = function (l) {
        try { return (l instanceof AVLayer) && !l.nullLayer && !l.adjustmentLayer && (l.source instanceof FootageItem) && (l.source.mainSource instanceof SolidSource); } catch (e) { return false; }
    };
    MS.applyColor = function (comp, layers, rgb, mode, t) {
        var sp = MS.filter(MS.selProps(comp), function (p) { return p.propertyValueType === PropertyValueType.COLOR; }), i, j, l, ps, n = 0, c4 = [rgb[0], rgb[1], rgb[2], 1];
        if (sp.length) {
            for (i = 0; i < sp.length; i++) { MS.setVal(sp[i], c4, t); }
            return sp.length;
        }
        for (i = 0; i < layers.length; i++) {
            l = layers[i];
            if (MS.isShape(l)) {
                ps = MS.shapeColorProps(l, mode === "stroke" ? "stroke" : "fill");
                if (!ps.length && mode !== "stroke") { ps = MS.shapeColorProps(l, "stroke"); }
                if (!ps.length && mode === "stroke") {
                    MS.addStroke(l.property("ADBE Root Vectors Group"), rgb, 4, 2);
                    n++;
                }
                for (j = 0; j < ps.length; j++) { MS.setVal(ps[j], c4, t); n++; }
            } else if (MS.isText(l)) {
                MS.setTextColor(l, rgb, t, mode === "stroke");
                n++;
            } else if (mode !== "stroke" && MS.isVisual(l) && !l.nullLayer && !l.adjustmentLayer) {
                if (MS.isSolidLayer(l) && !MS.getFx(l, "MS Fill")) { l.source.mainSource.color = rgb; }
                else { MS.applyFillFx(l, rgb); }
                n++;
            }
        }
        if (!n) { MS.fail(mode === "stroke" ? "No stroke-capable layers selected (shape or text)." : "Select shape, text, solid or footage layers."); }
        return n;
    };
    /* link the color(s) of a layer to an expression */
    MS.linkLayerColor = function (l, expr) {
        var n = 0, ps, j, idx, g, i;
        if (MS.isShape(l)) {
            ps = MS.shapeColorProps(l, "fill").concat(MS.shapeColorProps(l, "stroke"));
            for (j = 0; j < ps.length; j++) { MS.ensureExpr(ps[j], expr); n++; }
        } else if (MS.isText(l)) {
            g = MS.TXT_ANIMS(l); idx = 0;
            for (i = 1; i <= g.numProperties; i++) { if (g.property(i).name === "MS Color Link") { idx = i; } }
            if (!idx) { idx = MS.addTextAnimator(l, "MS Color Link", ["ADBE Text Fill Color"], "ADBE Text Selector"); }
            MS.ensureExpr(MS.animProp(l, idx, "ADBE Text Fill Color"), expr);
            n++;
        } else if (MS.isVisual(l) && !l.nullLayer && !l.adjustmentLayer) {
            if (!MS.getFx(l, "MS Fill")) { MS.applyFillFx(l, [1, 1, 1]); }
            MS.ensureExpr(MS.firstOfType(MS.getFx(l, "MS Fill"), PropertyValueType.COLOR), expr);
            n++;
        }
        return n;
    };
    MS.colorLinkLayers = function (comp) {
        return MS.needSome(MS.filter(MS.sel(comp, 1), function (l) { return MS.isVisual(l) && !l.nullLayer && !l.adjustmentLayer; }), "Select shape, text, solid or footage layers.");
    };
    MS.masterNull = function (comp, name, ctrlName, rgb, reuse) {
        var n = reuse ? MS.layerByName(comp, name) : null;
        if (!n) { n = MS.newNull(comp, name); n.label = 9; n.moveToBeginning(); }
        var p = MS.colorCtrl(n, ctrlName, rgb);
        if (rgb) { MS.getFx(n, ctrlName).property(1).setValue([rgb[0], rgb[1], rgb[2], 1]); }
        return n;
    };
    MS.ctrlRef = function (n, ctrlName) { return "thisComp.layer(" + MS.q(n.name) + ").effect(" + MS.q(ctrlName) + ")(1)"; };
    /* bake color expressions (optionally only those matching "test") into static colors */
    MS.bakeColors = function (comp, layers, test) {
        var t = comp.time, n = 0, i, l, g, j, c, td, p;
        for (i = 0; i < layers.length; i++) {
            l = layers[i];
            MS.walk(l, function (q) {
                if (q.propertyValueType === PropertyValueType.COLOR && q.canSetExpression && q.expression && (!test || test(q.expression))) {
                    var v = q.valueAtTime(t, false);
                    q.expression = "";
                    MS.setVal(q, v, t);
                    n++;
                }
            });
            if (MS.isText(l)) {
                g = MS.TXT_ANIMS(l);
                for (j = g.numProperties; j >= 1; j--) {
                    if (MS.TXT_ANIMS(l).property(j).name === "MS Color Link") {
                        p = MS.TXT_ANIMS(l).property(j).property("ADBE Text Animator Properties").property("ADBE Text Fill Color");
                        c = p ? p.valueAtTime(t, true) : null;
                        MS.TXT_ANIMS(l).property(j).remove();
                        if (c) { td = MS.textDoc(l).valueAtTime(t, true); td.applyFill = true; td.fillColor = [c[0], c[1], c[2]]; MS.setVal(MS.textDoc(l), td, t); }
                        n++;
                    }
                }
            }
        }
        return n;
    };

    MS.T.swatch = {
        name: "Palette Swatch",
        click: function (c) {   // apply to fill / text color
            var comp = MS.comp();
            MS.applyColor(comp, MS.sel(comp), MS.hex2rgb(c.args.hex), "fill", comp.time);
        },
        alt: function () {      // color picker: dominant color of the selected layer -> slot
            var comp = MS.comp(), ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select a layer to pick a color from.");
            return MS.rgb2hex(MS.dominantColor(comp, ls[0], comp.time));
        },
        shift: function (c) {   // stroke only
            var comp = MS.comp();
            MS.applyColor(comp, MS.sel(comp), MS.hex2rgb(c.args.hex), "stroke", comp.time);
        },
        ctrl: function () {     // auto-extract a 5-color palette from an image / video layer
            var comp = MS.comp(), ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select an image or video layer.");
            return MS.extractPalette(comp, ls[0], comp.time, 5);
        },
        ctrlAlt: function (c) { // link swatch to an expression color control
            var comp = MS.comp(), ls = MS.colorLinkLayers(comp), cn = "MS Swatch - " + (c.args.name || "Color"), n = MS.masterNull(comp, "MS Palette", cn, MS.hex2rgb(c.args.hex), true), i;
            for (i = 0; i < ls.length; i++) { if (!MS.eqL(ls[i], n)) { MS.linkLayerColor(ls[i], MS.ctrlRef(n, cn)); } }
        }
    };

    MS.T.colorLink = {
        name: "Global Color Linker",
        click: function (c) {
            var comp = MS.comp(), ls = MS.colorLinkLayers(comp), n = MS.masterNull(comp, "MS Master Color", "MS Master Color", MS.argColor(c), true), i;
            for (i = 0; i < ls.length; i++) { if (!MS.eqL(ls[i], n)) { MS.linkLayerColor(ls[i], MS.ctrlRef(n, "MS Master Color")); } }
        },
        alt: function () {      // unlink from master (keeps the current color)
            var comp = MS.comp(), n = MS.bakeColors(comp, MS.sel(comp, 1), function (e) { return e.indexOf("MS Master Color") !== -1 || e.indexOf("MS Palette") !== -1 || e.indexOf("MS Swatch") !== -1; });
            if (!n) { MS.fail("The selected layers are not linked to a master color."); }
        },
        shift: function (c) {   // link to a designated layer index
            var comp = MS.comp(), ls = MS.colorLinkLayers(comp), s = prompt("Link colors to the Color Control on layer index (1-" + comp.numLayers + "):", "1", "MotionSeeds - Color Linker"), idx, L, g, i, cn = null;
            if (s === null) { return; }
            idx = parseInt(s, 10);
            if (isNaN(idx) || idx < 1 || idx > comp.numLayers) { MS.fail("Invalid layer index."); }
            L = comp.layer(idx);
            g = MS.fx(L);
            if (!g) { MS.fail("Layer " + idx + " cannot hold a Color Control."); }
            for (i = 1; i <= g.numProperties; i++) { if (g.property(i).matchName === "ADBE Color Control") { cn = g.property(i).name; break; } }
            if (!cn) { cn = "MS Color"; MS.colorCtrl(L, cn, MS.argColor(c)); }
            for (i = 0; i < ls.length; i++) { if (!MS.eqL(ls[i], L)) { MS.linkLayerColor(ls[i], "thisComp.layer(" + idx + ").effect(" + MS.q(cn) + ")(1)"); } }
        },
        ctrl: function (c) {    // link with per-layer HSL offsets
            var comp = MS.comp(), ls = MS.colorLinkLayers(comp), n = MS.masterNull(comp, "MS Master Color", "MS Master Color", MS.argColor(c), true), i, ex;
            ex = "var c=" + MS.ctrlRef(n, "MS Master Color") + ";\nvar h=rgbToHsl(c);\n" +
                "var ho=effect(\"MS Hue Offset\")(1)/360, so=effect(\"MS Sat Offset\")(1)/100, lo=effect(\"MS Light Offset\")(1)/100;\n" +
                "hslToRgb([((h[0]+ho)%1+1)%1,clamp(h[1]+so,0,1),clamp(h[2]+lo,0,1),h[3]])";
            for (i = 0; i < ls.length; i++) {
                if (MS.eqL(ls[i], n)) { continue; }
                MS.slider(ls[i], "MS Hue Offset", (i * 30) % 360);
                MS.slider(ls[i], "MS Sat Offset", 0);
                MS.slider(ls[i], "MS Light Offset", 0);
                MS.linkLayerColor(ls[i], ex);
            }
        },
        ctrlAlt: function () {  // bake hex values into hard property colors
            var comp = MS.comp(), n = MS.bakeColors(comp, MS.sel(comp, 1), null);
            if (!n) { MS.fail("No color expressions found on the selected layers."); }
        },
        shiftCtrl: function (c) {   // random linked color mapping
            var comp = MS.comp(), ls = MS.colorLinkLayers(comp), pal = MS.argPalette(c), n = MS.layerByName(comp, "MS Palette Master"), i, cn;
            if (!n) { n = MS.newNull(comp, "MS Palette Master"); n.label = 9; n.moveToBeginning(); }
            for (i = 0; i < pal.length; i++) { MS.colorCtrl(n, "MS Palette " + (i + 1), pal[i]); MS.getFx(n, "MS Palette " + (i + 1)).property(1).setValue([pal[i][0], pal[i][1], pal[i][2], 1]); }
            for (i = 0; i < ls.length; i++) {
                if (MS.eqL(ls[i], n)) { continue; }
                cn = "MS Palette " + (1 + Math.floor(Math.random() * pal.length));
                MS.linkLayerColor(ls[i], MS.ctrlRef(n, cn));
            }
        }
    };


    /* =====================================================================
     * MODULE 6 - SEQUENCE & STAGGER
     * ===================================================================== */
    MS.staggerOrder = function (comp, order) {
        var ls = MS.sel(comp, 2), i, j, tmp;
        if (order === "random") {
            for (i = ls.length - 1; i > 0; i--) { j = Math.floor(Math.random() * (i + 1)); tmp = ls[i]; ls[i] = ls[j]; ls[j] = tmp; }
        } else {
            ls.sort(function (a, b) { return order === "down" ? b.index - a.index : a.index - b.index; });
        }
        return ls;
    };
    MS.snap = function (comp, t) { return Math.round(t / comp.frameDuration) * comp.frameDuration; };
    MS.staggerRun = function (c) {
        var comp = MS.comp(), fd = comp.frameDuration, fr = MS.num(c.args.frames, 5), grp = Math.max(1, Math.round(MS.num(c.args.group, 1)));
        var ls = MS.staggerOrder(comp, c.args.order || "up"), base = ls[0].inPoint, i, k, target, l, acc = 0, lastK = 0, gEnd, n = 0, props, j, fade, op, end;
        if (c.mod === "shift") {                     // end-to-end chaining (no gaps)
            target = base; gEnd = base;
            for (i = 0; i < ls.length; i++) {
                if (i > 0 && i % grp === 0) { target = gEnd; }
                l = ls[i];
                l.startTime += MS.snap(comp, target - l.inPoint);
                gEnd = Math.max(gEnd, l.outPoint);
            }
            return;
        }
        for (i = 0; i < ls.length; i++) {
            l = ls[i];
            k = Math.floor(i / grp);
            if (c.mod === "alt") {                   // randomized intervals
                if (k !== lastK) { acc += Math.max(0, Math.round(fr * MS.rnd(0.35, 1.65))); lastK = k; }
                target = base + acc * fd;
            } else {
                target = base + k * fr * fd;
            }
            target = MS.snap(comp, target);
            if (c.mod === "ctrl") {                  // in-points only (trim, content stays)
                if (target < l.outPoint - fd) { try { l.inPoint = target; } catch (eIn) { l.inPoint = Math.max(target, l.startTime); } }
            } else if (c.mod === "ctrlAlt") {        // delay animation with an expression instead of moving layers
                props = [];
                MS.walk(l, function (p) { if (p.numKeys > 0 && p.canSetExpression && MS.canKey(p) && p.propertyValueType !== PropertyValueType.TEXT_DOCUMENT) { props.push(p); } });
                for (j = 0; j < props.length; j++) { MS.ensureExpr(props[j], "valueAtTime(time-framesToTime(" + Math.round((target - base) / fd) + "))"); n++; }
            } else {
                l.startTime += target - l.inPoint;
                if (c.mod === "shiftCtrl") {         // + automatic opacity fade-in
                    fade = Math.max(5, fr) * fd;
                    op = MS.tr(l, "ADBE Opacity");
                    end = op.valueAtTime(l.inPoint + fade, true);
                    op.setValueAtTime(l.inPoint, 0);
                    op.setValueAtTime(l.inPoint + fade, end > 0 ? end : 100);
                }
            }
        }
        if (c.mod === "ctrlAlt" && !n) { MS.fail("The selected layers have no keyframes to delay."); }
    };
    MS.T.stagger = {
        name: "Sequence & Stagger",
        click: MS.staggerRun, alt: MS.staggerRun, shift: MS.staggerRun, ctrl: MS.staggerRun, ctrlAlt: MS.staggerRun, shiftCtrl: MS.staggerRun
    };

    /* =====================================================================
     * MODULE 7 - CUSTOM TOOLKIT (assets/ffx, assets/aep, assets/color)
     * ===================================================================== */
    MS.assetBases = function () {
        var a = [];
        if (MS.root) { a.push(MS.root + "/assets"); }
        a.push(Folder.userData.fsName.replace(/\\/g, "/") + "/MotionSeeds/assets");
        return a;
    };
    MS.resolveAsset = function (v) {
        var b = MS.assetBases(), i, f;
        if (!v) { return null; }
        v = String(v).replace(/\\/g, "/");
        if (v.indexOf("assets/") === 0) {
            for (i = 0; i < b.length; i++) { f = new File(b[i] + "/" + v.substr(7)); if (f.exists) { return f; } }
            return null;
        }
        f = new File(v);
        return f.exists ? f : null;
    };
    MS.typeOfFile = function (name) {
        var e = String(name).split(".").pop().toLowerCase();
        if (e === "ffx") { return "ffx"; }
        if (e === "aep" || e === "aet") { return "aep"; }
        if (e === "jsx" || e === "jsxbin") { return "jsx"; }
        return "";
    };
    MS.writeText = function (path, s) {
        var f = new File(path);
        try { f.parent.create(); } catch (e0) {}
        f.encoding = "UTF-8";
        if (!f.open("w")) { return false; }
        f.write(s);
        f.close();
        return true;
    };
    MS.readText = function (path) {
        var f = new File(path), s;
        if (!f.exists) { return null; }
        f.encoding = "UTF-8";
        if (!f.open("r")) { return null; }
        s = f.read();
        f.close();
        return s;
    };
    MS.T.assetLink = {
        name: "Link Preset",
        noUndo: true,
        click: function () {
            var isWin = $.os.indexOf("Windows") !== -1, filt, f, type, b = MS.assetBases(), i, sub, dst, fo;
            filt = isWin ? "MotionSeeds presets:*.ffx;*.aep;*.aet;*.jsx;*.jsxbin,All files:*.*" : function (x) { return (x instanceof Folder) || /\.(ffx|aep|aet|jsx|jsxbin)$/i.test(x.name); };
            f = File.openDialog("MotionSeeds - link a preset (.ffx / .aep / .jsx) to this Toolkit item", filt, false);
            if (!f) { return { cancelled: true }; }
            type = MS.typeOfFile(f.name);
            if (!type) { MS.fail("Unsupported file. Use .ffx, .aep/.aet or .jsx/.jsxbin"); }
            sub = (type === "ffx") ? "ffx" : (type === "aep" ? "aep" : "scripts");
            for (i = 0; i < b.length; i++) {
                try {
                    fo = new Folder(b[i] + "/" + sub);
                    if (!fo.exists) { fo.create(); }
                    dst = new File(fo.fsName + "/" + f.name);
                    if (dst.exists && dst.fsName === f.fsName) { return { value: "assets/" + sub + "/" + f.name, type: type, name: decodeURI(f.name).replace(/\.[^\.]+$/, "") }; }
                    if (f.copy(dst.fsName)) { return { value: "assets/" + sub + "/" + f.name, type: type, name: decodeURI(f.name).replace(/\.[^\.]+$/, "") }; }
                } catch (e) {}
            }
            return { value: f.fsName.replace(/\\/g, "/"), type: type, name: decodeURI(f.name).replace(/\.[^\.]+$/, "") };
        }
    };
    MS.T.assetList = {
        name: "List Assets",
        noUndo: true,
        click: function () {
            var b = MS.assetBases(), out = [], seen = {}, i, j, k, subs = ["ffx", "aep"], fs, n;
            for (i = 0; i < b.length; i++) {
                for (k = 0; k < subs.length; k++) {
                    try {
                        fs = new Folder(b[i] + "/" + subs[k]).getFiles();
                        for (j = 0; j < fs.length; j++) {
                            if (!(fs[j] instanceof File) || !MS.typeOfFile(fs[j].name)) { continue; }
                            n = "assets/" + subs[k] + "/" + fs[j].name;
                            if (!seen[n]) { seen[n] = 1; out.push({ value: n, type: MS.typeOfFile(fs[j].name), name: decodeURI(fs[j].name).replace(/\.[^\.]+$/, "") }); }
                        }
                    } catch (e) {}
                }
            }
            return out;
        }
    };
    MS.T.dataSave = {
        name: "Save Data",
        noUndo: true,
        click: function (c) {
            var b = MS.assetBases(), i, rel = (c.args.kind === "palette") ? "/color/palette.json" : "/color/toolkit.json";
            for (i = 0; i < b.length; i++) { try { if (MS.writeText(b[i] + rel, c.args.json)) { return "saved"; } } catch (e) {} }
            return "";
        }
    };
    MS.T.dataLoad = {
        name: "Load Data",
        noUndo: true,
        click: function (c) {
            var b = MS.assetBases(), i, s, rel = (c.args.kind === "palette") ? "/color/palette.json" : "/color/toolkit.json";
            for (i = 0; i < b.length; i++) { try { s = MS.readText(b[i] + rel); if (s) { return s; } } catch (e) {} }
            return "";
        }
    };
    MS.LABELS = ["#B53838", "#E4D84C", "#A9CBC7", "#E5BCC9", "#A9A9CA", "#E7C19E", "#B3C7B3", "#677DE0", "#4AA44C", "#8E2C9A", "#E8920D", "#7F452A", "#F46DD6", "#3DA2A5", "#A89677", "#1E401E"];
    MS.nearestLabel = function (hex) {
        var c = MS.hex2rgb(hex), best = 1, bd = 1e9, i, l, d;
        for (i = 0; i < MS.LABELS.length; i++) {
            l = MS.hex2rgb(MS.LABELS[i]);
            d = Math.pow(c[0] - l[0], 2) + Math.pow(c[1] - l[1], 2) + Math.pow(c[2] - l[2], 2);
            if (d < bd) { bd = d; best = i + 1; }
        }
        return best;
    };
    MS.exprSnapshot = function (layers) {
        var map = {}, i;
        for (i = 0; i < layers.length; i++) {
            (function (l, li) { MS.walk(l, function (p) { if (p.canSetExpression && p.expression) { map[li + ":" + MS.idxPath(p).join(",")] = 1; } }); }(layers[i], i));
        }
        return map;
    };
    MS.stripNewExpr = function (layers, snap) {
        var i, n = 0;
        for (i = 0; i < layers.length; i++) {
            (function (l, li) {
                var list = [];
                MS.walk(l, function (p) { if (p.canSetExpression && p.expression && !snap[li + ":" + MS.idxPath(p).join(",")]) { list.push(p); } });
                var j;
                for (j = 0; j < list.length; j++) { try { list[j].expression = ""; n++; } catch (e) {} }
            }(layers[i], i));
        }
        return n;
    };
    MS.findComps = function (folder, out) {
        var i, it;
        for (i = 1; i <= folder.numItems; i++) {
            it = folder.item(i);
            if (it instanceof CompItem) { out.push(it); } else if (it instanceof FolderItem) { MS.findComps(it, out); }
        }
        return out;
    };
    MS.toolkitRun = function (c) {
        var it = c.args.item || {}, mod = c.mod, comp, sel, t, file, type, targets, i, adj, snap, top, io, imp, comps, L, rgb, lab, ls;
        if (mod === "shiftCtrl") {                   // filter project layers by label color
            comp = MS.comp();
            lab = MS.nearestLabel(it.color || "#ffffff");
            ls = MS.filter(MS.allLayers(comp), function (x) { return x.label === lab; });
            MS.selectOnly(comp, ls);
            c.selSet = true;
            if (!ls.length) { MS.fail("No layers use the label color closest to \"" + (it.name || "this item") + "\"."); }
            return;
        }
        if (it.type === "color") {
            comp = MS.comp(); t = comp.time; sel = MS.sel(comp); rgb = MS.hex2rgb(it.value || it.color);
            if (mod === "alt") {
                adj = comp.layers.addSolid([1, 1, 1], MS.uniq(comp, "MS Color - " + (it.name || "Tint")), comp.width, comp.height, comp.pixelAspect, comp.duration);
                adj.adjustmentLayer = true;
                MS.placeAbove(adj, MS.topOf(sel));
                MS.applyFillFx(adj, rgb);
                return;
            }
            if (!sel.length) {
                L = comp.layers.addSolid(rgb, MS.uniq(comp, it.name || "MS Color"), comp.width, comp.height, comp.pixelAspect, comp.duration);
                return;
            }
            if (mod === "shift") { for (i = 0; i < sel.length; i++) { MS.removeFxNamed(sel[i], "MS Fill"); } }
            if (mod === "ctrlAlt") { MS.bakeColors(comp, sel, null); }
            if (mod === "ctrl") {
                var sp = [];
                for (i = 0; i < sel.length; i++) {
                    if (MS.isShape(sel[i])) { sp = sp.concat(MS.shapeColorProps(sel[i], "fill")); }
                    else if (MS.isText(sel[i])) { MS.textDoc(sel[i]).setValueAtTime(t, (function (l) { var td = MS.textDoc(l).valueAtTime(t, true); td.applyFill = true; td.fillColor = rgb; return td; }(sel[i]))); }
                    else if (MS.isVisual(sel[i]) && !sel[i].nullLayer) { MS.applyFillFx(sel[i], rgb); sp.push(MS.firstOfType(MS.getFx(sel[i], "MS Fill"), PropertyValueType.COLOR)); }
                }
                for (i = 0; i < sp.length; i++) { sp[i].setValueAtTime(t, [rgb[0], rgb[1], rgb[2], 1]); }
                return;
            }
            MS.applyColor(comp, sel, rgb, "fill", t);
            return;
        }
        file = MS.resolveAsset(it.value);
        if (!it.value) { MS.fail("\"" + (it.name || "Tool") + "\" has no preset linked. Edit the toolkit and use the link button."); }
        if (!file) { MS.fail("Linked file not found: " + it.value); }
        type = MS.typeOfFile(file.name);
        if (type === "jsx") { $.evalFile(file); return; }
        if (type === "aep") {
            io = new ImportOptions(file);
            try { if (io.canImportAs(ImportAsType.PROJECT)) { io.importAs = ImportAsType.PROJECT; } } catch (e0) {}
            imp = app.project.importFile(io);
            comps = (imp instanceof FolderItem) ? MS.findComps(imp, []) : ((imp instanceof CompItem) ? [imp] : []);
            if (mod === "ctrlAlt") {
                for (i = 0; i < comps.length; i++) { var j; for (j = 1; j <= comps[i].numLayers; j++) { MS.walk(comps[i].layer(j), function (p) { if (p.canSetExpression && p.expression) { try { p.expression = ""; } catch (e1) {} } }); } }
            }
            comp = MS.compOrNull();
            if (!comp || mod === "alt" || !comps.length) { return; }
            comps.sort(function (a, b) { return b.numLayers - a.numLayers; });
            L = comp.layers.add(comps[0]);
            MS.placeAbove(L, MS.topOf(MS.sel(comp)));
            if (mod === "ctrl") {
                L.startTime = comp.time;
                L.property("ADBE Marker").setValueAtTime(comp.time, new MarkerValue(it.name || "Preset"));
            }
            return;
        }
        if (type !== "ffx") { MS.fail("Unsupported preset type: " + file.name); }
        comp = MS.comp(); t = comp.time; sel = MS.sel(comp);
        targets = sel;
        if (mod === "alt") {
            adj = comp.layers.addSolid([1, 1, 1], MS.uniq(comp, "MS FX - " + (it.name || "Preset")), comp.width, comp.height, comp.pixelAspect, comp.duration);
            adj.adjustmentLayer = true;
            MS.placeAbove(adj, MS.topOf(sel));
            targets = [adj];
        }
        if (!targets.length) {
            top = comp.layers.addSolid([0.5, 0.5, 0.5], MS.uniq(comp, it.name || "MS Preset"), comp.width, comp.height, comp.pixelAspect, comp.duration);
            targets = [top];
        }
        if (mod === "shift") {
            for (i = 0; i < targets.length; i++) { var g = MS.fx(targets[i]), k; if (g) { for (k = g.numProperties; k >= 1; k--) { MS.fx(targets[i]).property(k).remove(); } } }
        }
        if (mod === "ctrl") {
            for (i = 0; i < targets.length; i++) { targets[i].property("ADBE Marker").setValueAtTime(t, new MarkerValue(it.name || "Preset")); }
        }
        snap = (mod === "ctrlAlt") ? MS.exprSnapshot(targets) : null;
        MS.selectOnly(comp, targets);
        targets[0].applyPreset(file);
        c.selSet = true;
        if (snap) { MS.stripNewExpr(targets, snap); }
    };
    MS.T.toolkit = {
        name: "Custom Toolkit",
        click: MS.toolkitRun, alt: MS.toolkitRun, shift: MS.toolkitRun, ctrl: MS.toolkitRun, ctrlAlt: MS.toolkitRun, shiftCtrl: MS.toolkitRun
    };


    /* =====================================================================
     * MODULE 8 - QUICK UTILS & KEYFRAMES
     * ===================================================================== */

    /* ---------------- Point to Null ---------------- */
    MS.pathLayer = function (comp) {
        var ls = MS.sel(comp, 1), i, fp;
        for (i = 0; i < ls.length; i++) { fp = MS.findPath(ls[i]); if (fp) { return { l: ls[i], fp: fp }; } }
        MS.fail("Select a layer that has a mask or a shape path.");
    };
    MS.pathFnExpr = function (l, fp) {   // defines P (the path) and toC(p): path space -> comp/world space
        var ref = MS.pathExprRef(l, fp);
        return "var L=thisComp.layer(" + MS.q(l.name) + ");\n" + MS.TF_FN + "\nvar P=" + ref.ref + ";\nfunction toC(p){" + ref.chain +
            (l.threeDLayer ? "var w=L.toWorld(p);return [w[0],w[1],w.length>2?w[2]:0];}\n" : "var w=L.toComp(p);return [w[0],w[1]];}\n");
    };
    MS.makePointNull = function (comp, l, fp, vi) {
        var n = MS.newNull(comp, "MS Point " + (vi + 1) + " - " + l.name);
        MS.tr(n, "ADBE Anchor Point").setValue([50, 50, 0]);
        if (l.threeDLayer) { n.threeDLayer = true; }
        n.label = 11;
        MS.ensureExpr(MS.tr(n, "ADBE Position"), MS.pathFnExpr(l, fp) + "toC(P.points()[" + vi + "])");
        MS.placeAbove(n, l);
        return n;
    };
    MS.T.pointNull = {
        name: "Point to Null",
        click: function () {    // vertex 1 (scripts cannot read which vertex is selected in the viewer)
            var comp = MS.comp(), o = MS.pathLayer(comp);
            MS.makePointNull(comp, o.l, o.fp, 0);
        },
        alt: function () {      // nulls for all vertices
            var comp = MS.comp(), o = MS.pathLayer(comp), n = o.fp.prop.valueAtTime(comp.time, false).vertices.length, i;
            for (i = n - 1; i >= 0; i--) { MS.makePointNull(comp, o.l, o.fp, i); }
        },
        shift: function () {    // trace a new path through the selected layers / nulls
            var comp = MS.comp(), ls = MS.sel(comp, 2), names = [], i, s, gi;
            for (i = 0; i < ls.length; i++) { names.push(MS.q(ls[i].name)); }
            s = MS.newShape(comp, "MS Traced Path");
            MS.placeAbove(s, MS.topOf(ls));
            MS.tr(s, "ADBE Anchor Point").setValue([0, 0, 0]);
            MS.tr(s, "ADBE Position").setValue([0, 0, 0]);
            gi = MS.newGroupIdx(s, "Trace");
            MS.addPath(MS.grpContents(s, gi), [[0, 0], [100, 0]], false);
            MS.addStroke(MS.grpContents(s, gi), [1, 1, 1], 4, 2);
            MS.ensureExpr(MS.grpContents(s, gi).property(1).property("ADBE Vector Shape"),
                "var n=[" + names.join(",") + "];\nvar pts=[];\nfor (var i=0;i<n.length;i++) { var L=thisComp.layer(n[i]); pts.push(fromComp(L.toComp(L.anchorPoint))); }\ncreatePath(pts,[],[],false)");
        },
        ctrl: function () {     // 0-100% path-length tracker
            var comp = MS.comp(), t = comp.time, o = MS.pathLayer(comp), n = MS.newNull(comp, "MS Path Tracker - " + o.l.name), body;
            MS.tr(n, "ADBE Anchor Point").setValue([50, 50, 0]);
            if (o.l.threeDLayer) { n.threeDLayer = true; }
            n.label = 11;
            MS.slider(n, "MS Progress", 0);
            MS.keys(MS.getFx(n, "MS Progress").property(1), [t, t + 2], [0, 100], true);
            body = MS.pathFnExpr(o.l, o.fp) + "var s=clamp(effect(\"MS Progress\")(1)/100,0,1);\n";
            MS.ensureExpr(MS.tr(n, "ADBE Position"), body + "toC(P.pointOnPath(s))");
            MS.ensureExpr(MS.tr(n, "ADBE Rotate Z"), body + "var s0=Math.min(s,0.999);\nvar a=toC(P.pointOnPath(s0)), b=toC(P.pointOnPath(s0+0.001));\nradiansToDegrees(Math.atan2(b[1]-a[1],b[0]-a[0]))");
            MS.placeAbove(n, o.l);
        },
        ctrlAlt: function () {  // specific vertex index
            var comp = MS.comp(), o = MS.pathLayer(comp), cnt = o.fp.prop.valueAtTime(comp.time, false).vertices.length, s, v;
            s = prompt("Attach a Null to vertex number (1 - " + cnt + "):", "1", "MotionSeeds - Point to Null");
            if (s === null) { return; }
            v = parseInt(s, 10);
            if (isNaN(v) || v < 1 || v > cnt) { MS.fail("Vertex number must be between 1 and " + cnt + "."); }
            MS.makePointNull(comp, o.l, o.fp, v - 1);
        },
        shiftCtrl: function () { // bake tracking nulls (position / rotation expressions -> keyframes)
            var comp = MS.comp(), ls = MS.sel(comp, 1), i, n = 0;
            for (i = 0; i < ls.length; i++) {
                if (MS.bakeProp(MS.tr(ls[i], "ADBE Position"), comp, ls[i], 1)) { n++; }
                try { if (MS.bakeProp(MS.tr(ls[i], "ADBE Rotate Z"), comp, ls[i], 1)) { n++; } } catch (e) {}
            }
            if (!n) { MS.fail("No position/rotation expressions to bake on the selected layers."); }
        }
    };

    /* ---------------- Fit to Comp ---------------- */
    MS.fitRun = function (c, mode) {
        var comp = MS.comp(), t = comp.time, ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select visual layers to fit."), list = [], i, r, l, sc, sx, sy, cur, g, items = [], k = 1, cw = comp.width, ch = comp.height, ext;
        if (mode === "safe") { k = 0.9; }
        for (i = 0; i < ls.length; i++) {
            r = MS.rect(ls[i], t);
            if (r.width <= 0 || r.height <= 0) { continue; }
            list.push({ l: ls[i], a: [r.left + r.width / 2, r.top + r.height / 2], r: r });
        }
        if (!list.length) { MS.fail("The selected layers have no visible content."); }
        MS.relocateAnchors(comp, list, t);
        for (i = 0; i < list.length; i++) {
            l = list[i].l; r = list[i].r;
            sc = MS.tr(l, "ADBE Scale");
            cur = sc.valueAtTime(t, true);
            sx = cw * k / r.width * 100; sy = ch * k / r.height * 100;
            if (mode === "prop" || mode === "safe" || mode === "lock") { sx = sy = Math.min(sx, sy); }
            else if (mode === "width") { sy = cur[1]; }
            else if (mode === "height") { sx = cur[0]; }
            if (mode === "lock") {
                ext = MS.ext(l) ? "true" : "false";
                MS.ensureExpr(sc, "var r=sourceRectAtTime(time," + ext + ");\nvar s=Math.min(thisComp.width/r.width,thisComp.height/r.height)*100;\n" + (l.threeDLayer ? "[s,s,value[2]]" : "[s,s]"));
                MS.ensureExpr(MS.tr(l, "ADBE Anchor Point"), "var r=sourceRectAtTime(time," + ext + ");\n[r.left+r.width/2,r.top+r.height/2" + (l.threeDLayer ? ",value[2]]" : "]"));
            } else {
                if (sc.expression) { sc.expression = ""; }
                MS.setVal(sc, MS.vfit(cur, [sx, sy]), t);
            }
        }
        g = MS.geo(comp, (function () { var a = [], j; for (j = 0; j < list.length; j++) { a.push(list[j].l); } return a; }()), t);
        for (i = 0; i < g.length; i++) { items.push({ l: g[i].l, g: g[i], d: [cw / 2 - g[i].cx, ch / 2 - g[i].cy, 0] }); }
        MS.moveWorld(comp, items, t);
    };
    MS.T.fit = {
        name: "Fit to Comp",
        click: function (c) { MS.fitRun(c, "prop"); },
        alt: function (c) { MS.fitRun(c, "width"); },
        shift: function (c) { MS.fitRun(c, "height"); },
        ctrl: function (c) { MS.fitRun(c, "stretch"); },
        ctrlAlt: function (c) { MS.fitRun(c, "lock"); },
        shiftCtrl: function (c) { MS.fitRun(c, "safe"); }
    };

    /* ---------------- Delete Layers / Clean Up ---------------- */
    MS.exprText = function (comp) {
        var s = [], i;
        for (i = 1; i <= comp.numLayers; i++) { MS.walk(comp.layer(i), function (p) { if (p.canSetExpression && p.expression) { s.push(p.expression); } }); }
        return s.join("\n");
    };
    MS.isProtected = function (comp, l, exprs) {
        var i, o;
        try { if (l.isTrackMatte) { return true; } } catch (e) {}
        for (i = 1; i <= comp.numLayers; i++) {
            o = comp.layer(i);
            if (MS.eqL(o, l)) { continue; }
            if (o.parent && MS.eqL(o.parent, l)) { return true; }
            try { if (o.trackMatteLayer && MS.eqL(o.trackMatteLayer, l)) { return true; } } catch (e2) {}
        }
        return exprs.indexOf("\"" + l.name + "\"") !== -1 || exprs.indexOf("'" + l.name + "'") !== -1;
    };
    MS.deleteLayers = function (list, what) {
        var i;
        if (!list.length) { MS.fail("No " + what + " found."); }
        list.sort(function (a, b) { return b.index - a.index; });
        for (i = 0; i < list.length; i++) { try { MS.removeLayer(list[i]); } catch (e) {} }
        return list.length;
    };
    MS.isEmptyLayer = function (l) {
        try {
            if (MS.isText(l)) { return String(MS.textDoc(l).value.text).replace(/\s/g, "") === ""; }
            if (MS.isShape(l)) { return l.property("ADBE Root Vectors Group").numProperties === 0; }
            if ((l instanceof AVLayer) && l.source) {
                if ((l.source instanceof FootageItem) && l.source.footageMissing) { return true; }
                if ((l.source instanceof CompItem) && l.source.numLayers === 0) { return true; }
            }
        } catch (e) {}
        return false;
    };
    MS.removeEmptyGroups = function (l) {
        var removed = 0, again = true;
        function scan(contPath) {
            var cont = MS.resolveIdx(l, contPath), i, it, cp;
            if (!cont) { return; }
            for (i = cont.numProperties; i >= 1; i--) {
                it = MS.resolveIdx(l, contPath.concat([i]));
                if (it && it.matchName === "ADBE Vector Group") {
                    cp = contPath.concat([i, it.property("ADBE Vectors Group").propertyIndex]);
                    if (MS.resolveIdx(l, cp).numProperties === 0) { MS.resolveIdx(l, contPath.concat([i])).remove(); removed++; again = true; }
                    else { scan(cp); }
                }
            }
        }
        while (again) { again = false; scan(MS.idxPath(l.property("ADBE Root Vectors Group"))); }
        return removed;
    };
    MS.T.cleanup = {
        name: "Delete Layers",
        click: function () {
            var comp = MS.comp(), ex = MS.exprText(comp);
            MS.deleteLayers(MS.filter(MS.allLayers(comp), function (l) { return !l.locked && MS.isEmptyLayer(l) && !MS.isProtected(comp, l, ex); }), "empty / no-media layers");
        },
        alt: function () {
            var comp = MS.comp(), ex = MS.exprText(comp);
            MS.deleteLayers(MS.filter(MS.allLayers(comp), function (l) {
                var hidden = MS.isAV(l) ? (l.hasVideo && !l.enabled) : !l.enabled;
                if (comp.hideShyLayers && l.shy) { hidden = true; }
                return hidden && !l.locked && !MS.isProtected(comp, l, ex);
            }), "hidden or disabled layers");
        },
        shift: function () {
            var n = app.project.removeUnusedFootage();
            if (!n) { MS.fail("No unused project assets found."); }
        },
        ctrl: function () {
            var comp = MS.comp();
            MS.deleteLayers(MS.filter(MS.allLayers(comp), function (l) { return (l instanceof AVLayer) && l.hasAudio && !l.hasVideo && !l.audioEnabled && !l.locked; }), "muted audio layers");
        },
        ctrlAlt: function () {
            var comp = MS.comp(), list = MS.filter(MS.allLayers(comp), function (l) { return !l.locked; });
            if (!list.length) { MS.fail("No unlocked layers found."); }
            if (!confirm("MotionSeeds: delete " + list.length + " unlocked layer(s) in \"" + comp.name + "\"?\n(Locked layers are kept. You can undo this.)", true, "MotionSeeds - Delete Unlocked Layers")) { return; }
            MS.deleteLayers(list, "unlocked layers");
        },
        shiftCtrl: function () {
            var comp = MS.comp(), ls = MS.filter(MS.sel(comp), MS.isShape), i, n = 0;
            if (!ls.length) { ls = MS.filter(MS.allLayers(comp), function (l) { return MS.isShape(l) && !l.locked; }); }
            for (i = 0; i < ls.length; i++) { n += MS.removeEmptyGroups(ls[i]); }
            if (!n) { MS.fail("No empty shape groups found."); }
        }
    };

    /* ---------------- Keyframe Utils (Reverse Keyframes button) ---------------- */
    MS.T.keyUtils = {
        name: "Keyframe Utils",
        click: function () {    // reverse selected keyframe timing
            var comp = MS.comp(), ps = MS.needKeyProps(comp), i, j, d, t0, t1, ks, n = 0;
            for (i = 0; i < ps.length; i++) {
                if (ps[i].selectedKeys.length < 2) { continue; }
                d = MS.selKeyData(ps[i]);
                t0 = d[0].t; t1 = d[d.length - 1].t;
                ks = ps[i].selectedKeys;
                for (j = ks.length - 1; j >= 0; j--) { ps[i].removeKey(ks[j]); }
                for (j = 0; j < d.length; j++) { MS.writeKey(ps[i], t0 + t1 - d[j].t, d[j], true); }
                n++;
            }
            if (!n) { MS.fail("Select at least 2 keyframes on a property."); }
        },
        alt: function () { MS.T.bake.click({ args: {}, mod: "click" }); },
        shift: function (c) { MS.cloneRun(c, false, false); },
        ctrl: function () {     // mirror keyframe values around the first selected key
            var comp = MS.comp(), ps = MS.needKeyProps(comp), i, j, ks, v0, v, n = 0;
            for (i = 0; i < ps.length; i++) {
                if (!MS.NUMERIC(ps[i])) { continue; }
                ks = ps[i].selectedKeys;
                v0 = ps[i].keyValue(ks[0]);
                for (j = 1; j < ks.length; j++) {
                    v = ps[i].keyValue(ks[j]);
                    if (MS.isArr(v)) { var o = [], m; for (m = 0; m < v.length; m++) { o.push(2 * v0[m] - v[m]); } ps[i].setValueAtKey(ks[j], o); }
                    else { ps[i].setValueAtKey(ks[j], 2 * v0 - v); }
                    n++;
                }
            }
            if (!n) { MS.fail("Select 2+ keyframes on numeric properties."); }
        },
        ctrlAlt: function () {  // rove in time
            var comp = MS.comp(), ps = MS.needKeyProps(comp), i, j, ks, n = 0;
            for (i = 0; i < ps.length; i++) {
                if (!ps[i].isSpatial) { continue; }
                ks = ps[i].selectedKeys;
                for (j = 0; j < ks.length; j++) {
                    if (ks[j] === 1 || ks[j] === ps[i].numKeys) { continue; }
                    try { ps[i].setRovingAtKey(ks[j], true); n++; } catch (e) {}
                }
            }
            if (!n) { MS.fail("Roving needs selected middle keyframes on a spatial property (e.g. Position)."); }
        },
        shiftCtrl: function () { // toggle hold
            var comp = MS.comp(), ps = MS.needKeyProps(comp), i, j, ks, allHold = true, H = KeyframeInterpolationType.HOLD, it;
            for (i = 0; i < ps.length; i++) { ks = ps[i].selectedKeys; for (j = 0; j < ks.length; j++) { if (ps[i].keyOutInterpolationType(ks[j]) !== H) { allHold = false; } } }
            for (i = 0; i < ps.length; i++) {
                ks = ps[i].selectedKeys;
                for (j = 0; j < ks.length; j++) {
                    it = ps[i].keyInInterpolationType(ks[j]);
                    if (allHold) { ps[i].setInterpolationTypeAtKey(ks[j], it === H ? KeyframeInterpolationType.LINEAR : it, it === KeyframeInterpolationType.BEZIER ? KeyframeInterpolationType.BEZIER : KeyframeInterpolationType.LINEAR); }
                    else { ps[i].setInterpolationTypeAtKey(ks[j], it, H); }
                }
            }
        }
    };

    /* ---------------- Bake Expressions button ---------------- */
    MS.bakeRun = function (step, wholeComp) {
        var comp = MS.comp(), sp = MS.filter(MS.selProps(comp), function (p) { return p.canSetExpression && p.expression && p.expressionEnabled; }), ls, i, n = 0;
        if (sp.length && !wholeComp) {
            for (i = 0; i < sp.length; i++) { if (MS.bakeProp(sp[i], comp, MS.ownerLayer(sp[i]), step)) { n++; } }
        } else {
            ls = wholeComp ? MS.allLayers(comp) : MS.sel(comp, 1);
            for (i = 0; i < ls.length; i++) { if (!ls[i].locked) { n += MS.bakeLayer(comp, ls[i], step); } }
        }
        if (!n) { MS.fail("No active expressions found to bake."); }
    };
    MS.T.bake = {
        name: "Bake Expressions",
        click: function () { MS.bakeRun(1, false); },
        alt: function () { MS.bakeRun(2, false); },
        shift: function () { MS.bakeRun(1, true); }
    };

    /* ---------------- Crop Comp to Selection ---------------- */
    MS.selSpan = function (comp) {
        var ls = MS.sel(comp, 1), a = 1e9, b = -1e9, i;
        for (i = 0; i < ls.length; i++) { a = Math.min(a, ls[i].inPoint); b = Math.max(b, ls[i].outPoint); }
        a = Math.max(0, a); b = Math.min(comp.duration, b);
        if (b - a < comp.frameDuration) { MS.fail("The selected layers have no duration inside the comp."); }
        return { a: a, b: b, ls: ls };
    };
    MS.T.crop = {
        name: "Crop Comp to Selection",
        click: function () {
            var comp = MS.comp(), s = MS.selSpan(comp);
            comp.workAreaStart = s.a;
            comp.workAreaDuration = s.b - s.a;
        },
        alt: function () {      // crop comp duration to the selection
            var comp = MS.comp(), s = MS.selSpan(comp), i, l, lk;
            for (i = 1; i <= comp.numLayers; i++) {
                l = comp.layer(i); lk = l.locked;
                if (lk) { l.locked = false; }
                l.startTime -= s.a;
                if (lk) { l.locked = true; }
            }
            comp.duration = s.b - s.a;
            comp.workAreaStart = 0;
            comp.workAreaDuration = comp.duration;
            comp.time = Math.max(0, comp.time - s.a);
        },
        shift: function () {    // crop comp size to the selected layers' bounds
            var comp = MS.comp(), t = comp.time, ls = MS.needSome(MS.filter(MS.sel(comp, 1), MS.isVisual), "Select visual layers."), u = MS.union(MS.geo(comp, ls, t)), W, H, i, l, lk;
            W = Math.max(4, Math.ceil(u.w)); H = Math.max(4, Math.ceil(u.h));
            for (i = 1; i <= comp.numLayers; i++) {
                l = comp.layer(i);
                if (l.parent) { continue; }
                lk = l.locked;
                if (lk) { l.locked = false; }
                MS.posAdd(l, [-u.minX, -u.minY, 0]);
                if ((l instanceof CameraLayer) || (l instanceof LightLayer)) { try { MS.addToProp(MS.tr(l, "ADBE Anchor Point"), [-u.minX, -u.minY, 0]); } catch (e) {} }
                if (lk) { l.locked = true; }
            }
            comp.width = W;
            comp.height = H;
        }
    };

    /* ---------------- Copy Ease Velocity ---------------- */
    MS.easeClip = null;
    MS.T.copyEase = {
        name: "Copy Ease Velocity",
        noUndoMods: ["click"],
        click: function () {
            var comp = MS.comp(), p = MS.needKeyProps(comp)[0], k = p.selectedKeys[0], ie = p.keyInTemporalEase(k), oe = p.keyOutTemporalEase(k);
            MS.easeClip = { inT: p.keyInInterpolationType(k), outT: p.keyOutInterpolationType(k), i: [ie[0].speed, ie[0].influence], o: [oe[0].speed, oe[0].influence] };
            return "copied";
        },
        shift: function () {
            var comp = MS.comp(), ps = MS.needKeyProps(comp), i, j, ks, n, E = MS.easeClip;
            if (!E) { MS.fail("Copy an ease first (click Copy Ease Velocity with one keyframe selected)."); }
            for (i = 0; i < ps.length; i++) {
                ks = ps[i].selectedKeys;
                for (j = 0; j < ks.length; j++) {
                    n = ps[i].keyInTemporalEase(ks[j]).length;
                    try { ps[i].setInterpolationTypeAtKey(ks[j], E.inT, E.outT); } catch (e1) {}
                    try { ps[i].setTemporalEaseAtKey(ks[j], MS.easeArr(n, E.i[0], E.i[1]), MS.easeArr(n, E.o[0], E.o[1])); } catch (e2) {}
                }
            }
        }
    };


    /* =====================================================================
     * MODULE 9 - WORKFLOW & RENDER
     * ===================================================================== */
    MS.compat = function () { return $.global.MotionSeedsCompat || { aeVersion: parseFloat(app.version), hasTaper: parseFloat(app.version) >= 17.1, hasH264RQ: parseFloat(app.version) >= 23, hasAME: true }; };
    MS.safeName = function (s) { return String(s).replace(/[\\\/:\*\?"<>\|]/g, "_").replace(/^\s+|\s+$/g, ""); };
    MS.outFolder = function (sub) {
        var base = (app.project.file) ? app.project.file.parent.fsName : Folder.desktop.fsName, f = new Folder(base + "/" + sub);
        if (!f.exists && !f.create()) { MS.fail("Cannot create folder: " + f.fsName + "  (enable Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network)"); }
        return f;
    };
    MS.frameNum = function (comp, t) { return Math.round((t + comp.displayStartTime) / comp.frameDuration); };

    /* ---------------- Batch Rename ---------------- */
    MS.renameTargets = function () {
        var comp = MS.compOrNull(), s, out = [], i;
        if (comp && comp.selectedLayers.length) { out = MS.sel(comp); out.sort(function (a, b) { return a.index - b.index; }); return { kind: "layer", items: out }; }
        s = app.project.selection;
        if (s && s.length) { for (i = 0; i < s.length; i++) { out.push(s[i]); } return { kind: "item", items: out }; }
        MS.fail("Select layers (or Project panel items) to rename.");
    };
    MS.ask = function (msg, def) {
        var s = prompt(msg, def || "", "MotionSeeds - Batch Rename");
        return (s === null) ? null : String(s);
    };
    MS.pad = function (n, w) { var s = String(n); while (s.length < w) { s = "0" + s; } return s; };
    MS.typeLabel = function (x) {
        if (x instanceof TextLayer) { return 1; }
        if (x instanceof ShapeLayer) { return 2; }
        if (x instanceof CameraLayer) { return 13; }
        if (x instanceof LightLayer) { return 6; }
        if (x instanceof AVLayer) {
            if (x.nullLayer) { return 11; }
            if (x.adjustmentLayer) { return 5; }
            if (x.source instanceof CompItem) { return 15; }
            if (MS.isSolidLayer(x)) { return 4; }
            if (x.hasAudio && !x.hasVideo) { return 9; }
            try { if (x.source.mainSource.isStill) { return 14; } } catch (e) {}
            return 3;
        }
        if (x instanceof CompItem) { return 15; }
        if (x instanceof FolderItem) { return 2; }
        if (x instanceof FootageItem) {
            try { if (x.mainSource instanceof SolidSource) { return 4; } if (x.hasAudio && !x.hasVideo) { return 9; } if (x.mainSource.isStill) { return 14; } } catch (e2) {}
            return 3;
        }
        return 0;
    };
    MS.T.rename = {
        name: "Batch Rename",
        click: function () {
            var o = MS.renameTargets(), s = MS.ask("New name for " + o.items.length + " item(s):", o.items[0].name), i;
            if (s === null || !MS.trim(s)) { return; }
            for (i = 0; i < o.items.length; i++) { o.items[i].name = (o.items.length === 1) ? s : s + " " + (i + 1); }
        },
        alt: function () {      // staircase Name_01, Name_02 ...
            var o = MS.renameTargets(), s = MS.ask("Base name (becomes Name_01, Name_02 ...):", String(o.items[0].name).replace(/[_\s]*\d+$/, "")), i, w;
            if (s === null || !MS.trim(s)) { return; }
            w = Math.max(2, String(o.items.length).length);
            for (i = 0; i < o.items.length; i++) { o.items[i].name = s + "_" + MS.pad(i + 1, w); }
        },
        shift: function () {
            var o = MS.renameTargets(), s = MS.ask("Suffix to append:", "_v01"), i;
            if (s === null || s === "") { return; }
            for (i = 0; i < o.items.length; i++) { o.items[i].name = o.items[i].name + s; }
        },
        ctrl: function () {     // auto color-code by asset type
            var o = MS.renameTargets(), i, lb;
            for (i = 0; i < o.items.length; i++) { lb = MS.typeLabel(o.items[i]); if (lb) { o.items[i].label = lb; } }
        },
        ctrlAlt: function () {  // search & replace
            var o = MS.renameTargets(), f = MS.ask("Find text:", ""), r, i, n = 0, nm;
            if (f === null || f === "") { return; }
            r = MS.ask("Replace \"" + f + "\" with:", "");
            if (r === null) { return; }
            for (i = 0; i < o.items.length; i++) {
                nm = String(o.items[i].name);
                if (nm.indexOf(f) !== -1) { o.items[i].name = nm.split(f).join(r); n++; }
            }
            if (!n) { MS.fail("\"" + f + "\" was not found in the selected names."); }
        },
        shiftCtrl: function () {
            var o = MS.renameTargets(), s = MS.ask("Prefix to prepend:", "MS_"), i;
            if (s === null || s === "") { return; }
            for (i = 0; i < o.items.length; i++) { o.items[i].name = s + o.items[i].name; }
        }
    };

    /* ---------------- Smart Grouping ---------------- */
    MS.descendants = function (comp, root) {
        var out = [], i, l, p;
        for (i = 1; i <= comp.numLayers; i++) {
            l = comp.layer(i);
            p = l.parent;
            while (p) { if (MS.eqL(p, root)) { out.push(l); break; } p = p.parent; }
        }
        return out;
    };
    MS.T.group = {
        name: "Smart Grouping",
        click: function () {
            var comp = MS.comp(), t = comp.time, sel = MS.sel(comp, 1), vis = MS.filter(sel, MS.isVisual), u, n, i;
            u = vis.length ? MS.union(MS.geo(comp, vis, t)) : { cx: comp.width / 2, cy: comp.height / 2 };
            n = MS.newNull(comp, "MS Group");
            MS.tr(n, "ADBE Anchor Point").setValue([50, 50, 0]);
            MS.tr(n, "ADBE Position").setValue([u.cx, u.cy, 0]);
            n.label = sel[0].label;
            MS.placeAbove(n, MS.topOf(sel));
            for (i = 0; i < sel.length; i++) {
                if (sel[i].parent && MS.idxL(sel, sel[i].parent) !== -1) { continue; }
                try { sel[i].parent = n; } catch (e) {}
            }
        },
        alt: function (c) {     // select all children of the active parent
            var comp = MS.comp(), p = MS.sel(comp, 1)[0], d = MS.descendants(comp, p);
            if (!d.length) { MS.fail("\"" + p.name + "\" has no child layers."); }
            MS.selectOnly(comp, [p].concat(d));
            c.selSet = true;
        },
        shift: function () {    // ungroup & clear parenting
            var comp = MS.comp(), sel = MS.sel(comp, 1), i, j, kids, rm = [];
            for (i = 0; i < sel.length; i++) {
                kids = MS.filter(MS.allLayers(comp), function (x) { return x.parent && MS.eqL(x.parent, sel[i]); });
                for (j = 0; j < kids.length; j++) { kids[j].parent = null; }
                if (sel[i].parent) { sel[i].parent = null; }
                if (kids.length && sel[i].nullLayer && sel[i].name.indexOf("MS Group") === 0) { rm.push(sel[i]); }
            }
            for (i = 0; i < rm.length; i++) { MS.removeLayer(rm[i]); }
        },
        ctrl: function () {     // pre-compose the group (parent + all descendants)
            var comp = MS.comp(), p = MS.sel(comp, 1)[0], all = [p].concat(MS.descendants(comp, p)), idx = [], i;
            for (i = 0; i < all.length; i++) { idx.push(all[i].index); }
            idx.sort(function (a, b) { return a - b; });
            comp.layers.precompose(idx, p.name + " Group", true);
        },
        ctrlAlt: function () {  // lock / unlock the hierarchy
            var comp = MS.comp(), p = MS.sel(comp, 1)[0], all = [p].concat(MS.descendants(comp, p)), v = !p.locked, i;
            for (i = all.length - 1; i >= 0; i--) { try { all[i].locked = v; } catch (e) {} }
        },
        shiftCtrl: function () { // solo / unsolo the hierarchy
            var comp = MS.comp(), p = MS.sel(comp, 1)[0], all = [p].concat(MS.descendants(comp, p)), v = !p.solo, i;
            for (i = 0; i < all.length; i++) { try { all[i].solo = v; } catch (e) {} }
        }
    };

    /* ---------------- Smart Snapshot ---------------- */
    MS.savePng = function (comp, t, file) {
        var i;
        if (typeof comp.saveFrameToPng !== "function") { MS.fail("Frame snapshots need After Effects CC 2015 or newer."); }
        if (file.exists) { file.remove(); }
        comp.saveFrameToPng(t, file);
        for (i = 0; i < 100 && !file.exists; i++) { $.sleep(50); }
        if (!file.exists) { MS.fail("Snapshot could not be written: " + file.fsName + "  (enable Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network)"); }
        $.sleep(100);
        return file;
    };
    MS.snapName = function (comp, t, ext) { return MS.safeName(comp.name) + "_" + MS.pad(MS.frameNum(comp, t), 5) + "." + ext; };
    MS.projFolder = function (name) {
        var i, it;
        for (i = 1; i <= app.project.rootFolder.numItems; i++) { it = app.project.rootFolder.item(i); if (it instanceof FolderItem && it.name === name) { return it; } }
        return app.project.items.addFolder(name);
    };
    MS.T.snapshot = {
        name: "Smart Snapshot",
        noUndoMods: ["alt", "shift", "ctrl", "ctrlAlt", "shiftCtrl"],
        click: function (c) {   // PNG snapshot imported into the project
            var comp = MS.comp(), t = comp.time, f = MS.savePng(comp, t, new File(MS.outFolder("MotionSeeds Snapshots").fsName + "/" + MS.snapName(comp, t, "png"))), it;
            it = app.project.importFile(new ImportOptions(f));
            it.parentFolder = MS.projFolder("MS Snapshots");
            c.info = "Snapshot imported: " + f.name;
        },
        alt: function (c) {     // save into a chosen OS folder
            var comp = MS.comp(), t = comp.time, fo = Folder.selectDialog("MotionSeeds - choose a folder for the snapshot"), f;
            if (!fo) { return; }
            f = MS.savePng(comp, t, new File(fo.fsName + "/" + MS.snapName(comp, t, "png")));
            c.info = "Saved: " + f.fsName;
        },
        shift: function () {    // compressed JPEG (converted by the panel)
            var comp = MS.comp(), t = comp.time, dir = MS.outFolder("MotionSeeds Snapshots"), tmp = new File(Folder.temp.fsName + "/ms_snap_" + new Date().getTime() + ".png");
            MS.savePng(comp, t, tmp);
            return { post: "jpeg", src: tmp.fsName, dst: dir.fsName + "/" + MS.snapName(comp, t, "jpg") };
        },
        ctrl: function () {     // layered PSD through AE's native "Save Frame As > Photoshop Layers..."
            var comp = MS.comp(), id = app.findMenuCommandId("Photoshop Layers...");
            if (!id) { MS.fail("Use Composition > Save Frame As > Photoshop Layers... (menu not found in this language)."); }
            try { comp.openInViewer(); } catch (e) {}
            app.executeCommand(id);
        },
        ctrlAlt: function (c) { // batch frames at composition (or selected layer) markers
            var comp = MS.comp(), mk = null, times = [], i, dir, sel = MS.sel(comp);
            try { mk = comp.markerProperty; } catch (e) { mk = null; }
            if (mk && mk.numKeys) { for (i = 1; i <= mk.numKeys; i++) { times.push(mk.keyTime(i)); } }
            if (!times.length && sel.length) { mk = sel[0].property("ADBE Marker"); for (i = 1; i <= mk.numKeys; i++) { times.push(mk.keyTime(i)); } }
            if (!times.length) { MS.fail("Add composition markers (or select a layer with markers) first."); }
            dir = MS.outFolder("MotionSeeds Snapshots/" + MS.safeName(comp.name) + " markers");
            for (i = 0; i < times.length; i++) { MS.savePng(comp, times[i], new File(dir.fsName + "/" + MS.snapName(comp, times[i], "png"))); }
            c.info = times.length + " marker frames saved to " + dir.fsName;
        },
        shiftCtrl: function () { // PNG cropped to the alpha boundary (cropped by the panel)
            var comp = MS.comp(), t = comp.time, dir = MS.outFolder("MotionSeeds Snapshots"), tmp = new File(Folder.temp.fsName + "/ms_snap_" + new Date().getTime() + ".png");
            MS.savePng(comp, t, tmp);
            return { post: "trim", src: tmp.fsName, dst: dir.fsName + "/" + MS.snapName(comp, t, "png").replace(/\.png$/, "_alpha.png") };
        }
    };

    /* ---------------- Quick Render ---------------- */
    MS.applyTemplate = function (om, names) {
        var tl = om.templates, i;
        for (i = 0; i < names.length; i++) { if (MS.idx(tl, names[i]) !== -1) { om.applyTemplate(names[i]); return names[i]; } }
        return null;
    };
    MS.toAME = function (comp, c, note) {
        var rq = app.project.renderQueue, states = [], i, item;
        if (typeof rq.queueInAME !== "function") { MS.fail("Adobe Media Encoder queueing is not available in this version."); }
        for (i = 1; i <= rq.numItems; i++) { try { states.push(rq.item(i).render); rq.item(i).render = false; } catch (e) { states.push(null); } }
        item = rq.items.add(comp);
        try { if (rq.canQueueInAME === false) { MS.fail("Media Encoder queue is unavailable (is Adobe Media Encoder installed?)."); } } catch (e2) { if (e2.msUser) { throw e2; } }
        rq.queueInAME(false);
        for (i = 1; i <= states.length; i++) { try { if (states[i - 1] !== null) { rq.item(i).render = states[i - 1]; } } catch (e3) {} }
        c.info = note || ("\"" + comp.name + "\" sent to Adobe Media Encoder.");
        return item;
    };
    MS.rqRender = function (c, label, templates, ext, settings) {
        var comp = MS.comp(), rqi = app.project.renderQueue.items.add(comp), om = rqi.outputModule(1), used = MS.applyTemplate(om, templates), dir = MS.outFolder("Renders");
        if (!used && settings) { try { om.setSettings(settings); used = "custom"; } catch (e) { used = null; } }
        if (!used) {
            rqi.remove();
            MS.fail(label + ": no matching Output Module template found (" + templates.join(" / ") + "). Create one in Edit > Templates > Output Module.");
        }
        om.file = new File(dir.fsName + "/" + MS.safeName(comp.name) + "_" + label.replace(/[^A-Za-z0-9]+/g, "") + "." + ext);
        c.info = "\"" + comp.name + "\" added to the Render Queue (" + used + ").";
        return rqi;
    };
    MS.T.render = {
        name: "Quick Render",
        click: function (c) {   // H.264 / MP4
            var comp = MS.comp();
            if (MS.compat().hasH264RQ) {
                MS.rqRender(c, "H264", ["H.264 - Match Render Settings - 15 Mbps", "H.264 - Match Render Settings - 5 Mbps", "H.264 - Match Render Settings - 40 Mbps", "H.264"], "mp4", { "Format": "H.264" });
            } else {
                MS.toAME(comp, c, "H.264 is rendered by Media Encoder in this AE version: \"" + comp.name + "\" queued in AME.");
            }
        },
        alt: function (c) { MS.rqRender(c, "ProRes4444", ["Apple ProRes 4444", "ProRes 4444", "Apple ProRes 4444 XQ", "High Quality with Alpha", "Lossless with Alpha"], "mov", null); },
        shift: function (c) { var comp = MS.comp(); MS.toAME(comp, c, "Animated GIF: \"" + comp.name + "\" queued in Media Encoder - pick the Animated GIF preset there."); },
        ctrl: function (c) { MS.toAME(MS.comp(), c, null); },
        ctrlAlt: function (c) { MS.rqRender(c, "ProRes422", ["Apple ProRes 422", "Apple ProRes 422 HQ", "ProRes 422", "High Quality", "Lossless"], "mov", null); },
        shiftCtrl: function (c) { MS.rqRender(c, "WAV", ["WAV", "WAV 48kHz", "AIFF 48kHz"], "wav", { "Format": "WAV" }); }
    };

    /* ---------------- Project Purge & Save ---------------- */
    MS.nextVersionFile = function (f) {
        var dir = f.parent.fsName, base = decodeURI(f.name).replace(/\.aep$/i, ""), m = base.match(/^(.*?)(_v)(\d+)$/i), n, w, stem, out;
        if (m) { stem = m[1] + m[2]; n = parseInt(m[3], 10) + 1; w = m[3].length; } else { stem = base + "_v"; n = 2; w = 2; }
        do { out = new File(dir + "/" + stem + MS.pad(n, w) + ".aep"); n++; } while (out.exists);
        return out;
    };
    MS.T.purge = {
        name: "Project Purge & Save",
        noUndoMods: ["alt", "ctrlAlt", "shiftCtrl"],
        click: function (c) {
            var n = app.project.removeUnusedFootage();
            c.info = n ? n + " unused footage item(s) removed." : "No unused footage found.";
        },
        alt: function (c) {
            app.purge(PurgeTarget.ALL_CACHES);
            var id = 0;
            try { id = app.findMenuCommandId("All Memory & Disk Cache..."); } catch (e) {}
            if (id) { app.executeCommand(id); }
            c.info = "Memory caches purged.";
        },
        shift: function (c) {
            var n = app.project.consolidateFootage();
            c.info = n ? n + " duplicate footage item(s) consolidated." : "Nothing to consolidate.";
        },
        ctrl: function () {     // reduce project to the selected / active comps
            var s = app.project.selection, comps = [], i, a = MS.compOrNull();
            for (i = 0; i < s.length; i++) { if (s[i] instanceof CompItem) { comps.push(s[i]); } }
            if (!comps.length && a) { comps.push(a); }
            if (!comps.length) { MS.fail("Select comps in the Project panel (or open one)."); }
            if (!confirm("Reduce the project to " + comps.length + " comp(s) and their dependencies?", true, "MotionSeeds - Reduce Project")) { return; }
            app.project.reduceProject(comps);
        },
        ctrlAlt: function (c) { // purge + incremental save
            var f;
            app.purge(PurgeTarget.ALL_CACHES);
            if (!app.project.file) { app.project.saveWithDialog(); return; }
            f = MS.nextVersionFile(app.project.file);
            app.project.save(f);
            c.info = "Saved as " + decodeURI(f.name);
        },
        shiftCtrl: function () {
            var id = 0;
            try { id = app.findMenuCommandId("Collect Files..."); } catch (e) {}
            if (!id) { MS.fail("Use File > Dependencies > Collect Files... (menu not found in this language)."); }
            app.executeCommand(id);
        }
    };

    /* =====================================================================
     * LICENSING - machine fingerprint (blueprint STEP 3, hardened)
     * ===================================================================== */
    MS.deviceCache = null;
    MS.sys = function (cmd) { var r = system.callSystem(cmd); return r ? String(r) : ""; };
    MS.validUUID = function (u) { return !!u && !/^[0F\-]+$/i.test(u) && u.length > 5; };
    MS.getSystemDeviceID = function () {
        var id = "", out, m, rx = /[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/;
        if (MS.deviceCache) { return MS.deviceCache; }
        try {
            if ($.os.indexOf("Windows") !== -1) {
                try { out = MS.sys("cmd.exe /c wmic csproduct get uuid"); m = out.match(rx); if (m && MS.validUUID(m[0])) { id = "WIN_" + m[0].toUpperCase(); } } catch (e1) {}
                if (!id) { try { out = MS.sys("powershell.exe -NoProfile -NonInteractive -Command \"(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID\""); m = out.match(rx); if (m && MS.validUUID(m[0])) { id = "WIN_" + m[0].toUpperCase(); } } catch (e2) {} }
                if (!id) { try { out = MS.sys("cmd.exe /c reg query \"HKLM\\SOFTWARE\\Microsoft\\Cryptography\" /v MachineGuid"); m = out.match(/MachineGuid\s+REG_SZ\s+([0-9A-Fa-f\-]+)/); if (m) { id = "WINR_" + m[1].toUpperCase(); } } catch (e3) {} }
            } else {
                out = MS.sys("/usr/sbin/ioreg -rd1 -c IOPlatformExpertDevice");
                m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/);
                if (m && m[1]) { id = "MAC_" + m[1]; }
            }
        } catch (e) {}
        if (!id) { return "MOTIONSEEDS_FALLBACK_DEVICE_ID"; }
        MS.deviceCache = id;
        return id;
    };


    /* =====================================================================
     * DISPATCHER - called by the panel:  MotionSeeds.exec(tool, modifierTier, argsJSON)
     * ===================================================================== */
    MS.sameSel = function (a, b) {
        var i;
        if (a.length !== b.length) { return false; }
        for (i = 0; i < a.length; i++) { if (!MS.eqL(a[i], b[i])) { return false; } }
        return true;
    };
    MS.exec = function (tool, mod, argStr) {
        var res = { ok: true, err: "", info: "", data: null }, t = MS.T[tool], fn, args = {}, ctx, undo, comp0 = null, sel0 = [], r, comp1;
        if (!t) { res.ok = false; res.err = "Unknown tool: " + tool; return MS.json(res); }
        fn = t[mod];
        if (typeof fn !== "function") { res.ok = false; res.err = (t.name || tool) + ": no " + (MS.MOD[mod] || mod) + " action."; return MS.json(res); }
        if (argStr) { try { args = JSON.parse(argStr); } catch (pe) { args = {}; } }
        ctx = { mod: mod, args: args || {}, info: "", selSet: false };
        undo = !(t.noUndo === true || (t.noUndoMods && MS.idx(t.noUndoMods, mod) !== -1));
        try { comp0 = MS.compOrNull(); if (comp0) { sel0 = MS.sel(comp0); } } catch (e0) { comp0 = null; }
        if (undo) { app.beginUndoGroup("MotionSeeds: " + (t.name || tool)); }
        try {
            r = fn(ctx);
            res.data = (r === undefined) ? null : r;
            res.info = ctx.info || "";
            if (comp0 && !ctx.selSet) {
                comp1 = MS.compOrNull();
                if (comp1 && comp1.id === comp0.id && !MS.sameSel(MS.sel(comp0), sel0)) { MS.selectOnly(comp0, sel0); }
            }
        } catch (err) {
            res.ok = false;
            res.err = MS.errStr(err);
        } finally {
            if (undo) { app.endUndoGroup(); }
        }
        return MS.json(res);
    };
    MS.setRoot = function (p) { MS.root = String(p).replace(/\\/g, "/").replace(/\/$/, ""); return "ok"; };
    MS.ping = function () { return MS.json({ ok: true, v: MS.VERSION, ae: app.version, os: $.os }); };

    $.global.MotionSeeds = MS;
    $.global.getSystemDeviceID = function () { return MS.getSystemDeviceID(); };


}());
